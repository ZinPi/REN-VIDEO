import gc
import json
import os
import re
import shutil
import tempfile
import urllib.parse
import urllib.request
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from common import app_dir, sanitize_filename

COMMON_LANGUAGES = [
    ("Ngôn ngữ gốc (tự động)", "auto"),
    ("Tiếng Việt", "vi"),
    ("日本語 / Tiếng Nhật", "ja"),
    ("English", "en"),
    ("한국어 / Tiếng Hàn", "ko"),
    ("中文 / Tiếng Trung", "zh-Hans"),
    ("繁體中文 / Trung phồn thể", "zh-Hant"),
    ("Español", "es"),
    ("Français", "fr"),
    ("Deutsch", "de"),
    ("ไทย", "th"),
    ("Bahasa Indonesia", "id"),
]
LANG_LABEL_TO_CODE = dict(COMMON_LANGUAGES)

WHISPER_QUALITY = [
    "Nhanh (small)",
    "Cân bằng (medium)",
    "Chính xác (large-v3)",
]
WHISPER_MODEL_BY_QUALITY = {
    "Nhanh (small)": "small",
    "Cân bằng (medium)": "medium",
    "Chính xác (large-v3)": "large-v3",
}


@dataclass
class Segment:
    text: str
    start: float
    duration: float

    @property
    def end(self):
        return self.start + self.duration


def extract_video_id(url_or_id: str) -> str:
    raw = (url_or_id or "").strip()
    if re.fullmatch(r"[A-Za-z0-9_-]{11}", raw):
        return raw

    try:
        u = urllib.parse.urlparse(raw)
    except Exception:
        u = None

    if u:
        host = (u.netloc or '').lower()
        path = u.path or ''
        if 'youtu.be' in host:
            candidate = path.strip('/').split('/')[0]
            if re.fullmatch(r"[A-Za-z0-9_-]{11}", candidate or ''):
                return candidate
        if 'youtube.com' in host or 'youtube-nocookie.com' in host:
            q = urllib.parse.parse_qs(u.query)
            if q.get('v'):
                candidate = q['v'][0]
                if re.fullmatch(r"[A-Za-z0-9_-]{11}", candidate or ''):
                    return candidate
            parts = [p for p in path.split('/') if p]
            if parts and parts[0] in ('shorts', 'embed', 'live') and len(parts) > 1:
                candidate = parts[1]
                if re.fullmatch(r"[A-Za-z0-9_-]{11}", candidate or ''):
                    return candidate

    m = re.search(r"(?:v=|youtu\.be/|shorts/|embed/|live/)([A-Za-z0-9_-]{11})", raw)
    if m:
        return m.group(1)
    raise ValueError("Không nhận diện được Video ID từ URL YouTube này.")


def normalize_item(item) -> Segment:
    if hasattr(item, 'text'):
        text = str(item.text)
        start = float(item.start)
        duration = float(item.duration)
    elif isinstance(item, dict):
        text = str(item.get('text', ''))
        start = float(item.get('start', 0) or 0)
        duration = float(item.get('duration', 0) or 0)
    else:
        raise TypeError("Định dạng transcript không được hỗ trợ")
    text = re.sub(r'\s+', ' ', text.replace('\n', ' ')).strip()
    return Segment(text=text, start=start, duration=duration)


def clean_segments(items):
    out = []
    for item in items:
        try:
            s = normalize_item(item)
        except Exception:
            continue
        if not s.text:
            continue
        if s.text.startswith('[') and s.text.endswith(']') and len(s.text) < 50:
            # Keep useful markers such as [Music], but they can be removed later if desired.
            pass
        out.append(s)
    return out


def _fetch_yta(video_id: str, lang_code: str):
    """Fetch transcript with youtube-transcript-api, compatible with old/new releases."""
    from youtube_transcript_api import YouTubeTranscriptApi

    # New API (1.x): instance methods list/fetch
    try:
        api = YouTubeTranscriptApi()
        if hasattr(api, 'list'):
            transcript_list = api.list(video_id)
            transcripts = list(transcript_list)
            if not transcripts:
                raise RuntimeError("YouTube không trả về transcript nào.")

            selected = None
            if lang_code != 'auto':
                exact = [t for t in transcripts if getattr(t, 'language_code', '') == lang_code]
                if not exact and '-' in lang_code:
                    base = lang_code.split('-')[0]
                    exact = [t for t in transcripts if getattr(t, 'language_code', '').split('-')[0] == base]
                if exact:
                    # prefer human-created transcript, then generated
                    exact.sort(key=lambda t: bool(getattr(t, 'is_generated', False)))
                    selected = exact[0]
                else:
                    # try library's language resolver, which may support translation
                    try:
                        selected = transcript_list.find_transcript([lang_code])
                    except Exception:
                        pass
            else:
                manual = [t for t in transcripts if not getattr(t, 'is_generated', False)]
                selected = (manual or transcripts)[0]

            if selected is None:
                langs = ', '.join(sorted({getattr(t, 'language_code', '?') for t in transcripts}))
                raise RuntimeError(f"Không có transcript cho ngôn ngữ đã chọn. Có sẵn: {langs}")

            fetched = selected.fetch()
            segments = clean_segments(fetched)
            meta = {
                'source': 'youtube-transcript-api',
                'language_code': getattr(selected, 'language_code', lang_code),
                'language': getattr(selected, 'language', ''),
                'is_generated': bool(getattr(selected, 'is_generated', False)),
            }
            return segments, meta
    except TypeError:
        pass

    # Older API: static list_transcripts/get_transcript
    if hasattr(YouTubeTranscriptApi, 'list_transcripts'):
        transcript_list = YouTubeTranscriptApi.list_transcripts(video_id)
        transcripts = list(transcript_list)
        if not transcripts:
            raise RuntimeError("YouTube không trả về transcript nào.")
        selected = None
        if lang_code == 'auto':
            manual = [t for t in transcripts if not getattr(t, 'is_generated', False)]
            selected = (manual or transcripts)[0]
        else:
            try:
                selected = transcript_list.find_transcript([lang_code])
            except Exception:
                base = lang_code.split('-')[0]
                matches = [t for t in transcripts if getattr(t, 'language_code', '').split('-')[0] == base]
                if matches:
                    selected = matches[0]
        if selected is None:
            langs = ', '.join(sorted({getattr(t, 'language_code', '?') for t in transcripts}))
            raise RuntimeError(f"Không có transcript cho ngôn ngữ đã chọn. Có sẵn: {langs}")
        fetched = selected.fetch()
        segments = clean_segments(fetched)
        meta = {
            'source': 'youtube-transcript-api',
            'language_code': getattr(selected, 'language_code', lang_code),
            'language': getattr(selected, 'language', ''),
            'is_generated': bool(getattr(selected, 'is_generated', False)),
        }
        return segments, meta

    # Very old API fallback
    languages = None if lang_code == 'auto' else [lang_code]
    rows = YouTubeTranscriptApi.get_transcript(video_id, languages=languages)
    return clean_segments(rows), {
        'source': 'youtube-transcript-api',
        'language_code': lang_code,
        'language': '',
        'is_generated': None,
    }


def choose_caption_track(info: dict, lang_code: str):
    manual = info.get('subtitles') or {}
    automatic = info.get('automatic_captions') or {}

    def candidates_for(mapping):
        if not mapping:
            return []
        if lang_code == 'auto':
            preferred = []
            native = info.get('language')
            if native and native in mapping:
                preferred.append(native)
            preferred += [k for k in mapping.keys() if k not in preferred]
            return preferred
        if lang_code in mapping:
            return [lang_code]
        base = lang_code.split('-')[0]
        exact_base = [k for k in mapping if k.split('-')[0] == base]
        return exact_base

    manual_langs = candidates_for(manual)
    auto_langs = candidates_for(automatic)
    if manual_langs:
        code = manual_langs[0]
        return code, manual[code], False
    if auto_langs:
        code = auto_langs[0]
        return code, automatic[code], True
    available = sorted(set(manual) | set(automatic))
    raise RuntimeError("Không tìm thấy subtitle phù hợp qua yt-dlp. Ngôn ngữ có sẵn: " + ', '.join(available[:30]))


def parse_json3_caption(data: dict):
    segments = []
    for ev in data.get('events', []):
        segs = ev.get('segs') or []
        if not segs:
            continue
        text = ''.join((s.get('utf8') or '') for s in segs)
        text = re.sub(r'\s+', ' ', text.replace('\n', ' ')).strip()
        if not text:
            continue
        start = float(ev.get('tStartMs', 0) or 0) / 1000.0
        duration = float(ev.get('dDurationMs', 0) or 0) / 1000.0
        segments.append(Segment(text=text, start=start, duration=duration))
    return segments


def _fetch_ytdlp(url: str, lang_code: str):
    import yt_dlp

    cookiefile = app_dir() / 'cookies.txt'
    opts = {
        'skip_download': True,
        'quiet': True,
        'no_warnings': True,
        'extract_flat': False,
        'noplaylist': True,
    }
    if cookiefile.exists():
        opts['cookiefile'] = str(cookiefile)

    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=False)

    code, formats, is_generated = choose_caption_track(info, lang_code)
    # Prefer json3 because it is easy to parse with timing intact.
    fmt = next((f for f in formats if f.get('ext') == 'json3'), None)
    if fmt is None:
        fmt = next((f for f in formats if 'json3' in (f.get('url') or '')), None)
    if fmt is None:
        raise RuntimeError("yt-dlp tìm thấy subtitle nhưng không có định dạng JSON3 để đọc trực tiếp.")

    req = urllib.request.Request(fmt['url'], headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req, timeout=30) as r:
        raw = r.read()
    data = json.loads(raw.decode('utf-8', errors='replace'))
    segments = parse_json3_caption(data)
    if not segments:
        raise RuntimeError("Subtitle JSON3 nhận được nhưng không có nội dung văn bản.")

    meta = {
        'source': 'yt-dlp',
        'language_code': code,
        'language': code,
        'is_generated': is_generated,
        'title': info.get('title') or '',
        'channel': info.get('channel') or info.get('uploader') or '',
        'webpage_url': info.get('webpage_url') or url,
    }
    return segments, meta


def _status(callback, message):
    if callback:
        try:
            callback(str(message))
        except Exception:
            pass


def _cookie_opts():
    cookiefile = app_dir() / 'cookies.txt'
    return {'cookiefile': str(cookiefile)} if cookiefile.exists() else {}


def _download_audio(url: str, video_id: str, work_dir: Path, status_callback=None):
    """Download audio-only with yt-dlp and return (audio_path, info)."""
    import yt_dlp

    _status(status_callback, 'Không có subtitle dùng được → đang tải riêng audio...')
    template = str(work_dir / f'{video_id}.%(ext)s')
    opts = {
        'format': 'bestaudio/best',
        'outtmpl': template,
        'quiet': True,
        'no_warnings': True,
        'noplaylist': True,
        'retries': 3,
        'fragment_retries': 3,
        'continuedl': True,
        **_cookie_opts(),
    }
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
        prepared = Path(ydl.prepare_filename(info))

    if prepared.exists():
        return prepared, info

    candidates = [p for p in work_dir.glob(f'{video_id}.*') if p.is_file() and not p.name.endswith(('.part', '.ytdl'))]
    if not candidates:
        raise RuntimeError('yt-dlp báo tải audio xong nhưng không tìm thấy file audio.')
    candidates.sort(key=lambda x: x.stat().st_size, reverse=True)
    return candidates[0], info


def _whisper_language(lang_code: str):
    if not lang_code or lang_code == 'auto':
        return None
    base = lang_code.split('-')[0].lower()
    aliases = {'zh': 'zh', 'jv': 'jw'}
    return aliases.get(base, base)


def _cuda_device_count():
    try:
        import ctranslate2
        fn = getattr(ctranslate2, 'get_cuda_device_count', None)
        return int(fn()) if fn else 0
    except Exception:
        return 0


def _transcribe_audio(audio_path: Path, lang_code: str, quality: str, status_callback=None):
    """Transcribe with automatic GPU→CPU fallback.

    Order: CUDA FP16 → CUDA INT8/FP16 → CPU INT8.
    """
    try:
        from faster_whisper import WhisperModel
    except Exception as e:
        raise RuntimeError(
            'Chưa có faster-whisper. Hãy chạy CHAY_TOOL.bat để tool tự cài thư viện nhận dạng giọng nói. '
            f'Chi tiết: {e}'
        )

    model_name = WHISPER_MODEL_BY_QUALITY.get(quality, 'medium')
    language = _whisper_language(lang_code)
    model_dir = app_dir() / 'whisper_models'
    try:
        model_dir.mkdir(parents=True, exist_ok=True)
    except Exception:
        model_dir = None

    attempts = []
    if _cuda_device_count() > 0:
        attempts.extend([
            ('cuda', 'float16', 'GPU CUDA FP16'),
            ('cuda', 'int8_float16', 'GPU CUDA INT8'),
        ])
    attempts.append(('cpu', 'int8', 'CPU INT8'))

    errors = []
    for device, compute_type, label in attempts:
        model = None
        try:
            _status(status_callback, f'Whisper: đang thử {label} • model {model_name}...')
            kwargs = {
                'device': device,
                'compute_type': compute_type,
            }
            if model_dir is not None:
                kwargs['download_root'] = str(model_dir)
            if device == 'cpu':
                kwargs['cpu_threads'] = max(1, (os.cpu_count() or 4) - 1)
                kwargs['num_workers'] = 1
            model = WhisperModel(model_name, **kwargs)
            _status(status_callback, f'Whisper đang nhận dạng bằng {label}...')
            stream, info = model.transcribe(
                str(audio_path),
                language=language,
                beam_size=5,
                vad_filter=True,
                condition_on_previous_text=True,
            )
            segments = []
            for seg in stream:
                text = re.sub(r'\s+', ' ', str(getattr(seg, 'text', '')).replace('\n', ' ')).strip()
                if not text:
                    continue
                start = float(getattr(seg, 'start', 0.0) or 0.0)
                end = float(getattr(seg, 'end', start) or start)
                segments.append(Segment(text=text, start=start, duration=max(0.05, end-start)))
            if not segments:
                raise RuntimeError('Whisper chạy xong nhưng không nhận dạng được lời nói.')
            detected = getattr(info, 'language', None) or language or 'auto'
            probability = getattr(info, 'language_probability', None)
            return segments, {
                'source': 'faster-whisper',
                'language_code': detected,
                'language': detected,
                'is_generated': None,
                'transcription_engine': label,
                'whisper_model': model_name,
                'language_probability': probability,
            }
        except Exception as e:
            errors.append(f'{label}: {e}')
            _status(status_callback, f'{label} không dùng được → tự chuyển chế độ khác...')
        finally:
            try:
                del model
            except Exception:
                pass
            gc.collect()

    raise RuntimeError('Whisper không chạy được ở cả GPU lẫn CPU.\n' + '\n'.join(f'• {x}' for x in errors))


def _fetch_audio_transcription(url: str, video_id: str, lang_code: str, quality: str, status_callback=None):
    work_dir = Path(tempfile.mkdtemp(prefix='alltool_whisper_'))
    try:
        audio_path, info = _download_audio(url, video_id, work_dir, status_callback)
        segs, meta = _transcribe_audio(audio_path, lang_code, quality, status_callback)
        meta.update({
            'title': info.get('title') or '',
            'channel': info.get('channel') or info.get('uploader') or '',
            'webpage_url': info.get('webpage_url') or url,
        })
        return segs, meta
    finally:
        shutil.rmtree(work_dir, ignore_errors=True)


def fetch_transcript(url: str, lang_code: str, *, allow_audio_fallback=True, whisper_quality='Cân bằng (medium)', status_callback=None):
    video_id = extract_video_id(url)
    errors = []

    _status(status_callback, 'Đang thử transcript/subtitle trực tiếp...')
    try:
        segs, meta = _fetch_yta(video_id, lang_code)
        if segs:
            meta['video_id'] = video_id
            return segs, meta
    except Exception as e:
        errors.append(f"youtube-transcript-api: {e}")

    _status(status_callback, 'Transcript API không lấy được → đang thử yt-dlp subtitle...')
    try:
        segs, meta = _fetch_ytdlp(url, lang_code)
        if segs:
            meta['video_id'] = video_id
            return segs, meta
    except Exception as e:
        errors.append(f"yt-dlp subtitle: {e}")

    if allow_audio_fallback:
        try:
            segs, meta = _fetch_audio_transcription(url, video_id, lang_code, whisper_quality, status_callback)
            if segs:
                meta['video_id'] = video_id
                return segs, meta
        except Exception as e:
            errors.append(f"audio + faster-whisper: {e}")

    raise RuntimeError(
        "Không lấy được nội dung YouTube.\n\n" +
        "\n".join(f"• {x}" for x in errors) +
        "\n\nNếu video không có subtitle, hãy bật chế độ nghe audio bằng Whisper. "
        "Nếu cả tải audio cũng bị YouTube chặn, có thể cần cookies.txt hoặc kiểm tra quyền truy cập video."
    )


def smart_merge(segments, max_chars=300, max_duration=24.0, gap_break=2.5):
    if not segments:
        return []
    merged = []
    current = []
    start = None
    end = None

    def flush():
        nonlocal current, start, end
        if current:
            text = ' '.join(current)
            text = re.sub(r'\s+([,.!?;:。！？、])', r'\1', text)
            merged.append(Segment(text=text.strip(), start=start or 0, duration=max(0.05, (end or start or 0) - (start or 0))))
        current, start, end = [], None, None

    for s in segments:
        if start is None:
            start, end = s.start, s.end
            current = [s.text]
            continue
        gap = s.start - (end or s.start)
        new_len = len(' '.join(current)) + 1 + len(s.text)
        duration = s.end - start
        sentence_end = bool(re.search(r'[.!?。！？]$', current[-1]))
        if gap > gap_break or new_len > max_chars or duration > max_duration or (sentence_end and len(' '.join(current)) > 80):
            flush()
            start, end = s.start, s.end
            current = [s.text]
        else:
            current.append(s.text)
            end = max(end or s.end, s.end)
    flush()
    return merged


def make_plain_text(segments):
    merged = smart_merge(segments, max_chars=340, max_duration=28.0)
    return '\n'.join(s.text for s in merged)


def make_srt(segments):
    merged = smart_merge(segments, max_chars=90, max_duration=8.5, gap_break=1.8)

    def fmt(sec):
        sec = max(0, sec)
        ms = int(round((sec - int(sec)) * 1000))
        total = int(sec)
        s = total % 60
        m = (total // 60) % 60
        h = total // 3600
        if ms >= 1000:
            ms = 0
            s += 1
        return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"

    blocks = []
    for i, s in enumerate(merged, 1):
        blocks.append(f"{i}\n{fmt(s.start)} --> {fmt(s.end)}\n{s.text}")
    return '\n\n'.join(blocks) + ('\n' if blocks else '')

