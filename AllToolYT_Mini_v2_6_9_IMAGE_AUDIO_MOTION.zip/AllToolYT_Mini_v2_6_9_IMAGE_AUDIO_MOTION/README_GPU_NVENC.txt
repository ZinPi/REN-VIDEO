ALLTOOLYT MINI v2.6.6 — SUA / CHAN DOAN GPU NVIDIA
====================================================

BAN GOC: v2.6.5 (giữ nguyên ZIP gốc).

Vì sao v2.6.5 vẫn chạy CPU?
- GPU=ON chỉ là lựa chọn, KHÔNG xác nhận RTX 3060 đã mã hóa được.
- Log cũ báo NVENC preflight FAIL, sau đó chương trình chuyển sang libx264/CPU.
- Lỗi -22 / "Could not open encoder before EOF" thường là HẬU QUẢ.
  Phải xem dòng phía trên để biết lỗi NVENC/driver/CUDA/API thật sự.
- Không thể xác nhận root cause trên máy Windows chỉ từ log đã rút gọn.

Trong v2.6.6:
1) TEST NVENC và lúc render đều dùng video MP4 TEST THẬT.
2) Thử FFmpeg cạnh tool, các bản trong PATH và FFmpeg imageio (nếu có).
3) Thử 3 cấu hình NVENC: p4_constqp, medium_constqp, basic_compat.
4) Test cả video 640x360 lẫn độ phân giải đầu ra người dùng chọn.
5) Chỉ khi PASS mới gắn FFmpeg/profile đó cho toàn bộ tiến trình render.
6) Ghi GPU model/driver qua nvidia-smi khi có; không coi thiếu nvidia-smi là GPU hỏng.
7) Hiện lỗi từ FFmpeg NVENC có nguyên nhân cao, không che bởi -22 cuối log.
8) Có GPU_DIAGNOSTIC.bat: tự tạo GPU_DIAGNOSTIC_*.txt để gửi khi FAIL.
9) Giữ CPU fallback an toàn nếu phần cứng/driver/FFmpeg vẫn không hỗ trợ.

Cách dùng:
- Giải nén phiên bản mới ra THƯ MỤC RIÊNG, không ghi đè ZIP gốc.
- Chạy CHAY_TOOL_KHONG_CMD.vbs, hoặc CHAY_TOOL.bat (Python + requirements).
- Trong tab Ảnh → Video, chọn GPU, bấm TEST NVENC.
- Log bắt buộc có dòng "NVENC PASS" mới khẳng định encoder GPU chạy.
- Nếu FAIL: chạy GPU_DIAGNOSTIC.bat, gửi file GPU_DIAGNOSTIC_*.txt.
- Có thể chép ffmpeg.exe bản hỗ trợ NVENC phù hợp driver đặt cạnh tool,
  hoặc cập nhật driver NVIDIA chính hãng rồi test lại.
- Không thay file ảnh, SRT, audio hoặc cache dự án của bạn.

Lưu ý quan trọng về hiệu năng:
- h264_nvenc chỉ chuyển bước MÃ HÓA H.264 sang GPU.
- Filter FFmpeg zoompan, easing, oversampling, scale Lanczos trong bản này
  vẫn chạy trên CPU. GPU Encode có thể PASS mà CPU vẫn sử dụng cao.
- Đừng hiểu nhầm GPU Encode với toàn bộ render hiệu ứng trên GPU.

Kiểm thử môi trường phát triển:
- Linux của môi trường kiểm thử không có CUDA/NVIDIA; không thể xác nhận
  RTX 3060 thật của bạn hoạt động từ đây.
- Linux giả lập được lỗi 'Cannot load libcuda.so.1' và bản mới ghi đúng nguyên nhân.
- Phải chạy TEST NVENC trên chính Windows có RTX 3060 để xác nhận thực tế.


CAP NHAT v2.6.7 (theo log RTX 3060 cua nguoi dung):
- NGUYEN NHAN DA XAC DINH: FFmpeg 8.1.2 yêu cầu NVENC 13.1; driver 576.02 chỉ có NVENC 13.0.
- FFmpeg 7.1 cài sẵn trong imageio_ffmpeg đã NVENC PASS với RTX 3060.
- FFMPEG_GPU_PATH.txt đã ưu tiên đúng đường dẫn FFmpeg 7.1 từ log. Nếu cài đặt
  Python đổi chỗ, hãy chỉnh file này hoặc xóa nó để tool tự dò bản FFmpeg khác.
- Không cần cập nhật driver nếu FFmpeg 7.1 vẫn PASS trên máy.
- Vào Ảnh → Video, bật GPU, bấm TEST NVENC; chờ "NVENC PASS".
- GPU PASS = mã hóa H.264 bằng NVENC; zoom/pan/Lanczos vẫn xử lý trên CPU.
- Linux môi trường chỉnh sửa không có NVIDIA; chưa thể chứng nhận lượt render thật trên Windows.

CAP NHAT V2.6.9: tab Anh + Audio 1:1 dung cung GPU/NVENC preflight va CPU fallback; bao cao QA co ghi NVENC encoded/CPU fallback.
