"""Lossless audio assembly and strict ordered pairing for IMAGE + AUDIO batch mode.

All behavior here is independent of Tk; the GUI delegates to these functions.
The audio master is one gapless FLAC encoded from decoded 48k stereo PCM. It
never concatenates individually encoded MP3/AAC chunks (encoder delay risk).
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import threading
from pathlib import Path
from typing import Callable

from common import find_ffmpeg, natural_key, parse_file_index, probe_media

IMAGE_EXTS = {'.png', '.jpg', '.jpeg', '.webp', '.bmp'}
AUDIO_EXTS = {'.mp3', '.wav', '.m4a', '.aac', '.flac', '.ogg', '.opus'}
SAMPLE_RATE = 48000
CHANNELS = 2
BYTES_PER_SAMPLE_FRAME = CHANNELS * 2

class JobCancelled(RuntimeError):
    pass


def strict_pairs(image_dir, audio_dir):
    """Never pair an indexed item with an unrelated audio or reuse an audio.

    Indexed names: use their LAST numerical token, exactly (CHAR_001 ↔ 001).
    Fully non-numeric names: natural-sort by position, equal counts required.
    Mixed indexing / duplicates / missing: fail *before* altering output.
    """
    images = sorted((p for p in Path(image_dir).iterdir() if p.is_file() and
                     p.suffix.lower() in IMAGE_EXTS), key=natural_key)
    audios = sorted((p for p in Path(audio_dir).iterdir() if p.is_file() and
                     p.suffix.lower() in AUDIO_EXTS), key=natural_key)
    if not images or not audios:
        raise ValueError(f'Thiếu ảnh hoặc audio: ảnh={len(images)}, audio={len(audios)}.')
    if len(images) != len(audios):
        raise ValueError(f'Sai số lượng: {len(images)} ảnh nhưng có {len(audios)} audio. Phải đủ 1:1.')
    im_ids = [parse_file_index(p) for p in images]
    au_ids = [parse_file_index(p) for p in audios]
    if all(i is None for i in im_ids + au_ids):
        return list(zip(images, audios)), 'natural-sort'
    if any(i is None for i in im_ids + au_ids):
        raise ValueError('Tên file có số và không có số bị trộn. Hãy dùng chung chỉ số (001/002/...) cho cả ảnh và audio.')
    if len(set(im_ids)) != len(im_ids) or len(set(au_ids)) != len(au_ids):
        raise ValueError('Có chỉ số trùng ở thư mục ảnh hoặc audio. Mỗi chỉ số phải duy nhất.')
    idx_audio = dict(zip(au_ids, audios))
    missing = sorted(set(im_ids) - set(au_ids))
    extra = sorted(set(au_ids) - set(im_ids))
    if missing or extra:
        raise ValueError(f'Không khớp chỉ số; thiếu audio {missing[:25]}, audio thừa {extra[:25]}. Không ghép theo vị trí để tránh sai nội dung.')
    return [(p, idx_audio[i]) for p, i in zip(images, im_ids)], 'numeric-strict'


def file_signature(path):
    p = Path(path).resolve()
    st = p.stat()
    return [str(p), st.st_size, st.st_mtime_ns]


def job_identity(pairs, output, fps, w, h, effects, intensity):
    obj = {
        'format': 2,
        'sources': [[file_signature(img), file_signature(aud)] for img, aud in pairs],
        'output': str(Path(output).resolve()),
        'fps': fps, 'w': w, 'h': h, 'effects': effects,
        'intensity': intensity,
    }
    encoded = json.dumps(obj, ensure_ascii=False, sort_keys=True).encode('utf-8')
    return hashlib.sha256(encoded).hexdigest()[:20], obj


def _hidden_kwargs():
    if os.name != 'nt':
        return {}
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = subprocess.SW_HIDE
    return {'startupinfo': si, 'creationflags': getattr(subprocess, 'CREATE_NO_WINDOW', 0)}


def _check_cancel(event):
    if event is not None and event.is_set():
        raise JobCancelled('Đã hủy theo yêu cầu. Các segment đã hoàn thành vẫn nằm trong cache.')


def build_gapless_master_audio(pairs, dest, fps, *, ffmpeg=None, log=None,
                               progress=None, cancel_event=None):
    """Stream-decode each audio and encode one continuous FLAC, saving sample counts.

    Frame boundaries are rounded from cumulative *decoded* PCM sample counts,
    so a batch of 100 clips does not accumulate a 100-frame duration error.
    No 100 separate AAC encoder padding segments are introduced.
    """
    ffmpeg = ffmpeg or find_ffmpeg()
    dest = Path(dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    temp = dest.with_name(dest.stem + '.__working.flac')
    if temp.exists():
        temp.unlink()
    command = [ffmpeg, '-y', '-hide_banner', '-loglevel', 'error',
               '-f', 's16le', '-ar', str(SAMPLE_RATE), '-ac', str(CHANNELS),
               '-i', 'pipe:0', '-map', '0:a:0', '-c:a', 'flac',
               '-compression_level', '3', str(temp)]
    encoder = subprocess.Popen(command, stdin=subprocess.PIPE, stderr=subprocess.PIPE,
                               stdout=subprocess.DEVNULL, **_hidden_kwargs())
    timings = []
    total_samples = 0
    try:
        for i, (_, audio) in enumerate(pairs):
            _check_cancel(cancel_event)
            command_in = [ffmpeg, '-hide_banner', '-loglevel', 'error', '-i', str(audio),
                          '-map', '0:a:0', '-vn', '-ac', str(CHANNELS),
                          '-ar', str(SAMPLE_RATE), '-c:a', 'pcm_s16le',
                          '-f', 's16le', 'pipe:1']
            decoder = subprocess.Popen(command_in, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE, **_hidden_kwargs())
            size = 0
            try:
                while True:
                    _check_cancel(cancel_event)
                    chunk = decoder.stdout.read(1024 * 256)
                    if not chunk:
                        break
                    if encoder.poll() is not None:
                        raise RuntimeError('FFmpeg FLAC master dừng bất ngờ.')
                    encoder.stdin.write(chunk)
                    size += len(chunk)
                err = decoder.stderr.read().decode('utf-8', 'replace')
                if decoder.wait() != 0:
                    raise RuntimeError(f'Audio {i+1:04d} không giải mã được: {audio.name}\n{err[-1200:]}')
            finally:
                if decoder.poll() is None:
                    decoder.kill(); decoder.communicate()
                if decoder.stdout: decoder.stdout.close()
                if decoder.stderr: decoder.stderr.close()
            if size == 0 or size % BYTES_PER_SAMPLE_FRAME:
                raise RuntimeError(f'Audio rỗng hoặc PCM không hợp lệ: {audio.name}')
            samples = size // BYTES_PER_SAMPLE_FRAME
            start_samples = total_samples
            total_samples += samples
            start_frame = (start_samples * fps + SAMPLE_RATE // 2) // SAMPLE_RATE
            end_frame = (total_samples * fps + SAMPLE_RATE // 2) // SAMPLE_RATE
            frames = end_frame - start_frame
            if frames < 1:
                raise ValueError(f'Audio {audio.name} quá ngắn (<1 frame @ {fps} FPS).')
            timings.append({'index': i+1, 'audio': str(audio), 'samples': samples,
                            'start_frame': start_frame, 'end_frame': end_frame,
                            'frames': frames, 'start': start_frame/fps,
                            'end': end_frame/fps, 'duration': frames/fps,
                            'source_duration': samples/SAMPLE_RATE})
            if progress: progress(i+1, len(pairs))
            if log: log(f'[AUDIO] {i+1:04d}/{len(pairs)} {audio.name}: {samples/SAMPLE_RATE:.3f}s → {frames} frame')
        encoder.stdin.close()
        err = encoder.stderr.read().decode('utf-8', 'replace')
        if encoder.wait() != 0 or not temp.is_file() or temp.stat().st_size <= 0:
            raise RuntimeError('Không tạo được audio master FLAC:\n' + err[-1400:])
        audio_info = probe_media(temp)
        if not audio_info.get('has_audio'):
            raise RuntimeError('Không xác minh được audio master FLAC.')
        os.replace(temp, dest)
        if log:
            log(f'[AUDIO MASTER] {len(pairs)} đoạn, {total_samples/SAMPLE_RATE:.6f}s, {timings[-1]["end_frame"]} frames, {dest.name}')
        return timings
    except BaseException:
        if encoder.poll() is None:
            encoder.kill()
            try: encoder.communicate(timeout=5)
            except Exception: pass
        if temp.exists():
            try: temp.unlink()
            except OSError: pass
        raise
    finally:
        for stream in (encoder.stdin, encoder.stderr):
            try: stream.close()
            except Exception: pass


def assert_segment_video(path, expected_frames, expected_fps, width, height):
    """Strong cache gate; refuses wrong frames, fps or output resolution."""
    import shutil
    from common import run_process
    path = Path(path)
    if not path.is_file() or path.stat().st_size < 200:
        raise ValueError(f'Không có segment: {path}')
    ffmpeg = Path(find_ffmpeg())
    ffprobe = ffmpeg.with_name('ffprobe.exe' if os.name == 'nt' else 'ffprobe')
    probe = str(ffprobe) if ffprobe.is_file() else shutil.which('ffprobe')
    if not probe:
        # A portable bundled imageio ffmpeg may not ship ffprobe. Decode every
        # frame in FFmpeg's progress output and verify the expected count;
        # inspect stream metadata for dimensions and nominal FPS.
        import re
        from common import probe_media
        media = probe_media(path)
        text = media.get('raw','')
        video_line = next((line for line in text.splitlines() if 'Video:' in line and 'Stream' in line), '')
        dims = re.search(r'(?<!\d)(\d{2,5})x(\d{2,5})(?!\d)',video_line)
        if not dims or (int(dims.group(1)),int(dims.group(2))) != (width,height):
            raise ValueError('Segment sai độ phân giải hoặc FFmpeg không đọc được kích thước.')
        rate = re.search(r'\b([0-9.]+) fps\b',video_line)
        if not rate or abs(float(rate.group(1))-expected_fps)>0.01:
            raise ValueError('Segment sai FPS hoặc FFmpeg không đọc được FPS.')
        result = run_process([str(ffmpeg),'-nostats','-v','error','-i',str(path),'-map','0:v:0',
                              '-f','null','-','-progress','pipe:1'],timeout=180)
        if result.returncode:
            raise ValueError('Không giải mã được segment video: '+result.stderr[-500:])
        frames = re.findall(r'(?m)^frame=(\d+)',result.stdout)
        if not frames or int(frames[-1])!=expected_frames:
            raise ValueError(f'Không khớp số frame: {frames[-1] if frames else "?"} != {expected_frames}')
        return True
    r = run_process([probe, '-v', 'error', '-select_streams', 'v:0',
                     '-show_entries', 'stream=width,height,nb_frames,avg_frame_rate',
                     '-of', 'json', str(path)], timeout=45)
    if r.returncode:
        raise ValueError(f'Segment không đọc được: {path}')
    streams = json.loads(r.stdout or '{}').get('streams') or []
    if not streams:
        raise ValueError(f'Segment thiếu stream: {path}')
    s = streams[0]
    rate = s.get('avg_frame_rate', '0/1').split('/')
    actual_fps = float(rate[0]) / float(rate[1]) if len(rate) == 2 and int(rate[1]) else 0
    if (s.get('nb_frames') in (None, 'N/A', '') or int(s['nb_frames']) != int(expected_frames)
            or int(s.get('width') or 0) != width or int(s.get('height') or 0) != height
            or abs(actual_fps - expected_fps) > 0.001):
        raise ValueError(f'Cache segment sai frame/resolution/fps: {path.name}')
    return True
