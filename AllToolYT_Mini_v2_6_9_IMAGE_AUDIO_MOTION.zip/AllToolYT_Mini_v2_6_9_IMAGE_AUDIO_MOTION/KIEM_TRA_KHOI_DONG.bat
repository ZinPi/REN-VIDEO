﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
where py >nul 2>nul && set "PY=py -3"
echo === PYTHON ===
%PY% --version
echo.
echo === TKINTER ===
%PY% -c "import tkinter; print('tkinter OK - TkVersion', tkinter.TkVersion)"
echo.
echo === IMPORT TOOL ===
%PY% -c "import app; print('app import OK - version', app.APP_VERSION)"
echo.
echo === THU GUI ===
%PY% bootstrap.py
set E=%ERRORLEVEL%
echo.
echo Exit code: %E%
if exist STARTUP_ERROR.log (
  echo === STARTUP_ERROR.log ===
  type STARTUP_ERROR.log
)
pause
