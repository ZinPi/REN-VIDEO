﻿@echo off
cd /d "%~dp0"
start "" /b wscript.exe "%~dp0CHAY_TOOL_KHONG_CMD.vbs"
exit /b 0
