import json
import threading
from dataclasses import asdict
from datetime import datetime
from pathlib import Path

import customtkinter as ctk
from tkinter import filedialog, messagebox

from common import sanitize_filename
from rename_module import RenameFrame
from video_module import VideoFrame
from youtube_engine import COMMON_LANGUAGES, LANG_LABEL_TO_CODE, WHISPER_QUALITY, fetch_transcript, make_plain_text, make_srt

APP_VERSION='2.6.9'

ctk.set_appearance_mode('dark')
ctk.set_default_color_theme('blue')


class YoutubeFrame(ctk.CTkFrame):
    def __init__(self, master, on_back):
        super().__init__(master, fg_color='#2b2b2b')
        self.on_back=on_back
        self.current_segments=[]; self.current_meta={}; self.current_text=''; self.busy=False
        self._build()

    def _build(self):
        top=ctk.CTkFrame(self,fg_color='#242424',height=54,corner_radius=0)
        top.pack(fill='x'); top.pack_propagate(False)
        ctk.CTkButton(top,text='← Quay Lại Dashboard',width=160,fg_color='#d9534f',hover_color='#c64541',command=self.on_back).pack(side='left',padx=12,pady=10)
        ctk.CTkLabel(top,text='LẤY NỘI DUNG YT',font=('Segoe UI',18,'bold')).pack(side='left',padx=10)
        ctk.CTkButton(top,text='HƯỚNG DẪN SỬ DỤNG',width=160,fg_color='#f06c32',hover_color='#d85a25',command=self.show_help).pack(side='right',padx=12,pady=10)

        body=ctk.CTkFrame(self,fg_color='#2b2b2b')
        body.pack(fill='both',expand=True,padx=8,pady=8)
        ctk.CTkLabel(body,text='Lấy Subtitle YouTube (Đa ngôn ngữ)',font=('Segoe UI',14,'bold'),text_color='#e9e9e9').pack(pady=(8,14))
        row=ctk.CTkFrame(body,fg_color='transparent'); row.pack(fill='x',padx=20)
        ctk.CTkLabel(row,text='URL YouTube:',font=('Segoe UI',12,'bold'),width=110,anchor='w').pack(side='left')
        self.url=ctk.StringVar()
        ctk.CTkEntry(row,textvariable=self.url,placeholder_text='Ví dụ: https://www.youtube.com/watch?v=...',height=34).pack(side='left',fill='x',expand=True,padx=(0,10))
        self.lang=ctk.StringVar(value=COMMON_LANGUAGES[0][0])
        ctk.CTkOptionMenu(row,values=[x[0] for x in COMMON_LANGUAGES],variable=self.lang,width=220,fg_color='#e88724',button_color='#d46f0e').pack(side='left')

        stt=ctk.CTkFrame(body,fg_color='transparent'); stt.pack(fill='x',padx=20,pady=(8,0))
        self.audio_fallback=ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(stt,text='Không có subtitle → tự tải audio và nghe bằng Whisper',variable=self.audio_fallback,text_color='#f1f1f1').pack(side='left')
        self.whisper_quality=ctk.StringVar(value='Cân bằng (medium)')
        ctk.CTkLabel(stt,text='Mức nhận dạng:',text_color='#c7c7c7').pack(side='left',padx=(20,6))
        ctk.CTkOptionMenu(stt,values=WHISPER_QUALITY,variable=self.whisper_quality,width=190,fg_color='#6f42c1',button_color='#59359c').pack(side='left')
        ctk.CTkLabel(stt,text='GPU CUDA → GPU INT8 → CPU INT8 tự động',text_color='#8fceff').pack(side='left',padx=12)

        actions=ctk.CTkFrame(body,fg_color='transparent'); actions.pack(pady=12)
        self.fetch_btn=ctk.CTkButton(actions,text='LẤY NỘI DUNG',fg_color='#2878ad',hover_color='#216892',command=self.fetch)
        self.fetch_btn.pack(side='left',padx=5)
        self.save_btn=ctk.CTkButton(actions,text='LƯU DATA (SRT, JSON, TXT)',fg_color='#2cad65',hover_color='#248f55',command=self.save)
        self.save_btn.pack(side='left',padx=5)

        self.text=ctk.CTkTextbox(body,fg_color='#1d2220',border_color='#74818b',border_width=1,text_color='#f1f1f1',font=('Segoe UI',13),wrap='word')
        self.text.pack(fill='both',expand=True,padx=20,pady=(0,10))

        bottom=ctk.CTkFrame(body,fg_color='transparent'); bottom.pack(fill='x',padx=20,pady=(0,4))
        self.status=ctk.StringVar(value='Sẵn sàng.')
        ctk.CTkLabel(bottom,textvariable=self.status,text_color='#c7c7c7').pack(side='left')
        ctk.CTkButton(bottom,text='SAO CHÉP TẤT CẢ',width=140,fg_color='#3d617b',command=self.copy_all).pack(side='right')

    def set_busy(self,b,status=None):
        self.busy=b; state='disabled' if b else 'normal'
        self.fetch_btn.configure(state=state); self.save_btn.configure(state=state)
        if status: self.status.set(status)

    def fetch(self):
        if self.busy:return
        url=self.url.get().strip()
        if not url: messagebox.showwarning('Thiếu URL','Hãy dán URL YouTube vào ô phía trên.'); return
        code=LANG_LABEL_TO_CODE.get(self.lang.get(),'auto')
        allow_audio=bool(self.audio_fallback.get())
        quality=self.whisper_quality.get()
        self.set_busy(True,'Đang lấy transcript/subtitle từ YouTube...')
        self.text.delete('1.0','end'); self.text.insert('1.0','Đang xử lý...')
        def status_cb(msg):
            self.after(0,lambda m=msg:self.status.set(m))
        def worker():
            try:
                segs,meta=fetch_transcript(url,code,allow_audio_fallback=allow_audio,whisper_quality=quality,status_callback=status_cb); plain=make_plain_text(segs)
                if not plain.strip(): raise RuntimeError('Transcript lấy được nhưng nội dung trống.')
                self.after(0,lambda:self._success(segs,meta,plain))
            except Exception as e:
                detail=str(e); self.after(0,lambda:self._error(detail))
        threading.Thread(target=worker,daemon=True).start()

    def _success(self,segs,meta,plain):
        self.current_segments=segs; self.current_meta=meta; self.current_text=plain
        self.text.delete('1.0','end'); self.text.insert('1.0',plain)
        if meta.get('source') == 'faster-whisper':
            engine=meta.get('transcription_engine','?'); model=meta.get('whisper_model','?')
            self.set_busy(False,f"Đã nhận dạng {len(segs)} đoạn • {meta.get('language_code','?')} • {engine} • Whisper {model}")
        else:
            gen=meta.get('is_generated'); kind='tự động' if gen is True else ('thủ công' if gen is False else 'không rõ')
            self.set_busy(False,f"Đã lấy {len(segs)} đoạn • {meta.get('language_code','?')} • phụ đề {kind} • nguồn: {meta.get('source','?')}")

    def _error(self,detail):
        self.current_segments=[]; self.current_meta={}; self.current_text=''
        self.text.delete('1.0','end'); self.text.insert('1.0','Không lấy được nội dung.\n\n'+detail)
        self.set_busy(False,'Lỗi khi lấy nội dung.'); messagebox.showerror('Không lấy được nội dung',detail)

    def copy_all(self):
        content=self.text.get('1.0','end-1c').strip()
        if not content:return
        self.clipboard_clear(); self.clipboard_append(content); self.update(); self.status.set(f'Đã sao chép {len(content):,} ký tự.')

    def save(self):
        if not self.current_segments: messagebox.showwarning('Chưa có dữ liệu','Hãy bấm LẤY NỘI DUNG trước.'); return
        folder=filedialog.askdirectory(title='Chọn thư mục lưu TXT / SRT / JSON')
        if not folder:return
        meta=dict(self.current_meta); vid=meta.get('video_id') or 'youtube'; title=meta.get('title') or vid
        base=sanitize_filename(f'{title}_{vid}' if title!=vid else vid); out=Path(folder)
        txt=out/f'{base}.txt'; srt=out/f'{base}.srt'; js=out/f'{base}.json'
        plain=self.current_text or make_plain_text(self.current_segments)
        payload={'meta':{**meta,'saved_at':datetime.now().isoformat(timespec='seconds'),'app':'AllToolYoutube Mini','app_version':APP_VERSION},'segments':[asdict(s) for s in self.current_segments],'plain_text':plain}
        txt.write_text(plain,encoding='utf-8-sig'); srt.write_text(make_srt(self.current_segments),encoding='utf-8-sig'); js.write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf-8')
        self.status.set(f'Đã lưu: {txt.name}, {srt.name}, {js.name}'); messagebox.showinfo('Đã lưu',f'Đã lưu 3 file:\n\n{txt}\n{srt}\n{js}')

    def show_help(self):
        messagebox.showinfo('Hướng dẫn','1. Dán URL YouTube.\n2. Chọn ngôn ngữ hoặc để Ngôn ngữ gốc.\n3. Mặc định bật fallback Whisper.\n4. Bấm LẤY NỘI DUNG.\n5. Tool thử subtitle trước; nếu không có sẽ tải riêng audio và nhận dạng giọng nói.\n6. Có thể sao chép hoặc lưu TXT/SRT/JSON.\n\nWhisper tự thử GPU CUDA FP16 → GPU INT8 → CPU INT8. Lần đầu dùng một mức nhận dạng có thể phải tải model. Nếu video yêu cầu đăng nhập, có thể đặt cookies.txt cạnh tool.')


class Dashboard(ctk.CTkFrame):
    def __init__(self,master,on_open):
        super().__init__(master,fg_color='#08aaa6')
        self.on_open=on_open; self._build()
    def _build(self):
        top=ctk.CTkFrame(self,fg_color='#222222',height=48,corner_radius=0); top.pack(fill='x'); top.pack_propagate(False)
        ctk.CTkLabel(top,text=f'All-Tool-Youtube Mini  •  v{APP_VERSION}',font=('Segoe UI',14,'bold')).pack(side='left',padx=12)
        ctk.CTkLabel(top,text='3 công cụ tích hợp',text_color='#aaaaaa').pack(side='right',padx=12)
        cards=ctk.CTkFrame(self,fg_color='transparent'); cards.pack(fill='x',padx=24,pady=26)
        
        for _c in (0,1,2): cards.grid_columnconfigure(_c,weight=1,uniform='cards')
        self._card(cards,0,'ABC 123','ĐỔI TÊN FILE','#f39c2b','rename')
        self._card(cards,1,'🎬','TẠO VIDEO','#f39c2b','video')
        self._card(cards,2,'💬','LẤY NỘI DUNG YT','#f39c2b','youtube')
    def _card(self,parent,col,icon,title,accent,key):
        card=ctk.CTkFrame(parent,fg_color='#2b2b2b',corner_radius=8,height=170)
        card.grid(row=0,column=col,sticky='ew',padx=8); card.grid_propagate(False)
        head=ctk.CTkButton(card,text=icon,height=105,corner_radius=16,fg_color=accent,hover_color='#e68916',text_color='white',font=('Segoe UI',32,'bold'),command=lambda:self.on_open(key))
        head.pack(fill='x',padx=54,pady=(10,4))
        btn=ctk.CTkButton(card,text=title,fg_color='transparent',hover_color='#393939',text_color='#ffcf38',font=('Segoe UI',14,'bold'),command=lambda:self.on_open(key))
        btn.pack(fill='x',padx=20,pady=(0,8))


class MainApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(f'All-Tool-Youtube Mini v{APP_VERSION}')
        self.geometry('1500x900'); self.minsize(1100,700)
        self.container=ctk.CTkFrame(self,fg_color='#111111',corner_radius=0); self.container.pack(fill='both',expand=True)
        self.frames={}
        self.frames['dashboard']=Dashboard(self.container,self.open_tool)
        self.frames['rename']=RenameFrame(self.container,self.show_dashboard)
        self.frames['video']=VideoFrame(self.container,self.show_dashboard)
        self.frames['youtube']=YoutubeFrame(self.container,self.show_dashboard)
        for f in self.frames.values(): f.place(relx=0,rely=0,relwidth=1,relheight=1)
        self.show_dashboard()
    def show_dashboard(self): self.frames['dashboard'].lift()
    def open_tool(self,key): self.frames[key].lift()


def run_app():
    app = MainApp()
    # Đưa cửa sổ lên trước khi mở từ BAT/CMD trên Windows.
    def _show_front():
        try:
            app.deiconify()
            app.lift()
            app.attributes('-topmost', True)
            app.focus_force()
            app.after(800, lambda: app.attributes('-topmost', False))
        except Exception:
            pass
    app.after(150, _show_front)
    app.mainloop()


if __name__=='__main__':
    run_app()
