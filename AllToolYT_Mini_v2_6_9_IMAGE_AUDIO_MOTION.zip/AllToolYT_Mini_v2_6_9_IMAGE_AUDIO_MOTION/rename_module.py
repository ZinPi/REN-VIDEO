from pathlib import Path
import os
import re
import stat
import uuid
import customtkinter as ctk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
from common import natural_key

SORT_MODES = ["Theo vần (A-Z)", "Theo vần (Z-A)", "Theo số (tăng)", "Theo số (giảm)"]
PARITY = ["Chẵn", "Lẻ"]

SYSTEM_JUNK_NAMES = {
    'thumbs.db', 'ehthumbs.db', 'desktop.ini', '.ds_store'
}


def is_system_junk(path: Path) -> bool:
    """Return True for OS-generated junk/hidden/system files that must never be renamed.

    On Windows, rename preserves Hidden/System attributes, so this also catches a
    previously renamed Thumbs.db such as 030.db.
    """
    name = path.name.lower()
    if name in SYSTEM_JUNK_NAMES or path.name.startswith('.'):
        return True
    try:
        st = path.stat()
        attrs = getattr(st, 'st_file_attributes', 0)
        hidden = getattr(stat, 'FILE_ATTRIBUTE_HIDDEN', 0x2)
        system = getattr(stat, 'FILE_ATTRIBUTE_SYSTEM', 0x4)
        if attrs & (hidden | system):
            return True
    except Exception:
        pass
    return False


def is_cleanup_junk(path: Path) -> bool:
    """Conservative cleanup: known junk names, plus hidden/system .db/.ini files."""
    name = path.name.lower()
    if name in SYSTEM_JUNK_NAMES:
        return True
    if path.suffix.lower() not in {'.db', '.ini'}:
        return False
    try:
        st = path.stat()
        attrs = getattr(st, 'st_file_attributes', 0)
        hidden = getattr(stat, 'FILE_ATTRIBUTE_HIDDEN', 0x2)
        system = getattr(stat, 'FILE_ATTRIBUTE_SYSTEM', 0x4)
        return bool(attrs & (hidden | system))
    except Exception:
        return False



def numeric_key(p: Path):
    nums = re.findall(r"\d+", p.stem)
    return (int(nums[-1]) if nums else 10**18, natural_key(p))


def rename_batch_transaction(pairs):
    """Preflight every target; commit in two phases; rollback ALL on failure."""
    items=[(Path(old),Path(new)) for old,new in pairs if Path(old)!=Path(new)]
    if not items: return 0
    old_ids=[str(old.resolve()).casefold() for old,_ in items]
    target_ids=[str(new.absolute()).casefold() for _,new in items]
    if len(set(old_ids))!=len(old_ids) or len(set(target_ids))!=len(target_ids):
        raise ValueError('Danh sách nguồn hoặc đích có tên trùng nhau.')
    source_set=set(old_ids)
    for old,new in items:
        if not old.is_file():
            raise FileNotFoundError(f'File nguồn bị mất: {old.name}')
        if new.parent.resolve()!=old.parent.resolve():
            raise ValueError('Đổi tên hàng loạt chỉ hỗ trợ cùng một thư mục.')
        # Also check targets that are directories or dangling symlinks.
        if (new.exists() or new.is_symlink()) and str(new.absolute()).casefold() not in source_set:
            raise FileExistsError(f'Tên đích đã được sử dụng: {new.name}')
    journal=[]
    try:
        for old,new in items:
            tmp=old.with_name(f'.__rename_tmp_{uuid.uuid4().hex}{old.suffix}')
            if tmp.exists() or tmp.is_symlink():
                raise FileExistsError(f'Tên tạm bị trùng: {tmp.name}')
            old.rename(tmp)
            journal.append({'old':old,'tmp':tmp,'new':new,'committed':False})
        for rec in journal:
            new=rec['new']
            if new.exists() or new.is_symlink():
                raise FileExistsError(f'File đích đã tồn tại: {new.name}')
            rec['tmp'].rename(new)
            rec['committed']=True
        return len(items)
    except BaseException as error:
        recovery_errors=[]
        # First undo any committed final paths back to their unique temp path.
        for rec in reversed(journal):
            if rec['committed']:
                try: rec['new'].rename(rec['tmp']); rec['committed']=False
                except OSError as e: recovery_errors.append(str(e))
        # Then restore original names; conflicts between swaps are now absent.
        for rec in reversed(journal):
            if not rec['committed'] and rec['tmp'].exists():
                try: rec['tmp'].rename(rec['old'])
                except OSError as e: recovery_errors.append(str(e))
        if recovery_errors:
            raise RuntimeError(f'{error}\nROLLBACK KHÔNG ĐẦY ĐỦ: {recovery_errors}\n'
                               'Giữ nguyên các file còn lại và kiểm tra tên tạm .__rename_tmp_.') from error
        raise


class RenameFrame(ctk.CTkFrame):
    def __init__(self, master, on_back):
        super().__init__(master, fg_color="#202020")
        self.on_back = on_back
        self.folder = None
        self.destination = None
        self.preview_image = None
        self._build()

    def _build(self):
        top = ctk.CTkFrame(self, fg_color="#242424", height=54, corner_radius=0)
        top.pack(fill="x")
        top.pack_propagate(False)
        ctk.CTkButton(top, text="← Quay Lại Dashboard", width=160, fg_color="#d9534f", hover_color="#c64541", command=self.on_back).pack(side="left", padx=12, pady=10)
        ctk.CTkLabel(top, text="ĐỔI TÊN FILE", font=("Segoe UI", 18, "bold")).pack(side="left", padx=10)

        body = ctk.CTkFrame(self, fg_color="#202020")
        body.pack(fill="both", expand=True, padx=14, pady=14)
        body.grid_columnconfigure(0, weight=3)
        body.grid_columnconfigure(1, weight=2)
        body.grid_rowconfigure(0, weight=1)

        left = ctk.CTkScrollableFrame(body, fg_color="#292929", corner_radius=10)
        left.grid(row=0, column=0, sticky="nsew", padx=(0,8))
        right = ctk.CTkFrame(body, fg_color="#292929", corner_radius=10)
        right.grid(row=0, column=1, sticky="nsew", padx=(8,0))

        ctk.CTkLabel(left, text="THIẾT LẬP ĐỔI TÊN", text_color="#ffcf4a", font=("Segoe UI", 15, "bold")).pack(anchor="w", padx=14, pady=(14,8))

        self.folder_var = ctk.StringVar()
        self._path_row(left, "Thư mục nguồn:", self.folder_var, self.select_folder)

        row = ctk.CTkFrame(left, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=6)
        ctk.CTkLabel(row, text="Kiểu sắp xếp:", width=180, anchor="w").pack(side="left")
        self.sort_var = ctk.StringVar(value=SORT_MODES[0])
        ctk.CTkOptionMenu(row, values=SORT_MODES, variable=self.sort_var, command=lambda _: self.refresh()).pack(side="left", fill="x", expand=True)

        self.base_var = ctk.StringVar(value="")
        self.sep_var = ctk.StringVar(value="_")
        self.ext_var = ctk.StringVar(value="")
        self.start_var = ctk.StringVar(value="1")
        self.pad_var = ctk.StringVar(value="3")
        self._entry_row(left, "Tên mới (có thể để trống):", self.base_var, "VD: BG")
        self._entry_row(left, "Ký tự phân cách:", self.sep_var, "VD: _")
        self._entry_row(left, "Đuôi file:", self.ext_var, "VD: .jpg; để trống = giữ đuôi cũ")
        self._entry_row(left, "Số bắt đầu:", self.start_var, "VD: 1")
        self._entry_row(left, "Zero padding:", self.pad_var, "VD: 3 → 001")

        btns = ctk.CTkFrame(left, fg_color="transparent")
        btns.pack(fill="x", padx=14, pady=10)
        ctk.CTkButton(btns, text="LÀM MỚI DANH SÁCH", fg_color="#3d617b", command=self.refresh).pack(side="left", padx=(0,6))
        ctk.CTkButton(btns, text="XEM TRƯỚC", fg_color="#2878ad", command=self.preview_names).pack(side="left", padx=6)
        ctk.CTkButton(btns, text="ĐỔI TÊN", fg_color="#2cad65", command=self.rename_files).pack(side="left", padx=6)

        cleanup_row = ctk.CTkFrame(left, fg_color="transparent")
        cleanup_row.pack(fill="x", padx=14, pady=(0,8))
        ctk.CTkButton(cleanup_row, text="DỌN FILE RÁC HỆ THỐNG", fg_color="#8a5a2b", hover_color="#70481f", command=self.cleanup_system_junk).pack(side="left")
        ctk.CTkLabel(cleanup_row, text="  Tự bỏ qua Thumbs.db, desktop.ini và file Hidden/System.", text_color="#999999").pack(side="left")

        ctk.CTkFrame(left, height=1, fg_color="#4a4a4a").pack(fill="x", padx=14, pady=12)
        ctk.CTkLabel(left, text="XỬ LÝ FILE CHẴN / LẺ", text_color="#ffcf4a", font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=14, pady=(0,8))
        row = ctk.CTkFrame(left, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=5)
        ctk.CTkLabel(row, text="Chọn:", width=180, anchor="w").pack(side="left")
        self.parity_var = ctk.StringVar(value="Chẵn")
        ctk.CTkOptionMenu(row, values=PARITY, variable=self.parity_var).pack(side="left", fill="x", expand=True)
        self.dest_var = ctk.StringVar()
        self._path_row(left, "Thư mục đích:", self.dest_var, self.select_destination)
        row = ctk.CTkFrame(left, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=8)
        ctk.CTkButton(row, text="XÓA FILE CHẴN/LẺ", fg_color="#d9534f", hover_color="#b6403c", command=self.delete_by_parity).pack(side="left", padx=(0,8))
        ctk.CTkButton(row, text="CHUYỂN CHẴN/LẺ SANG THƯ MỤC", fg_color="#4ba3b8", command=self.move_by_parity).pack(side="left")

        # Right: preview + list
        ctk.CTkLabel(right, text="XEM TRƯỚC", text_color="#ffcf4a", font=("Segoe UI", 15, "bold")).pack(pady=(14,8))
        self.preview_label = ctk.CTkLabel(right, text="Chọn một file ảnh để xem", width=420, height=250, fg_color="#1c1c1c", corner_radius=8)
        self.preview_label.pack(fill="x", padx=12, pady=6)
        self.info_label = ctk.CTkLabel(right, text="Chưa chọn thư mục.", text_color="#bbbbbb")
        self.info_label.pack(padx=12, pady=(0,8))
        self.filebox = ctk.CTkTextbox(right, fg_color="#181818", font=("Consolas", 12))
        self.filebox.pack(fill="both", expand=True, padx=12, pady=(0,12))
        self.filebox.bind("<ButtonRelease-1>", self._click_list)

    def _path_row(self, parent, label, variable, command):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=6)
        ctk.CTkLabel(row, text=label, width=180, anchor="w").pack(side="left")
        ctk.CTkEntry(row, textvariable=variable).pack(side="left", fill="x", expand=True, padx=(0,6))
        ctk.CTkButton(row, text="Chọn...", width=82, command=command).pack(side="left")

    def _entry_row(self, parent, label, variable, placeholder=""):
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x", padx=14, pady=6)
        ctk.CTkLabel(row, text=label, width=180, anchor="w").pack(side="left")
        ctk.CTkEntry(row, textvariable=variable, placeholder_text=placeholder).pack(side="left", fill="x", expand=True)

    def select_folder(self):
        p = filedialog.askdirectory(title="Chọn thư mục nguồn")
        if p:
            self.folder = Path(p)
            self.folder_var.set(p)
            self.refresh()

    def select_destination(self):
        p = filedialog.askdirectory(title="Chọn thư mục đích")
        if p:
            self.destination = Path(p)
            self.dest_var.set(p)

    def get_sorted_items(self):
        folder = Path(self.folder_var.get().strip())
        if not folder.is_dir():
            return []
        items = [p for p in folder.iterdir() if p.is_file() and not is_system_junk(p)]
        mode = self.sort_var.get()
        if mode == "Theo vần (A-Z)":
            return sorted(items, key=natural_key)
        if mode == "Theo vần (Z-A)":
            return sorted(items, key=natural_key, reverse=True)
        if mode == "Theo số (tăng)":
            return sorted(items, key=numeric_key)
        return sorted(items, key=numeric_key, reverse=True)

    def refresh(self):
        items = self.get_sorted_items()
        self.filebox.configure(state="normal")
        self.filebox.delete("1.0", "end")
        for i, p in enumerate(items, 1):
            self.filebox.insert("end", f"{i:04d}  {p.name}\n")
        self.filebox.configure(state="disabled")
        self.info_label.configure(text=f"{len(items)} file" if items else "Chưa có file / chưa chọn thư mục")

    def _planned_names(self):
        items = self.get_sorted_items()
        if not items:
            raise ValueError("Không tìm thấy file trong thư mục nguồn.")
        try:
            start = int(self.start_var.get().strip())
            pad = int(self.pad_var.get().strip() or "0")
            if pad < 0:
                raise ValueError
        except Exception:
            raise ValueError("Số bắt đầu và Zero padding phải là số nguyên hợp lệ.")
        base = self.base_var.get().strip()
        sep = self.sep_var.get()
        ext_override = self.ext_var.get().strip()
        if ext_override and not ext_override.startswith("."):
            raise ValueError("Đuôi file phải bắt đầu bằng dấu chấm, ví dụ .jpg")
        result = []
        for offset, p in enumerate(items):
            n = start + offset
            num = str(n).zfill(pad) if pad else str(n)
            stem = f"{base}{sep if base else ''}{num}" if base else num
            ext = ext_override or p.suffix
            result.append((p, p.with_name(stem + ext)))
        return result

    def preview_names(self):
        try:
            pairs = self._planned_names()
        except Exception as e:
            messagebox.showerror("Lỗi", str(e)); return
        self.filebox.configure(state="normal")
        self.filebox.delete("1.0", "end")
        for i, (old, new) in enumerate(pairs, 1):
            self.filebox.insert("end", f"{i:04d}  {old.name}  →  {new.name}\n")
        self.filebox.configure(state="disabled")
        self.info_label.configure(text=f"Xem trước {len(pairs)} file")

    def rename_files(self):
        try:
            pairs=self._planned_names()
            changed=rename_batch_transaction(pairs)
        except Exception as e:
            messagebox.showerror('Đổi tên thất bại (đã rollback nếu có thể)',str(e))
            self.refresh()
            return
        messagebox.showinfo('Thành công',f'Đã đổi tên {changed} file, không ghi đè file cũ.')
        self.refresh()

    def cleanup_system_junk(self):
        folder = Path(self.folder_var.get().strip())
        if not folder.is_dir():
            messagebox.showwarning("Thiếu thư mục", "Hãy chọn thư mục nguồn trước.")
            return
        junk = [p for p in folder.iterdir() if p.is_file() and is_cleanup_junk(p)]
        if not junk:
            messagebox.showinfo("Thông báo", "Không tìm thấy Thumbs.db / desktop.ini / file .db ẩn-hệ thống cần dọn.")
            return
        names = "\n".join(f"• {p.name}" for p in junk[:15])
        more = f"\n... và {len(junk)-15} file khác" if len(junk) > 15 else ""
        if not messagebox.askyesno("Xác nhận dọn file hệ thống", f"Tìm thấy {len(junk)} file rác hệ thống:\n\n{names}{more}\n\nXóa các file này?\n(Windows có thể tự tạo lại Thumbs.db sau này.)"):
            return
        errors=[]; deleted=0
        for p in junk:
            try:
                p.unlink(); deleted += 1
            except Exception as e:
                errors.append(f"{p.name}: {e}")
        self.refresh()
        if errors:
            messagebox.showwarning("Dọn file", f"Đã xóa {deleted}/{len(junk)} file.\n\n" + "\n".join(errors[:10]))
        else:
            messagebox.showinfo("Hoàn tất", f"Đã xóa {deleted} file rác hệ thống.")

    def _selected_by_parity(self):
        items = self.get_sorted_items()
        even = self.parity_var.get() == "Chẵn"
        return [p for i,p in enumerate(items,1) if (i % 2 == 0) == even]

    def delete_by_parity(self):
        targets = self._selected_by_parity()
        if not targets:
            messagebox.showinfo("Thông báo", "Không có file phù hợp."); return
        if not messagebox.askyesno("Xác nhận", f"Bạn có chắc muốn XÓA {len(targets)} file {self.parity_var.get().lower()}?"):
            return
        errors=[]
        for p in targets:
            try: p.unlink()
            except Exception as e: errors.append(f"{p.name}: {e}")
        self.refresh()
        if errors: messagebox.showwarning("Có lỗi", "\n".join(errors[:10]))
        else: messagebox.showinfo("Hoàn tất", f"Đã xóa {len(targets)} file.")

    def move_by_parity(self):
        targets = self._selected_by_parity()
        dest = Path(self.dest_var.get().strip())
        if not dest:
            return
        if not dest.exists():
            if messagebox.askyesno("Tạo thư mục", f"Thư mục đích chưa tồn tại. Tạo mới?\n{dest}"):
                dest.mkdir(parents=True, exist_ok=True)
            else: return
        src = Path(self.folder_var.get().strip()).resolve()
        if dest.resolve() == src:
            messagebox.showerror("Lỗi", "Thư mục đích phải khác thư mục nguồn."); return
        if not targets:
            messagebox.showinfo("Thông báo", "Không có file phù hợp."); return
        if not messagebox.askyesno("Xác nhận", f"Chuyển {len(targets)} file {self.parity_var.get().lower()} sang:\n{dest} ?"):
            return
        errors=[]
        for p in targets:
            dst = dest / p.name
            if dst.exists():
                errors.append(f"Đã tồn tại: {dst.name}"); continue
            try: p.replace(dst)
            except Exception as e: errors.append(f"{p.name}: {e}")
        self.refresh()
        if errors: messagebox.showwarning("Có lỗi", "\n".join(errors[:10]))
        else: messagebox.showinfo("Hoàn tất", f"Đã chuyển {len(targets)} file.")

    def _click_list(self, event=None):
        try:
            idx = self.filebox.index(f"@{event.x},{event.y}")
            line = int(idx.split('.')[0])
            items = self.get_sorted_items()
            if 1 <= line <= len(items):
                self.show_preview(items[line-1])
        except Exception:
            pass

    def show_preview(self, path: Path):
        if path.suffix.lower() not in {'.png','.jpg','.jpeg','.webp','.bmp','.gif'}:
            self.preview_label.configure(image=None, text=path.name)
            self.preview_image=None
            return
        try:
            im = Image.open(path).convert('RGB')
            im.thumbnail((520,250))
            self.preview_image = ImageTk.PhotoImage(im)
            self.preview_label.configure(image=self.preview_image, text="")
        except Exception:
            self.preview_label.configure(image=None, text=path.name)
