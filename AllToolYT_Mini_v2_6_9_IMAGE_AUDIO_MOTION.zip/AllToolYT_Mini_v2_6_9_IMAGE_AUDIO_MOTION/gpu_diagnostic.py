"""Standalone, read-only NVENC diagnostic. Does not touch project images/videos."""
from __future__ import annotations
import os
import re
import subprocess
import tempfile
from datetime import datetime
from pathlib import Path
from common import find_ffmpeg_candidates, run_process, app_dir


def capture(cmd, timeout=30):
    try:
        r=run_process(cmd, timeout=timeout)
        return f'Exit code: {r.returncode}\nSTDOUT:\n{r.stdout}\nSTDERR:\n{r.stderr}'
    except (OSError, subprocess.TimeoutExpired) as exc:
        return f'FAILED TO START: {exc}'


def main():
    lines=[
        'AllToolYT NVIDIA NVENC Diagnostic v2.6.6',
        'Generated: '+datetime.now().isoformat(timespec='seconds'),
        'No user image/SRT/video paths are accessed; test clips use a temporary folder.',
        'System: '+os.name,
    ]
    commands=[['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader']]
    if os.name=='nt':
        other=Path(os.environ.get('ProgramFiles','C:\\Program Files'))/'NVIDIA Corporation'/'NVSMI'/'nvidia-smi.exe'
        if other.is_file(): commands.append([str(other),'--query-gpu=name,driver_version','--format=csv,noheader'])
    for command in commands:
        lines += ['\n===== NVIDIA GPU/DRIVER =====', ' '.join(command), capture(command,20)]
    ffmpegs=find_ffmpeg_candidates()
    lines += [f'\nFFmpeg candidates: {len(ffmpegs)}']
    for candidate in ffmpegs:
        lines += [f'\n===== FFMPEG {candidate} =====']
        for args in (['-hide_banner','-version'], ['-hide_banner','-encoders']):
            raw=capture([candidate,*args],20)
            if args[-1]=='-encoders':
                # Save matching encoder rows while keeping the diagnostic compact.
                raw='\n'.join(line for line in raw.splitlines() if 'h264_nvenc' in line or 'hevc_nvenc' in line or 'libx264' in line or 'Exit code:' in line)
            lines += ['CMD: '+str(args), raw]
        profiles=(
            ('p4_constqp',['-c:v','h264_nvenc','-preset','p4','-rc','constqp','-qp','28']),
            ('medium_constqp',['-c:v','h264_nvenc','-preset','medium','-rc','constqp','-qp','28']),
            ('basic_compat',['-c:v','h264_nvenc']),
        )
        for label,args in profiles:
            with tempfile.TemporaryDirectory(prefix='alltool_nvenc_diagnostic_') as tmp:
                output=Path(tmp)/'test.mp4'
                cmd=[candidate,'-y','-hide_banner','-loglevel','verbose',
                     '-f','lavfi','-i','testsrc2=size=640x360:rate=60',
                     '-frames:v','12','-pix_fmt','yuv420p','-an',
                     *args,'-bf','0', '-f','mp4',str(output)]
                lines += [f'\n===== GPU TEST: {label} =====', ' '.join(cmd), capture(cmd,35)]
                if output.exists():
                    lines.append(f'Output size: {output.stat().st_size} bytes')
    report=app_dir()/('GPU_DIAGNOSTIC_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'.txt')
    report.write_text('\n'.join(lines),encoding='utf-8-sig')
    print('Diagnostic complete: '+str(report))
    print('Khong sua file du an. Neu GPU FAIL, gui file diagnostic de xem nguyen nhan goc.')


if __name__=='__main__':
    main()
