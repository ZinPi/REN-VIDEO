@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
where py >nul 2>nul && set "PY=py -3"
%PY% -m pip install --upgrade pip
if errorlevel 1 goto ERROR
%PY% -m pip install -r requirements.txt
if errorlevel 1 goto ERROR
echo.
echo DA CAI CAC THU VIEN CAN THIET.
pause
exit /b 0
:ERROR
echo CAI DAT THAT BAI - KIEM TRA PYTHON / MANG / QUYEN CAI DAT.
pause
exit /b 1
