"""Offline headless regression tests. Run: python TEST_ENGINE_QA.py"""
import json
import math
import os
import shutil
import subprocess
import tempfile
import threading
import wave
from unittest import mock
import video_module
from pathlib import Path

from PIL import Image
from common import probe_media, find_ffmpeg
from image_audio_engine import strict_pairs, build_gapless_master_audio, assert_segment_video
from rename_module import rename_batch_transaction
from video_module import pair_files,build_srt_timeline,VideoFrame,verify_timeline_output,EFFECTS,build_image_effect


def make_wave(path, seconds, hz=440):
    with wave.open(str(path),'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(44100)
        length=round(seconds*44100)
        import struct
        for i in range(length):
            val=round(3000*math.sin(i*2*math.pi*hz/44100))
            w.writeframesraw(struct.pack('<h',val))


def test_all():
    with tempfile.TemporaryDirectory(prefix='alltool268_test_') as root:
        r=Path(root); img=r/'images'; aud=r/'audio'; img.mkdir(); aud.mkdir()
        for i,d in enumerate((.22,.36,.28),start=1):
            Image.new('RGB',(640,360),(i*45,65,95)).save(img/f'CHAR_{i:03d}.png')
            make_wave(aud/f'AUDIO_{i:03d}.wav',d)
        # Actual FFmpeg regression for every motion preset, not merely filter-string generation.
        motion_dir=r/'motion_regression'; motion_dir.mkdir()
        ffmpeg=find_ffmpeg()
        for idx,effect in enumerate(EFFECTS):
            motion_filter=build_image_effect(effect,1.2,320,180,30,.4,seed=idx+1)
            motion_out=motion_dir/f'{idx:02d}.mp4'
            cmd=[ffmpeg,'-y','-hide_banner','-loglevel','error','-loop','1','-framerate','30',
                 '-i',str(img/'CHAR_001.png'),'-vf',motion_filter,'-frames:v','12','-an',
                 '-c:v','libx264','-preset','ultrafast','-pix_fmt','yuv420p',str(motion_out)]
            result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=45)
            assert result.returncode==0 and motion_out.is_file() and motion_out.stat().st_size>500, (effect,result.stderr[-1000:])
            info=probe_media(motion_out)
            assert info.get('has_video') and abs(info.get('duration',0)-.4)<.08, (effect,info)
        pairs,mode=strict_pairs(img,aud)
        assert mode=='numeric-strict' and len(pairs)==3
        master=r/'master.flac'
        frames=build_gapless_master_audio(pairs,master,30)
        assert len(frames)==3 and sum(x['frames'] for x in frames)==frames[-1]['end_frame']
        assert probe_media(master)['has_audio']
        srt=[{'start':0.0,'end':1.0},{'start':3.0,'end':4.0}]
        t=build_srt_timeline(srt,30)
        assert t[0]['frames']==90 and t[1]['start_frame']==90 and t[1]['frames']==30, t
        try:
            pair_files([Path('001.mp4'),Path('002.mp4')],[Path('002.mp3'),Path('003.mp3')])
            raise AssertionError('video pairing did not reject missing indexed audio')
        except ValueError: pass
        (aud/'AUDIO_003.wav').rename(aud/'AUDIO_004.wav')
        try:
            strict_pairs(img,aud)
            raise AssertionError('image pairing did not reject missing audio')
        except ValueError: pass
        (aud/'AUDIO_004.wav').rename(aud/'AUDIO_003.wav')

        rename_dir=r/'rename'; rename_dir.mkdir()
        (rename_dir/'a.jpg').write_bytes(b'file-A'); (rename_dir/'b.jpg').write_bytes(b'file-B')
        (rename_dir/'001.jpg').mkdir()
        try:
            rename_batch_transaction([(rename_dir/'a.jpg',rename_dir/'001.jpg'),
                                      (rename_dir/'b.jpg',rename_dir/'002.jpg')])
            raise AssertionError('rename conflict accepted')
        except FileExistsError: pass
        assert (rename_dir/'a.jpg').read_bytes()==b'file-A'
        assert (rename_dir/'b.jpg').read_bytes()==b'file-B'
        assert not list(rename_dir.glob('.__rename_tmp_*'))
        n=rename_batch_transaction([(rename_dir/'a.jpg',rename_dir/'b.jpg'),
                                    (rename_dir/'b.jpg',rename_dir/'a.jpg')])
        assert n==2 and (rename_dir/'a.jpg').read_bytes()==b'file-B'

        # Full pipeline: 3 still clips, lossless master FLAC, merged H264 MP4.
        class NoGui:
            _render_image_segment=VideoFrame._render_image_segment
            _process_image_audio=VideoFrame._process_image_audio
            def __init__(self):
                self.logs=[]; self.pair_cancel_event=threading.Event(); self.status=''
            def log(self,msg): self.logs.append(str(msg))
            def set_progress(self,n,total,status=None): self.status=status or ''
            def after(self,delay,callback): pass  # no Tk; only dialog is queued
            def _set_busy(self,b): pass
        f=NoGui()
        settings={'fps':30,'w':320,'h':180,'effects':['Zoom In → Pan Trái'],
                  'intensity':1.2,'threads':2,'use_gpu':False,
                  'timeline_mode':'srt','srt_timeline':None}
        out=r/'final.mp4'
        f._process_image_audio(pairs,out,settings,'numeric-strict',True)
        if not out.exists():
            raise AssertionError('E2E failed:\n'+'\n'.join(f.logs[-20:]))
        assert probe_media(out)['has_audio'], f.logs
        verify_timeline_output(out,frames[-1]['end_frame'],30)
        assert (r/'final_QA.txt').exists()
        clipdir=r/'final_CLIPS'
        clips=sorted(clipdir.glob('*.mp4'))
        assert len(clips)==3 and all(probe_media(c)['has_audio'] for c in clips), f.logs[-10:]
        # Ensure cache removed only on verified success.
        assert not list(r.glob('.final_image_audio_cache_*'))

        # Inject clip-export failure: final video may pass, but job QA must not falsely say PASS;
        # existing clip must remain byte-for-byte intact and cache must be preserved for retry.
        partial_out=r/'partial.mp4'
        partial_dir=r/'partial_CLIPS'; partial_dir.mkdir()
        old_clip=partial_dir/'0001.mp4'; old_clip.write_bytes(b'pre-existing clip must survive')
        original_mux=video_module._mux_timeline_audio
        def fail_clip_mux(video_src,audio_src,dest,duration,log=None):
            if '_CLIPS' in str(dest):
                raise RuntimeError('injected clip export failure')
            return original_mux(video_src,audio_src,dest,duration,log)
        partial_job=NoGui()
        with mock.patch.object(video_module,'_mux_timeline_audio',side_effect=fail_clip_mux):
            partial_job._process_image_audio(pairs,partial_out,settings,'numeric-strict',True)
        partial_report=(r/'partial_QA.txt').read_text(encoding='utf-8')
        assert partial_out.is_file() and 'Status: PARTIAL_FAIL' in partial_report, partial_report
        assert old_clip.read_bytes()==b'pre-existing clip must survive'
        assert list(r.glob('.partial_image_audio_cache_*')), 'cache must remain when clip export is incomplete'
        assert 'clip lẻ chưa hoàn tất' in partial_job.status.lower(), partial_job.status
        print(f'PASS | Pairing strict, SRT gap, transactional rename, FLAC master, E2E motion render, all {len(EFFECTS)} motion filters, clip-failure QA/overwrite safety.')
        print('Output media:',probe_media(out)['duration'],'s; expected frames=',frames[-1]['end_frame'])

if __name__=='__main__': test_all()
