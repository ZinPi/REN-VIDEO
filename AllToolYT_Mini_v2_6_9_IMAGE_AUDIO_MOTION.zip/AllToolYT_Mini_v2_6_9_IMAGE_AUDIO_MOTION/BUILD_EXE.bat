﻿@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
where py >nul 2>nul && set "PY=py -3"
%PY% -m pip install -r requirements.txt pyinstaller
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name AllToolYoutubeMini ^
  --collect-all yt_dlp ^
  --collect-all youtube_transcript_api ^
  --collect-all imageio_ffmpeg ^
  --collect-all faster_whisper ^
  --collect-all ctranslate2 ^
  --collect-all av ^
  bootstrap.py
if errorlevel 1 goto ERR
echo.
copy /y "FFMPEG_GPU_PATH.txt" "dist\FFMPEG_GPU_PATH.txt" >nul
copy /y "HUONG_DAN_MOI_V269.txt" "dist\HUONG_DAN_MOI_V269.txt" >nul
echo DA BUILD XONG: dist\AllToolYoutubeMini.exe
explorer dist
pause
exit /b 0
:ERR
echo BUILD THAT BAI.
pause
