﻿Option Explicit
Dim fso, shell, folder, pycmd, code, cmd
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
folder = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = folder

pycmd = ""
code = shell.Run("cmd /d /s /c ""where pythonw.exe >nul 2>nul""", 0, True)
If code = 0 Then
    pycmd = "pythonw.exe"
Else
    code = shell.Run("cmd /d /s /c ""where pyw.exe >nul 2>nul""", 0, True)
    If code = 0 Then pycmd = "pyw.exe -3"
End If

If pycmd = "" Then
    MsgBox "Khong tim thay Python windowed (pythonw/pyw). Hay cai Python 3 hoac build file EXE bang BUILD_EXE.bat.", 16, "AllToolYT Mini"
    WScript.Quit 10
End If

cmd = pycmd & " " & Chr(34) & folder & "\bootstrap.py" & Chr(34)
shell.Run cmd, 0, False
