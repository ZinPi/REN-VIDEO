"""Small self-contained compatibility layer for the subset of CustomTkinter used here.
Built on tkinter so the tool does not depend on the external customtkinter package.
"""
import tkinter as tk
from tkinter import ttk

StringVar = tk.StringVar
BooleanVar = tk.BooleanVar
DoubleVar = tk.DoubleVar
IntVar = tk.IntVar


def set_appearance_mode(mode):
    pass


def set_default_color_theme(theme):
    pass


def _master_bg(master, fallback='#202020'):
    try:
        return master.cget('bg')
    except Exception:
        return fallback


def _px_chars(value, div=8):
    try:
        v = int(value)
        return max(1, v // div) if v > 60 else v
    except Exception:
        return value


def _base_kw(master, kwargs, *, default_bg=None, default_fg=None):
    kw = dict(kwargs)
    fg_color = kw.pop('fg_color', None)
    text_color = kw.pop('text_color', None)
    border_color = kw.pop('border_color', None)
    border_width = kw.pop('border_width', None)
    for k in ['corner_radius','hover_color','button_color','dropdown_fg_color','dropdown_hover_color',
              'segmented_button_fg_color','segmented_button_selected_color','segmented_button_selected_hover_color',
              'segmented_button_unselected_color','segmented_button_unselected_hover_color','progress_color',
              'scrollbar_fg_color','scrollbar_button_color','scrollbar_button_hover_color']:
        kw.pop(k, None)
    if fg_color == 'transparent':
        fg_color = _master_bg(master)
    if fg_color is not None:
        kw['bg'] = fg_color
    elif default_bg is not None:
        kw.setdefault('bg', default_bg if default_bg != 'master' else _master_bg(master))
    if text_color is not None:
        kw['fg'] = text_color
    elif default_fg is not None:
        kw.setdefault('fg', default_fg)
    if border_width is not None:
        kw['highlightthickness'] = border_width
    if border_color is not None:
        kw['highlightbackground'] = border_color
        kw['highlightcolor'] = border_color
    return kw


class CTk(tk.Tk):
    def __init__(self, *a, **kw):
        bg = kw.pop('fg_color', kw.pop('bg', '#111111'))
        super().__init__(*a, **kw)
        try: self.configure(bg=bg)
        except Exception: pass


class CTkFrame(tk.Frame):
    def __init__(self, master=None, *a, **kw):
        super().__init__(master, *a, **_base_kw(master, kw, default_bg='master'))


class CTkLabel(tk.Label):
    def __init__(self, master=None, *a, **kw):
        if 'width' in kw: kw['width'] = _px_chars(kw['width'])
        if 'height' in kw:
            try:
                h=int(kw['height']); kw['height']=max(1,h//20) if h>20 else h
            except Exception: pass
        kw = _base_kw(master, kw, default_bg='master', default_fg='white')
        super().__init__(master, *a, **kw)


class CTkButton(tk.Button):
    def __init__(self, master=None, *a, **kw):
        height = kw.pop('height', None)
        if 'width' in kw: kw['width'] = _px_chars(kw['width'])
        kw = _base_kw(master, kw, default_bg='#1f6aa5', default_fg='white')
        kw.setdefault('relief', 'flat'); kw.setdefault('bd', 0); kw.setdefault('cursor', 'hand2')
        if height and 'pady' not in kw:
            try: kw['pady'] = max(3, int(height)//12)
            except Exception: pass
        if 'bg' in kw: kw.setdefault('activebackground', kw['bg'])
        if 'fg' in kw: kw.setdefault('activeforeground', kw['fg'])
        super().__init__(master, *a, **kw)


class CTkEntry(tk.Entry):
    def __init__(self, master=None, *a, **kw):
        self.placeholder_text = kw.pop('placeholder_text', '')
        kw.pop('height', None)
        if 'width' in kw: kw['width'] = _px_chars(kw['width'])
        kw = _base_kw(master, kw, default_bg='#343638', default_fg='white')
        kw.setdefault('relief', 'flat'); kw.setdefault('insertbackground', 'white')
        super().__init__(master, *a, **kw)


class CTkTextbox(tk.Text):
    def __init__(self, master=None, *a, **kw):
        if 'height' in kw:
            try:
                h=int(kw['height']); kw['height']=max(3,h//18) if h>30 else h
            except Exception: pass
        if 'width' in kw: kw['width'] = _px_chars(kw['width'])
        kw = _base_kw(master, kw, default_bg='#1d1e1e', default_fg='white')
        kw.setdefault('relief', 'flat'); kw.setdefault('insertbackground', 'white')
        super().__init__(master, *a, **kw)


class CTkCheckBox(tk.Checkbutton):
    def __init__(self, master=None, *a, **kw):
        kw.pop('checkbox_width', None); kw.pop('checkbox_height', None)
        if 'width' in kw: kw['width'] = _px_chars(kw['width'])
        kw = _base_kw(master, kw, default_bg='master', default_fg='white')
        if 'bg' in kw:
            kw.setdefault('activebackground', kw['bg']); kw.setdefault('selectcolor', kw['bg'])
        super().__init__(master, *a, **kw)


class CTkRadioButton(tk.Radiobutton):
    def __init__(self, master=None, *a, **kw):
        kw = _base_kw(master, kw, default_bg='master', default_fg='white')
        if 'bg' in kw:
            kw.setdefault('activebackground', kw['bg']); kw.setdefault('selectcolor', kw['bg'])
        super().__init__(master, *a, **kw)


class CTkOptionMenu(ttk.Combobox):
    _style_ready = False
    def __init__(self, master=None, *a, **kw):
        values = kw.pop('values', [])
        variable = kw.pop('variable', kw.pop('textvariable', None))
        command = kw.pop('command', None)
        kw.pop('height', None)
        if 'width' in kw: kw['width'] = _px_chars(kw['width'])
        for k in ['fg_color','text_color','border_color','button_color','dropdown_fg_color','hover_color','corner_radius']:
            kw.pop(k, None)
        self._ensure_style(master)
        kw.setdefault('style','CTk.TCombobox')
        super().__init__(master, *a, values=values, textvariable=variable, state='readonly', **kw)
        self._ctk_command = command
        if command: self.bind('<<ComboboxSelected>>', lambda e: command(self.get()))

    @classmethod
    def _ensure_style(cls, master):
        if cls._style_ready: return
        try:
            st=ttk.Style(master)
            try: st.theme_use('clam')
            except Exception: pass
            st.configure('CTk.TCombobox', fieldbackground='#343638', background='#343638', foreground='white', arrowcolor='white')
            st.map('CTk.TCombobox', fieldbackground=[('readonly','#343638')], foreground=[('readonly','white')], selectbackground=[('readonly','#1f6aa5')], selectforeground=[('readonly','white')])
        except Exception: pass
        cls._style_ready=True

    def configure(self, cnf=None, **kw):
        if cnf: kw.update(cnf)
        cmd = kw.pop('command', None)
        for k in ['fg_color','text_color','border_color','button_color','dropdown_fg_color','hover_color','corner_radius']:
            kw.pop(k, None)
        if 'width' in kw: kw['width'] = _px_chars(kw['width'])
        if cmd is not None:
            self._ctk_command = cmd
            self.bind('<<ComboboxSelected>>', lambda e: cmd(self.get()))
        return super().configure(**kw)


class CTkProgressBar(ttk.Progressbar):
    def __init__(self, master=None, *a, **kw):
        variable = kw.pop('variable', None) or tk.DoubleVar(value=0)
        kw.pop('height', None)
        for k in ['fg_color','progress_color','corner_radius']: kw.pop(k, None)
        self._var = variable
        super().__init__(master, *a, variable=variable, maximum=1.0, **kw)
    def set(self, value): self._var.set(value)


class CTkScrollableFrame(CTkFrame):
    # For this compact app the settings fit normal desktop windows; it behaves as
    # a regular frame to keep the project dependency-free.
    pass


class CTkTabview(CTkFrame):
    def __init__(self, master=None, *a, **kw):
        for k in ['segmented_button_fg_color','segmented_button_selected_color','segmented_button_selected_hover_color',
                  'segmented_button_unselected_color','segmented_button_unselected_hover_color','border_color','border_width']:
            kw.pop(k, None)
        super().__init__(master, *a, **kw)
        st=ttk.Style(master)
        try:
            st.configure('CTk.TNotebook', background='#16163a', borderwidth=0)
            st.configure('CTk.TNotebook.Tab', background='#28285a', foreground='white', padding=(14,7))
            st.map('CTk.TNotebook.Tab', background=[('selected','#7c6cf0')], foreground=[('selected','white')])
        except Exception: pass
        self._nb = ttk.Notebook(self, style='CTk.TNotebook')
        self._nb.pack(fill='both', expand=True)
        self._tabs = {}
    def add(self, name):
        frame = tk.Frame(self._nb, bg='#16163a')
        self._nb.add(frame, text=name)
        self._tabs[name] = frame
        return frame


class CTkImage:
    def __init__(self, *a, **kw):
        self.light_image = kw.get('light_image'); self.dark_image = kw.get('dark_image'); self.size = kw.get('size')
