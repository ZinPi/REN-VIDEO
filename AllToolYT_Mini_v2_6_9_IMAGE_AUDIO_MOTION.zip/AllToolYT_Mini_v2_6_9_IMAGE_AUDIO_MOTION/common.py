import os
import re
import sys
import shutil
import subprocess
from pathlib import Path


def app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def natural_key(value):
    s = value.name if hasattr(value, "name") else str(value)
    return [int(x) if x.isdigit() else x.lower() for x in re.split(r"(\d+)", s)]


def parse_file_index(path_or_name):
    name = Path(path_or_name).stem
    nums = re.findall(r"\d+", name)
    return int(nums[-1]) if nums else None


def sanitize_filename(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*]+', '_', name or '')
    name = re.sub(r'\s+', ' ', name).strip().strip('.')
    return name[:160] or 'output'


# Pin one validated FFmpeg executable for the entire render process.
# In particular, the NVENC preflight and the real segments MUST use the same binary.
_FFMPEG_OVERRIDE = None


def _preferred_ffmpeg_candidates():
    """Read an optional, user-editable FFmpeg location; never run the text as code.

    A missing or moved path is ignored so regular FFmpeg discovery still works.
    Priority: ALLTOOLYT_FFMPEG environment setting, then FFMPEG_GPU_PATH.txt.
    """
    configured=[]
    env=os.environ.get('ALLTOOLYT_FFMPEG', '').strip().strip('"')
    if env:
        configured.append(os.path.expandvars(os.path.expanduser(env)))
    path_file=app_dir()/'FFMPEG_GPU_PATH.txt'
    try:
        lines=path_file.read_text(encoding='utf-8-sig').splitlines()
    except (OSError, UnicodeError):
        lines=[]
    for line in lines:
        candidate=line.strip().strip('"')
        if candidate and not candidate.startswith('#'):
            configured.append(os.path.expandvars(os.path.expanduser(candidate)))
            break
    return [str(Path(x)) for x in configured if Path(x).is_file()]


def find_ffmpeg_candidates():
    """Return priority/pinned, local, PATH, and imageio FFmpeg candidates."""
    candidates=_preferred_ffmpeg_candidates()
    for name in ('ffmpeg.exe', 'ffmpeg'):
        local=app_dir()/name
        if local.is_file():
            candidates.append(str(local))
    # Multiple FFmpeg installations may appear on PATH. Try every distinct binary.
    for folder in os.environ.get('PATH', '').split(os.pathsep):
        if not folder.strip():
            continue
        for name in ('ffmpeg.exe', 'ffmpeg') if os.name == 'nt' else ('ffmpeg',):
            executable=Path(folder.strip().strip('"'))/name
            if executable.is_file():
                candidates.append(str(executable))
    path_ffmpeg=shutil.which('ffmpeg')
    if path_ffmpeg:
        candidates.append(path_ffmpeg)
    try:
        import imageio_ffmpeg
        binary=imageio_ffmpeg.get_ffmpeg_exe()
        if binary:
            candidates.append(binary)
    except Exception:
        pass
    seen=set()
    unique=[]
    for candidate in candidates:
        try:
            identity=os.path.normcase(os.path.realpath(candidate))
        except Exception:
            identity=os.path.normcase(os.path.abspath(candidate))
        if identity not in seen:
            seen.add(identity)
            unique.append(str(candidate))
    return unique


def set_ffmpeg_override(path=None):
    """Use a hardware-tested executable consistently across all render helpers."""
    global _FFMPEG_OVERRIDE
    if path is None:
        _FFMPEG_OVERRIDE = None
    else:
        candidate=Path(path)
        if not candidate.is_file():
            raise FileNotFoundError(f'Không tìm thấy FFmpeg đã được kiểm tra: {path}')
        _FFMPEG_OVERRIDE = str(candidate)


def find_ffmpeg() -> str:
    if _FFMPEG_OVERRIDE is not None:
        if Path(_FFMPEG_OVERRIDE).is_file():
            return _FFMPEG_OVERRIDE
        raise FileNotFoundError('FFmpeg GPU đã chọn không còn tồn tại: '+_FFMPEG_OVERRIDE)
    candidates=find_ffmpeg_candidates()
    if candidates:
        return candidates[0]
    raise RuntimeError(
        'Không tìm thấy FFmpeg. Hãy đặt ffmpeg.exe cạnh tool hoặc cài FFmpeg vào PATH.\n'
        'Hãy cài requirements.txt hoặc build EXE bằng BUILD_EXE.bat nếu máy chưa có FFmpeg.'
    )

def _windows_hidden_process_kwargs(extra_creationflags=0):
    """Return subprocess kwargs that never create/show a console on Windows."""
    kwargs = {}
    if os.name == 'nt':
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        try:
            startupinfo.wShowWindow = subprocess.SW_HIDE
        except Exception:
            pass
        flags = int(extra_creationflags or 0) | int(getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        kwargs['startupinfo'] = startupinfo
        kwargs['creationflags'] = flags
    elif extra_creationflags:
        kwargs['creationflags'] = extra_creationflags
    return kwargs


def run_process(cmd, *, timeout=None, creationflags=0):
    """Run a child process silently on Windows.

    This helper is used by media probing/QA. Without CREATE_NO_WINDOW, every
    ffmpeg probe may open a Terminal window when the GUI itself runs via
    pythonw/windowed EXE.
    """
    kwargs = _windows_hidden_process_kwargs(creationflags)
    return subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        errors="replace",
        timeout=timeout,
        **kwargs,
    )


def probe_media(path: str):
    """Return duration(seconds), has_audio using ffmpeg stderr; no ffprobe needed."""
    ffmpeg = find_ffmpeg()
    p = run_process([ffmpeg, "-hide_banner", "-i", str(path)], timeout=60)
    txt = (p.stderr or "") + "\n" + (p.stdout or "")
    m = re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", txt)
    duration = 0.0
    if m:
        duration = int(m.group(1))*3600 + int(m.group(2))*60 + float(m.group(3))
    has_audio = bool(re.search(r"Stream #.*Audio:", txt))
    has_video = bool(re.search(r"Stream #.*Video:", txt))
    return {"duration": duration, "has_audio": has_audio, "has_video": has_video, "raw": txt}


def get_resolution(ratio: str, quality: str):
    base = {
        "720p": (1280, 720),
        "1080p": (1920, 1080),
        "2K": (2560, 1440),
        "4K": (3840, 2160),
    }.get(quality, (1920, 1080))
    if ratio == "9:16":
        return base[1], base[0]
    return base


def ensure_parent(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)


def open_in_explorer(path):
    p = Path(path)
    target = p if p.is_dir() else p.parent
    try:
        if os.name == 'nt':
            os.startfile(str(target))
        elif sys.platform == 'darwin':
            subprocess.Popen(['open', str(target)])
        else:
            subprocess.Popen(['xdg-open', str(target)])
    except Exception:
        pass
