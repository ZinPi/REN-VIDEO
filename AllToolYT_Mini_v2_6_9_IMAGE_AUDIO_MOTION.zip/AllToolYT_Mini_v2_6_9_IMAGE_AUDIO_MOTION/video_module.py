from __future__ import annotations
import os
import json
import hashlib
import random
import re
import shutil
import subprocess
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from image_audio_engine import (strict_pairs, job_identity, build_gapless_master_audio,
                                assert_segment_video, JobCancelled)
from pathlib import Path

import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog, messagebox

from common import find_ffmpeg, find_ffmpeg_candidates, set_ffmpeg_override, probe_media, natural_key, parse_file_index, get_resolution, open_in_explorer, run_process

VIDEO_EXTS = {'.mp4','.mov','.avi','.mkv','.webm','.m4v'}
AUDIO_EXTS = {'.mp3','.wav','.m4a','.aac','.flac','.ogg','.opus'}
IMAGE_EXTS = {'.png','.jpg','.jpeg','.webp','.bmp'}

TRANSITIONS = [
    'fade','wipeleft','wiperight','wipeup','wipedown','slideleft','slideright','slideup','slidedown',
    'circlecrop','rectcrop','distance','fadeblack','fadewhite','radial','smoothleft','smoothright','smoothup','smoothdown',
    'circleopen','circleclose','vertopen','vertclose','horzopen','horzclose','dissolve','pixelize','diagtl','diagtr','diagbl','diagbr',
    'hlslice','hrslice','vuslice','vdslice','hblur','fadegrays','wipetl','wipetr','wipebl','wipebr','squeezeh','squeezev','zoomin',
    'fadefast','fadeslow','hlwind','hrwind','vuwind','vdwind','coverleft','coverright','coverup','coverdown','revealleft','revealright',
    'revealup','revealdown'
]
TRANSITION_GROUPS = {
    'Tắt': ['none'],
    'Tất cả (58 kiểu)': TRANSITIONS,
    'Mượt / Fade': ['fade','fadeblack','fadewhite','dissolve','fadegrays','fadefast','fadeslow','hblur','pixelize'],
    'Slide / Cover': ['slideleft','slideright','slideup','slidedown','coverleft','coverright','coverup','coverdown','revealleft','revealright','revealup','revealdown'],
    'Wipe': ['wipeleft','wiperight','wipeup','wipedown','wipetl','wipetr','wipebl','wipebr','hlwind','hrwind','vuwind','vdwind'],
    'Hình học': ['circlecrop','rectcrop','radial','circleopen','circleclose','vertopen','vertclose','horzopen','horzclose','diagtl','diagtr','diagbl','diagbr','squeezeh','squeezev','zoomin'],
}
BASE_EFFECTS = ['Zoom In (phóng to)','Zoom Out (thu nhỏ)','Pan Trái','Pan Phải','Pan Lên','Pan Xuống']
COMBO_EFFECTS = [
    'Zoom In → Pan Trái','Zoom In → Pan Phải','Zoom In → Pan Lên','Zoom In → Pan Xuống',
    'Zoom In + Pan Trái','Zoom In + Pan Phải','Zoom In + Pan Lên','Zoom In + Pan Xuống'
]
EFFECTS = BASE_EFFECTS + COMBO_EFFECTS + ['Không hiệu ứng']
SYNC_MODES = ['Speed (co/dãn video)','Loop (lặp video)','Cut/Freeze (cắt hoặc giữ khung cuối)']
VOCAL_MODES = ['Không xử lý', 'Karaoke L-R', 'AI Demucs (nếu đã cài)']


def q(s):
    return str(s)


def normalize_mp4_output(value) -> Path:
    """Normalize an MP4 target before any long-running work.

    Missing extensions are automatically replaced with .mp4. Explicitly
    unsupported extensions are rejected rather than producing fake .mp4 files.
    """
    raw = str(value or '').strip().strip('"').strip()
    if not raw:
        raise ValueError('Chưa chọn nơi lưu video MP4.')
    path = Path(os.path.expandvars(os.path.expanduser(raw)))
    if path.is_dir():
        raise ValueError(f'Đường dẫn đang là thư mục; hãy nhập tên video: {path}')
    if not path.suffix:
        path = path.with_name(path.name + '.mp4')
    elif path.suffix.lower() != '.mp4':
        raise ValueError(f'Định dạng đầu ra phải là .mp4, không phải {path.suffix}.')
    if not path.name or path.name.lower() == '.mp4':
        raise ValueError('Tên file video không hợp lệ.')
    return path


def preflight_mp4_output(value, *, source_paths=()) -> Path:
    """Validate directory and write access before images are rendered.

    The short-lived probe is written only to the destination directory. No
    existing output or user-provided file is modified during preflight.
    """
    output = normalize_mp4_output(value)
    if any(str(output.absolute()).casefold() == str(Path(src).absolute()).casefold()
           for src in source_paths if src):
        raise ValueError('Video đầu ra trùng với file nguồn; hãy chọn tên khác.')
    parent = output.parent
    if not parent.exists():
        raise ValueError(f'Thư mục lưu không tồn tại: {parent}')
    if not parent.is_dir():
        raise ValueError(f'Đường dẫn lưu không phải thư mục: {parent}')
    if output.exists():
        if not output.is_file():
            raise ValueError(f'Đường dẫn video không phải file thường: {output}')
        try:
            with output.open('ab'):
                pass
        except OSError as e:
            raise ValueError(f'Video đích đang bị khóa hoặc không có quyền ghi: {output}\n{e}') from e
    try:
        fd, probe_name = tempfile.mkstemp(prefix='._alltool_write_test_', suffix='.tmp', dir=str(parent))
        try:
            with os.fdopen(fd, 'wb') as f:
                f.write(b'AllToolYT output preflight')
                f.flush()
        finally:
            try: Path(probe_name).unlink()
            except FileNotFoundError: pass
    except OSError as e:
        raise ValueError(f'Không có quyền ghi vào thư mục lưu: {parent}\n{e}') from e
    return output


def _render_job_fingerprint(pairs, settings, final_output):
    """Stable identity for safe per-project recovery across failed merges."""
    def source_stat(value):
        file = Path(value)
        stat = file.stat()
        return [str(file.absolute()), stat.st_size, stat.st_mtime_ns]
    job = {
        'cache_version': 264,
        'images': [source_stat(img) for img, _ in pairs],
        'srt': source_stat(settings['srt_path']),
        'srt_sha256': hashlib.sha256(Path(settings['srt_path']).read_bytes()).hexdigest(),
        'audio': source_stat(settings['timeline_audio']) if settings.get('timeline_audio') else None,
        'output': str(Path(final_output).absolute()),
        'fps': int(settings['fps']),
        'width': int(settings['w']),
        'height': int(settings['h']),
        'effects': list(settings.get('effects') or []),
        'intensity': float(settings['intensity']),
        'frames': [int(c['frames']) for c in settings['srt_timeline']],
    }
    encoded = json.dumps(job, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return hashlib.sha256(encoded).hexdigest()[:24], job


def verify_timeline_output(path, expected_frames, fps, log=None):
    """Verify absolute timeline frame count in the final MP4 when ffprobe exists."""
    media = _validate_media_file(path, require_audio=False)
    ffmpeg = Path(find_ffmpeg())
    suffix = '.exe' if os.name == 'nt' else ''
    local = ffmpeg.with_name('ffprobe' + suffix)
    probe = str(local) if local.exists() else shutil.which('ffprobe')
    if not probe:
        if log:
            log('[QA] FFprobe chưa cài: chỉ xác nhận video phát được; chưa xác minh số frame chính xác.')
        return None
    cmd=[probe,'-v','error','-select_streams','v:0','-show_entries',
         'stream=nb_frames,start_time,r_frame_rate','-of','json',str(path)]
    result=run_process(cmd,timeout=60)
    if result.returncode:
        raise RuntimeError('Không kiểm tra được video sau ghép: ' + (result.stderr or 'ffprobe failed')[-500:])
    streams=json.loads(result.stdout or '{}').get('streams') or []
    if not streams:
        raise RuntimeError('FFprobe không tìm thấy video stream sau ghép.')
    stream=streams[0]
    counted=stream.get('nb_frames')
    if counted not in (None,'N/A',''):
        count=int(counted)
        if count != int(expected_frames):
            raise RuntimeError(
                f'QA FAIL: video tổng có {count} frame; SRT cần {int(expected_frames)} frame. '
                'Đã giữ cache để không phải render lại ảnh khi sửa lỗi ghép.'
            )
    else:
        if log: log('[QA] MP4 chưa báo nb_frames; không xác minh được số frame.')
    start=float(stream.get('start_time') or 0.0)
    if abs(start)>1.0/(int(fps)*4):
        raise RuntimeError(f'QA FAIL: video phải bắt đầu 0.000s, thực tế {start:.6f}s.')
    if log:
        log(f'[QA] Video tổng: start={start:.6f}s • frame={counted} • expected={int(expected_frames)} • {fps} FPS')
    return stream


# A profile is only activated after actually encoding AND probing a GPU MP4.
# Some FFmpeg builds accept NVENC but disagree on newer preset/rate-control flags.
_NVENC_PROFILES = (
    ('p4_constqp', ('-c:v','h264_nvenc','-preset','p4','-rc','constqp','-qp','28')),
    ('medium_constqp', ('-c:v','h264_nvenc','-preset','medium','-rc','constqp','-qp','28')),
    ('basic_compat', ('-c:v','h264_nvenc')),
)
_ACTIVE_NVENC_PROFILE = _NVENC_PROFILES[0][0]
_ACTIVE_NVENC_ARGS = _NVENC_PROFILES[0][1]


def _codec_args(use_gpu: bool):
    if use_gpu:
        return list(_ACTIVE_NVENC_ARGS)
    return ['-c:v','libx264','-preset','fast','-crf','23']


def _scale_filter(w,h,fps=30):
    return f"scale={w}:{h}:force_original_aspect_ratio=decrease:force_divisible_by=2,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={fps},format=yuv420p"


_RENDER_CONTEXT = threading.local()
MAX_FFMPEG_SECONDS = 14400  # prevent indefinite orphaned FFmpeg processes


def _run_ffmpeg(cmd, log=None):
    """Bounded subprocess; paired-image jobs support responsive cancellation."""
    import time
    if log:
        log('FFmpeg: ' + ' '.join(str(x) for x in cmd[:18]) + (' ...' if len(cmd)>18 else ''))
    kwargs = {}
    if os.name == 'nt':
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        try: si.wShowWindow = subprocess.SW_HIDE
        except Exception: pass
        kwargs['startupinfo'] = si
        kwargs['creationflags'] = int(getattr(subprocess, 'CREATE_NO_WINDOW', 0))
    event = getattr(_RENDER_CONTEXT, 'cancel_event', None)
    if event is not None and event.is_set():
        raise JobCancelled('Đã hủy trước khi gọi FFmpeg.')
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            text=True, errors='replace', **kwargs)
    start = time.monotonic()
    try:
        while True:
            if event is not None and event.is_set():
                raise JobCancelled('Đã hủy render FFmpeg hiện tại; các đoạn đã hoàn tất vẫn trong cache.')
            remain = MAX_FFMPEG_SECONDS - (time.monotonic()-start)
            if remain <= 0:
                raise TimeoutError('FFmpeg vượt giới hạn 4 giờ của một tiến trình. Xem log/nguồn lỗi.')
            try:
                stdout,stderr=proc.communicate(timeout=min(0.35,remain))
                break
            except subprocess.TimeoutExpired:
                continue
        if proc.returncode:
            raise RuntimeError((stderr or stdout or 'FFmpeg lỗi')[-5000:])
        return subprocess.CompletedProcess(cmd,proc.returncode,stdout,stderr)
    except BaseException:
        if proc.poll() is None:
            proc.kill()
            try: proc.communicate(timeout=10)
            except Exception: pass
        raise


def _gpu_error_summary(exc):
    """Report the causal FFmpeg lines, not merely generic '-22 before EOF' noise."""
    lines=[x.strip() for x in str(exc).splitlines() if x.strip()]
    if not lines:
        return 'Lỗi NVENC không xác định.'
    patterns=(
        'driver does not support', 'minimum required nvidia driver',
        'cannot load nvcuda', 'cannot load nvencodeapi', 'cannot load libnvidia',
        'cannot load cuda', 'cannot load', 'cannot find', 'no nvenc capable',
        'no capable devices', 'unsupported device', 'unsupported gpu',
        'required nvenc api', 'cuinit(', 'cuda_error_', 'cuda error',
        'openencodesession', 'nvenc err', 'nv_enc_err', 'out of memory',
        'invalid param', 'invalid device', 'not supported',
        'failed to initialize', 'failed to create', 'operation not permitted',
        'permission denied', 'device not found', 'unknown encoder',
    )
    causes=[line for line in lines if any(tag in line.lower() for tag in patterns)]
    if causes:
        # Keep first/root messages as well as the last distinct diagnostic.
        selection=causes[:3]
        if causes[-1] not in selection:
            selection.append(causes[-1])
    else:
        selection=[line for line in lines if 'error' in line.lower() or 'nvenc' in line.lower()]
        if not selection:
            selection=lines
        selection=selection[:2]
    return ' | '.join(x[:350] for x in selection)[:1400]


def _nvidia_status():
    """Best-effort driver/GPU check; never assume absent nvidia-smi means no GPU."""
    commands=[['nvidia-smi','--query-gpu=name,driver_version','--format=csv,noheader']]
    if os.name == 'nt':
        root=os.environ.get('ProgramFiles','C:\\Program Files')
        smi=Path(root)/'NVIDIA Corporation'/'NVSMI'/'nvidia-smi.exe'
        if smi.is_file():
            commands.append([str(smi),'--query-gpu=name,driver_version','--format=csv,noheader'])
    for cmd in commands:
        try:
            p=run_process(cmd,timeout=12)
            if p.returncode == 0 and p.stdout.strip():
                return p.stdout.strip().replace('\n','; ')
        except (OSError, subprocess.TimeoutExpired):
            pass
    return 'Không đọc được nvidia-smi (chưa xác định driver/GPU; KHÔNG kết luận GPU vắng mặt).'


def _ffmpeg_encoder_available(ffmpeg):
    try:
        p=run_process([ffmpeg,'-hide_banner','-encoders'],timeout=20)
    except (OSError, subprocess.TimeoutExpired) as e:
        return False, str(e)
    output=(p.stdout or '')+'\n'+(p.stderr or '')
    supported=bool(re.search(r'^\s*V[.A-Z]{5}\s+h264_nvenc\b',output,re.M))
    # FFmpeg encoders listing flag formats vary; accept exact encoder token
    # on a conventional listing line when the six-character flags differ.
    if not supported:
        supported=bool(re.search(r'^\s*[A-Z.]{6}\s+h264_nvenc\s',output,re.M))
    return supported, ('h264_nvenc' if supported else (output[-500:] if p.returncode else 'Không có h264_nvenc trong danh sách FFmpeg encoders.'))


def _nvenc_probe_cmd(ffmpeg, output, args, *, width=640, height=360, fps=60, frames=12):
    return [
        ffmpeg,'-y','-hide_banner','-loglevel','info',
        '-f','lavfi','-i',f'testsrc2=size={width}x{height}:rate={fps}',
        '-frames:v',str(frames),'-pix_fmt','yuv420p','-an',
        *args,'-bf','0','-video_track_timescale','90000',
        '-movflags','+faststart',str(output),
    ]


def _validate_nvenc_probe(path, ffmpeg):
    """Independently decode a frame using the exact candidate FFmpeg."""
    output=Path(path)
    if not output.is_file() or output.stat().st_size < 1000:
        raise RuntimeError('NVENC không tạo được file MP4 có dữ liệu.')
    result=run_process([
        ffmpeg,'-hide_banner','-loglevel','error',
        '-i',str(output),'-map','0:v:0','-frames:v','1',
        '-an','-f','null','-'
    ],timeout=30)
    if result.returncode:
        raise RuntimeError('Không giải mã được video NVENC: '+(result.stderr or '')[-1500:])


def _preflight_nvenc(log=None, *, width=1920, height=1080, fps=60):
    """Real hardware test, with compatible profiles and FFmpeg candidates.

    Successful preflight pins both executable and codec options so the actual
    render uses exactly the same working encoder. No project inputs are used.
    """
    global _ACTIVE_NVENC_PROFILE, _ACTIVE_NVENC_ARGS
    candidates=find_ffmpeg_candidates()
    if not candidates:
        if log: log('[GPU] FAIL: Không tìm thấy ffmpeg.exe nào.')
        return False
    if log:
        log('[GPU] NVIDIA: '+_nvidia_status())
        log(f'[GPU] Tìm thấy {len(candidates)} bản FFmpeg; sẽ kiểm tra h264_nvenc thực tế.')
    first_cause=None
    for ffmpeg in candidates:
        try:
            p=run_process([ffmpeg,'-hide_banner','-version'],timeout=15)
            version=(p.stdout or p.stderr or '').splitlines()[0][:200]
        except (OSError, subprocess.TimeoutExpired) as e:
            if log: log(f'[GPU] Bỏ qua FFmpeg không thể khởi chạy: {ffmpeg} — {e}')
            continue
        if log:
            log('[GPU] FFmpeg: '+ffmpeg)
            log('[GPU] Phiên bản: '+version)
        supported, message=_ffmpeg_encoder_available(ffmpeg)
        if not supported:
            if log: log('[GPU] Không có encoder h264_nvenc; thử FFmpeg tiếp theo. '+message[:220])
            continue
        for profile_name, profile_args in _NVENC_PROFILES:
            try:
                with tempfile.TemporaryDirectory(prefix='alltool_nvenc_test_') as td:
                    small=Path(td)/'small.mp4'
                    if log: log(f'[GPU] Thử {profile_name}: H.264 NVENC 640x360/60fps/12 frame.')
                    _run_ffmpeg(_nvenc_probe_cmd(ffmpeg,small,profile_args),None)
                    _validate_nvenc_probe(small,ffmpeg)
                    # Also verify the requested actual target resolution. A basic
                    # 640x360 test alone cannot catch per-resolution failures.
                    tw=max(2,(int(width)//2)*2)
                    th=max(2,(int(height)//2)*2)
                    if tw != 640 or th != 360:
                        full=Path(td)/'target.mp4'
                        _run_ffmpeg(_nvenc_probe_cmd(ffmpeg,full,profile_args,width=tw,height=th,fps=max(1,int(fps)),frames=3),None)
                        _validate_nvenc_probe(full,ffmpeg)
                # Only commit changes once both real NVENC tests succeed.
                set_ffmpeg_override(ffmpeg)
                _ACTIVE_NVENC_PROFILE=profile_name
                _ACTIVE_NVENC_ARGS=profile_args
                if log:
                    log(f'[GPU] NVENC PASS: {profile_name}, {tw}x{th}@{fps}; FFmpeg này được cố định cho toàn bộ lượt render.')
                    log('[GPU] Lưu ý: NVENC mã hóa video bằng GPU; filter zoompan/lanczos vẫn xử lý trên CPU.')
                return True
            except Exception as e:
                cause=_gpu_error_summary(e)
                if first_cause is None: first_cause=cause
                if log: log(f'[GPU] {profile_name} FAIL: {cause}')
                # Driver/NVENC API incompatibility cannot be repaired by codec
                # presets. Do not waste time retrying the same FFmpeg binary.
                raw=str(e).lower()
                if 'driver does not support the required nvenc api version' in raw or 'minimum required nvidia driver for nvenc' in raw:
                    if log: log('[GPU] Bản FFmpeg này yêu cầu driver/NVENC API mới hơn. Bỏ qua để thử FFmpeg tương thích tiếp theo.')
                    break
    if log:
        log('[GPU] NVENC FAIL trên mọi FFmpeg/cấu hình được tìm thấy. Tool sẽ fallback CPU để không hỏng job.')
        if first_cause: log('[GPU] Lỗi đầu tiên: '+first_cause)
        log('[GPU] Kiểm tra driver NVIDIA/phiên bản FFmpeg. Chạy GPU_DIAGNOSTIC.bat để lưu toàn bộ stderr.')
    return False


def _run_with_gpu_fallback(cmd_gpu, cmd_cpu, use_gpu, log=None, gpu_disable_event=None, gpu_disable_lock=None, gpu_success_event=None):
    # A shared Event lets a whole batch stop retrying NVENC after the first real
    # encoder failure. This prevents hundreds of identical GPU failures before CPU fallback.
    gpu_allowed = bool(use_gpu) and not (gpu_disable_event and gpu_disable_event.is_set())
    if gpu_allowed:
        try:
            result = _run_ffmpeg(cmd_gpu, log)
            if gpu_success_event is not None:
                if gpu_disable_lock is not None:
                    with gpu_disable_lock:
                        first_success = not gpu_success_event.is_set()
                        gpu_success_event.set()
                else:
                    first_success = not gpu_success_event.is_set()
                    gpu_success_event.set()
                if first_success and log:
                    log('[GPU] Đã mã hóa thành công segment thực tế bằng NVIDIA NVENC.')
            return result
        except JobCancelled:
            raise
        except Exception as e:
            first_disable = True
            if gpu_disable_event is not None:
                if gpu_disable_lock is not None:
                    with gpu_disable_lock:
                        first_disable = not gpu_disable_event.is_set()
                        gpu_disable_event.set()
                else:
                    first_disable = not gpu_disable_event.is_set()
                    gpu_disable_event.set()
            if log and first_disable:
                log('[GPU] NVENC thất bại → tắt GPU cho phần còn lại của batch, chuyển sang CPU.')
                log('[GPU] ' + _gpu_error_summary(e))
    return _run_ffmpeg(cmd_cpu, log)



def _audio_filter_for_original(vocal_mode, volume):
    v = max(0.0, float(volume))
    if vocal_mode == 'Karaoke L-R':
        return f"pan=stereo|c0=0.5*c0-0.5*c1|c1=0.5*c1-0.5*c0,volume={v}"
    return f"volume={v}"


def _transition_name(group, item, seed):
    if group == 'Tắt': return None
    choices = TRANSITION_GROUPS.get(group) or TRANSITIONS
    if item == 'Random':
        return random.Random(seed).choice(choices)
    if item in choices: return item
    return choices[0] if choices else None


def pair_files(primary, secondary):
    """Stable 1:1 pairing; refuse indexed audio mistakes instead of silent reuse."""
    videos=sorted(primary,key=natural_key)
    audios=sorted(secondary,key=natural_key)
    if not audios:
        return [(video,None) for video in videos]
    if len(videos)!=len(audios):
        raise ValueError(f'Không khớp: {len(videos)} video, {len(audios)} audio. Không ghép thiếu file.')
    vnums=[parse_file_index(v) for v in videos]
    anums=[parse_file_index(a) for a in audios]
    if all(x is None for x in vnums+anums):
        return list(zip(videos,audios))
    if any(x is None for x in vnums+anums):
        raise ValueError('Video/audio phải đều có số thứ tự hoặc đều không có số.')
    if len(set(vnums))!=len(vnums) or len(set(anums))!=len(anums):
        raise ValueError('Chỉ số video hoặc audio bị trùng.')
    by_num=dict(zip(anums,audios))
    missing=sorted(set(vnums)-set(anums))
    extra=sorted(set(anums)-set(vnums))
    if missing or extra:
        raise ValueError(f'Không khớp chỉ số video/audio. Thiếu audio: {missing[:20]}, audio thừa: {extra[:20]}')
    return [(v,by_num[n]) for v,n in zip(videos,vnums)]


def _srt_timestamp_to_seconds(value: str) -> float:
    value = (value or '').strip().replace('.', ',')
    m = re.match(r'^(\d+):(\d+):(\d+),(\d{1,3})$', value)
    if not m:
        raise ValueError(f'Timestamp SRT không hợp lệ: {value}')
    hh, mm, ss, ms = m.groups()
    return int(hh) * 3600.0 + int(mm) * 60.0 + int(ss) + int(ms.ljust(3, '0')[:3]) / 1000.0


def _seconds_to_srt_timestamp(seconds: float) -> str:
    ms_total = int(round(max(0.0, float(seconds)) * 1000.0))
    hh = ms_total // 3600000
    rem = ms_total % 3600000
    mm = rem // 60000
    rem %= 60000
    ss = rem // 1000
    ms = rem % 1000
    return f"{hh:02d}:{mm:02d}:{ss:02d},{ms:03d}"


def parse_srt_file(path) -> list[dict]:
    path = Path(path)
    raw = path.read_text(encoding="utf-8-sig", errors="replace")
    raw = raw.replace("\r\n", "\n").replace("\r", "\n")
    blocks = re.split(r"\n\s*\n", raw.strip())
    cues = []
    for block in blocks:
        lines = [ln.strip("\ufeff") for ln in block.split("\n") if ln.strip() != ""]
        if not lines:
            continue
        time_line = None
        text_lines = []
        idx = None
        if lines and re.match(r"^\d+$", lines[0]):
            idx = int(lines[0])
            lines = lines[1:]
        for i, line in enumerate(lines):
            if "-->" in line:
                time_line = line
                text_lines = lines[i+1:]
                break
        if not time_line:
            continue
        left, right = [x.strip() for x in time_line.split("-->", 1)]
        start = _srt_timestamp_to_seconds(left)
        end = _srt_timestamp_to_seconds(right)
        if end <= start:
            end = start + 0.001
        cues.append({
            "index": idx if idx is not None else len(cues) + 1,
            "start": start,
            "end": end,
            "text": " ".join(text_lines).strip(),
            "start_ts": left.replace(".", ","),
            "end_ts": right.replace(".", ","),
        })
    if not cues:
        raise RuntimeError(f"Không đọc được cue nào từ SRT: {path.name}")
    return cues


def build_srt_timeline(cues: list[dict], fps: int) -> list[dict]:
    """Keep original cue START. For gaps, hold previous image (never show next early).

    Overlapping cues are rejected: no image can satisfy two different timestamps.
    Adjacent sub-frame cues get at least one frame, with bounded frame rounding.
    """
    if not cues:
        raise RuntimeError('SRT không có cue nào.')
    fps=max(1,int(fps))
    base=float(cues[0]['start'])
    if base < 0:
        raise ValueError('SRT không được có thời điểm âm.')
    timeline=[]
    prev_frame=0
    for i,cue in enumerate(cues):
        start=float(cue['start'])-base
        end=float(cue['end'])-base
        if end <= start:
            raise ValueError(f'Cue {i+1} có thời gian END không lớn hơn START.')
        if i:
            last_end=float(cues[i-1]['end'])-base
            if start < last_end-0.0005:
                raise ValueError(f'SRT cue {i+1} chồng thời gian cue {i}; hãy sửa SRT trước khi render.')
        if i+1<len(cues):
            next_start=float(cues[i+1]['start'])-base
            if next_start < end-0.0005:
                raise ValueError(f'Cue {i+1} chồng thời gian cue {i+2}; hãy sửa SRT.')
            # A blank interval displays the current image (not the next image).
            displayed_end=next_start
        else:
            displayed_end=end
        # Absolute boundaries remain the reference; 1 frame minimum for short cues.
        start_frame=prev_frame
        end_frame=max(start_frame+1,round(displayed_end*fps))
        timeline.append({
            'index':cue.get('index',i+1),'text':cue.get('text',''),
            'source_start':cue['start'],'source_end':cue['end'],
            'start_frame':start_frame,'end_frame':end_frame,'frames':end_frame-start_frame,
            'start':start_frame/fps,'end':end_frame/fps,'duration':(end_frame-start_frame)/fps,
            'start_ts':_seconds_to_srt_timestamp(start_frame/fps),
            'end_ts':_seconds_to_srt_timestamp(end_frame/fps),
            'source_start_ts':cue.get('start_ts') or _seconds_to_srt_timestamp(cue['start']),
            'source_end_ts':cue.get('end_ts') or _seconds_to_srt_timestamp(cue['end']),
            'normalized_source_start':start,'normalized_source_end':end,
        })
        prev_frame=end_frame
    return timeline


def _mux_timeline_audio(video_src, audio_src, out_path, duration, log=None):
    ffmpeg = find_ffmpeg()
    video_src = Path(video_src)
    audio_src = Path(audio_src)
    out_path = normalize_mp4_output(out_path)
    if log:
        source_info=probe_media(audio_src)
        diff=source_info.get('duration',0)-float(duration)
        if source_info.get('duration',0)>0 and abs(diff)>0.25:
            log(f'[AUDIO-WARNING] Audio nguồn dài {source_info["duration"]:.3f}s, timeline video {duration:.3f}s; '
                + ('sẽ cắt bớt cuối.' if diff>0 else 'sẽ bổ sung im lặng cuối.'))
    temp_out = out_path.with_name(out_path.stem + '.__mux.mp4')
    try:
        if temp_out.exists():
            temp_out.unlink()
    except Exception:
        pass
    cmd = [
        ffmpeg, '-y', '-hide_banner',
        '-i', str(video_src), '-i', str(audio_src),
        '-map', '0:v:0', '-map', '1:a:0?',
        '-c:v', 'copy',
        '-af', f'aresample=48000,aformat=channel_layouts=stereo,apad,atrim=duration={float(duration):.6f}',
        '-c:a', 'aac', '-b:a', '192k', '-ar', '48000',
        '-movflags', '+faststart', '-t', f'{float(duration):.6f}',
        '-f', 'mp4', str(temp_out)
    ]
    _run_ffmpeg(cmd, log)
    _validate_media_file(temp_out, require_audio=True)
    os.replace(temp_out, out_path)
    return out_path


def _validate_media_file(path, require_audio=True):
    p = Path(path)
    if not p.exists() or p.stat().st_size < 1024:
        raise RuntimeError(f'File output không tồn tại hoặc quá nhỏ: {p}')
    info = probe_media(p)
    if not info.get('has_video'):
        raise RuntimeError(f'Output không có video hợp lệ: {p.name}')
    # FFmpeg reports duration rounded to hundredths; one frame at 60 FPS is
    # ~0.017 s and must not be rejected by an arbitrary 0.05 s threshold.
    if info.get('duration', 0) <= 0.05:
        r=run_process([find_ffmpeg(),'-v','error','-i',str(p),'-map','0:v:0',
                       '-frames:v','1','-f','null','-'],timeout=45)
        if r.returncode:
            raise RuntimeError(f'Video quá ngắn không giải mã được: {p.name}\n{r.stderr[-500:]}')
    if require_audio and not info.get('has_audio'):
        raise RuntimeError(f'Output thiếu audio: {p.name}')
    return info


def merge_segments(files, out_path, log=None, *, w=None, h=None, fps=30, use_gpu=False, require_audio=True):
    """Ghép tổng theo 2 tầng.

    Tầng 1 dùng concat stream-copy để nhanh. Nếu FFmpeg từ chối hoặc file tổng
    không hợp lệ, tầng 2 tự re-encode về H.264/AAC CFR cố định để chịu được
    khác biệt timebase/encoder giữa các segment (đặc biệt khi một vài segment
    đã fallback GPU -> CPU).
    """
    ffmpeg = find_ffmpeg()
    files = [Path(x) for x in files]
    if not files:
        raise RuntimeError('Không có segment để ghép.')
    for f in files:
        _validate_media_file(f, require_audio=require_audio)

    out_path = normalize_mp4_output(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    # Stage the result and promote only on success: a merge failure must not
    # overwrite an existing final video or leave a half-written final file.
    work_out = out_path.with_name(out_path.stem + '.__merging.mp4')
    concat = out_path.parent / ('._alltool_concat_' + str(os.getpid()) + '.txt')
    try:
        if work_out.exists(): work_out.unlink()
    except OSError:
        pass
    with concat.open('w', encoding='utf-8') as f:
        for item in files:
            safe = str(item.resolve()).replace("'", "'\\''")
            f.write(f"file '{safe}'\n")

    copy_error = None
    try:
        if log: log('[MERGE 1/2] Thử ghép nhanh stream-copy...')
        cmd = [
            ffmpeg, '-y', '-hide_banner', '-fflags', '+genpts',
            '-f', 'concat', '-safe', '0', '-i', str(concat),
            '-map', '0:v:0', '-map', '0:a:0?',
            '-c', 'copy', '-avoid_negative_ts', 'make_zero',
            '-video_track_timescale', '90000', '-movflags', '+faststart',
            '-f', 'mp4', str(work_out)
        ]
        _run_ffmpeg(cmd, log)
        _validate_media_file(work_out, require_audio=require_audio)
    except Exception as e:
        copy_error = e
        try:
            if work_out.exists(): work_out.unlink()
        except Exception:
            pass
        if log:
            log('[MERGE] Stream-copy không ổn → tự chuyển sang ghép re-encode an toàn.')
            log('[MERGE] Lý do tầng 1: ' + str(e).splitlines()[-1])

    else:
        # Merge/QA succeeded. A destination access error is NOT a codec failure;
        # re-encoding the whole film would waste hours without fixing it.
        try:
            os.replace(work_out, out_path)
        except OSError as e:
            raise RuntimeError(f'Video ghép đã hoàn tất nhưng không thể lưu file đích: {out_path}\n{e}') from e
        finally:
            try: concat.unlink()
            except OSError: pass
        if log: log('[MERGE] Ghép nhanh thành công.')
        return out_path

    # Tầng 2: concat demuxer + re-encode. Tất cả segment của tool đã cùng
    # resolution/fps; bước này làm phẳng timebase, codec parameters và audio.
    vf = f"fps={int(fps)},format=yuv420p"
    if w and h:
        vf = _scale_filter(int(w), int(h), int(fps))
    base = [
        ffmpeg, '-y', '-hide_banner', '-fflags', '+genpts+discardcorrupt',
        '-err_detect', 'ignore_err', '-f', 'concat', '-safe', '0', '-i', str(concat),
        '-map', '0:v:0',
        '-vf', vf,
        '-r', str(int(fps)), '-pix_fmt', 'yuv420p',
        '-map_metadata', '-1', '-map_chapters', '-1',
        '-max_muxing_queue_size', '4096', '-avoid_negative_ts', 'make_zero',
        '-video_track_timescale', '90000', '-movflags', '+faststart'
    ]
    if require_audio:
        base[base.index('-vf'):base.index('-vf')] = ['-map', '0:a:0?']
        base += ['-af', 'aresample=48000,aformat=channel_layouts=stereo', '-c:a', 'aac', '-b:a', '192k', '-ar', '48000']
    else:
        base += ['-an']
    cpu = base + _codec_args(False) + ['-f', 'mp4', str(work_out)]
    gpu = base + _codec_args(True) + ['-f', 'mp4', str(work_out)]
    try:
        if log: log('[MERGE 2/2] Đang re-encode video tổng để đảm bảo tương thích...')
        _run_with_gpu_fallback(gpu, cpu, bool(use_gpu), log)
        _validate_media_file(work_out, require_audio=require_audio)
        os.replace(work_out, out_path)
        if log: log('[MERGE] Re-encode ghép tổng thành công.')
        return out_path
    except Exception as e:
        try:
            if work_out.exists(): work_out.unlink()
        except OSError:
            pass
        raise RuntimeError(
            'Ghép tổng thất bại cả 2 tầng.\n'
            f'- Stream-copy: {copy_error}\n'
            f'- Re-encode: {e}'
        )
    finally:
        try: concat.unlink()
        except Exception: pass

def build_image_effect(effect, intensity, w, h, fps, duration, seed=1, safe_mode=False):
    """Build smooth Zoom/Pan motion with adaptive oversampling.

    Supports:
    - single effects: Zoom In/Out, Pan 4 hướng
    - combo effects (smooth continuity, no jump):
      * Zoom In → Pan Hướng (2 pha nối mượt)
      * Zoom In + Pan Hướng (đồng thời)
    """
    total = max(2, int(round(duration * fps)))
    zmax = float(intensity)
    if zmax <= 1.0:
        raise ValueError('Cường độ phải lớn hơn 1.0 (ví dụ 1.3).')

    name = effect
    if name.startswith('Không'):
        return f"scale={w}:{h}:force_original_aspect_ratio=decrease:force_divisible_by=2:flags=lanczos,pad={w}:{h}:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1,fps={fps},format=yuv420p"

    # Adaptive oversampling for stability at higher worker counts.
    longest = max(int(w), int(h))
    if safe_mode:
        over = 1.0
    elif longest <= 1920:
        over = 2.0
    elif longest <= 2560:
        over = 1.5
    else:
        over = 1.0

    mid_w = max(2, int(round(w * over / 2.0)) * 2)
    mid_h = max(2, int(round(h * over / 2.0)) * 2)
    base = f"scale={mid_w}:{mid_h}:force_original_aspect_ratio=increase:flags=lanczos,crop={mid_w}:{mid_h},setsar=1"

    denom = max(1, total - 1)
    t = f"(on/{denom})"
    ease = lambda u: f"(({u})*({u})*({u})*(10-15*({u})+6*({u})*({u})))"
    prog = f"(0.08*({t})+0.92*{ease(t)})"
    dz = zmax - 1.0

    # Helpers
    def center_x():
        return 'iw/2-(iw/zoom/2)'
    def center_y():
        return 'ih/2-(ih/zoom/2)'
    def pan_x(direction, p):
        return f"(iw-iw/zoom)*(1-({p}))" if direction == 'Trái' else f"(iw-iw/zoom)*({p})"
    def pan_y(direction, p):
        return f"(ih-ih/zoom)*(1-({p}))" if direction == 'Lên' else f"(ih-ih/zoom)*({p})"

    z = x = y = None

    # Sequential: Zoom In -> Pan Direction
    if name.startswith('Zoom In → Pan '):
        direction = name.split('Zoom In → Pan ', 1)[1].strip()
        split = '0.40'
        p1_raw = f"min(max(({t})/{split},0),1)"
        p2_raw = f"min(max((({t})-{split})/(1-{split}),0),1)"
        p1 = f"(0.08*({p1_raw})+0.92*{ease(p1_raw)})"
        p2 = f"(0.08*({p2_raw})+0.92*{ease(p2_raw)})"
        z = f"if(lte({t},{split}),1+({dz:.10f})*{p1},{zmax:.10f})"
        if direction in ('Trái','Phải'):
            x_pan = pan_x(direction, p2)
            x = f"if(lte({t},{split}),{center_x()},{x_pan})"
            y = center_y()
        else:
            y_pan = pan_y(direction, p2)
            x = center_x()
            y = f"if(lte({t},{split}),{center_y()},{y_pan})"

    # Simultaneous: Zoom In + Pan Direction
    elif name.startswith('Zoom In + Pan '):
        direction = name.split('Zoom In + Pan ', 1)[1].strip()
        z = f"1+({dz:.10f})*{prog}"
        if direction in ('Trái','Phải'):
            x = pan_x(direction, prog)
            y = center_y()
        else:
            x = center_x()
            y = pan_y(direction, prog)

    elif name.startswith('Zoom In'):
        z = f"1+({dz:.10f})*{prog}"
        x = center_x()
        y = center_y()
    elif name.startswith('Zoom Out'):
        z = f"{zmax:.10f}-({dz:.10f})*{prog}"
        x = center_x()
        y = center_y()
    elif name.startswith('Pan Trái'):
        z = f"{zmax:.10f}"
        x = pan_x('Trái', prog)
        y = center_y()
    elif name.startswith('Pan Phải'):
        z = f"{zmax:.10f}"
        x = pan_x('Phải', prog)
        y = center_y()
    elif name.startswith('Pan Lên'):
        z = f"{zmax:.10f}"
        x = center_x()
        y = pan_y('Lên', prog)
    elif name.startswith('Pan Xuống'):
        z = f"{zmax:.10f}"
        x = center_x()
        y = pan_y('Xuống', prog)
    else:
        raise ValueError(f'Hiệu ứng không được hỗ trợ: {effect}')

    return (
        f"{base},"
        f"zoompan=z='{z}':x='{x}':y='{y}':d=1:s={mid_w}x{mid_h}:fps={fps},"
        f"scale={w}:{h}:flags=lanczos,setsar=1,fps={fps},format=yuv420p"
    )

def apply_visual_transition(base_video, next_media, out_path, *, trans, duration, total_duration, w, h, fps, use_gpu, next_is_image, log=None):
    """Second-pass visual xfade. Audio is copied from base_video, so its timing is untouched."""
    ffmpeg = find_ffmpeg()
    offset = max(0.0, float(total_duration) - float(duration))
    cmd = [ffmpeg, '-y', '-hide_banner', '-i', str(base_video)]
    if next_is_image:
        cmd += ['-loop', '1', '-framerate', str(fps), '-i', str(next_media)]
    else:
        cmd += ['-stream_loop', '-1', '-i', str(next_media)]
    scale = _scale_filter(w, h, fps)
    # tpad delays the actual next clip until xfade offset while holding its first frame;
    # this makes a video transition begin from the start of the next clip instead of its middle.
    nextf = scale
    fc = (
        f"[0:v]fps={fps},format=yuv420p[va];"
        f"[1:v]{nextf}[vb];"
        f"[va][vb]xfade=transition={trans}:duration={duration:.3f}:offset={offset:.3f}[v]"
    )
    base = cmd + [
        '-filter_complex', fc,
        '-map', '[v]', '-map', '0:a:0?',
        '-t', f'{total_duration:.6f}', '-r', str(fps), '-pix_fmt', 'yuv420p',
        '-c:a', 'copy', '-movflags', '+faststart'
    ]
    cpu = base + _codec_args(False) + [str(out_path)]
    gpu = base + _codec_args(True) + [str(out_path)]
    _run_with_gpu_fallback(gpu, cpu, use_gpu, log)
    return Path(out_path)


class VideoFrame(ctk.CTkFrame):
    def __init__(self, master, on_back):
        super().__init__(master, fg_color='#101026')
        self.on_back=on_back
        self.busy=False
        self._active_job=None
        self._pair_lock_path=None
        self._build()

    def _build(self):
        top=ctk.CTkFrame(self,fg_color='#0a0a16',height=58,corner_radius=0)
        top.pack(fill='x'); top.pack_propagate(False)
        ctk.CTkButton(top,text='← Quay Lại Dashboard',width=160,fg_color='#d9534f',hover_color='#c64541',command=self.on_back).pack(side='left',padx=12,pady=10)
        ctk.CTkLabel(top,text='GHÉP / TẠO VIDEO',font=('Segoe UI',18,'bold'),text_color='#e2e8f0').pack(side='left',padx=12)

        self.gpu=ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(top,text='GPU',variable=self.gpu,text_color='#e2e8f0').pack(side='right',padx=(5,12))
        self.gpu_test_btn=ctk.CTkButton(top,text='TEST NVENC',width=102,command=self.test_gpu_nvenc)
        self.gpu_test_btn.pack(side='right',padx=(4,6))
        self.quality=ctk.StringVar(value='1080p'); self.ratio=ctk.StringVar(value='16:9'); self.threads=ctk.StringVar(value='2')
        ctk.CTkOptionMenu(top,values=['720p','1080p','2K','4K'],variable=self.quality,width=90).pack(side='right',padx=5)
        ctk.CTkOptionMenu(top,values=['16:9','9:16'],variable=self.ratio,width=75).pack(side='right',padx=5)
        ctk.CTkLabel(top,text='Ratio / Video:',text_color='#cbd5e1').pack(side='right',padx=4)
        ctk.CTkOptionMenu(top,values=['1','2','3','4','5','6'],variable=self.threads,width=60).pack(side='right',padx=5)
        ctk.CTkLabel(top,text='Luồng:',text_color='#cbd5e1').pack(side='right',padx=4)

        self.tabs=ctk.CTkTabview(self,fg_color='#16163a',segmented_button_selected_color='#7c6cf0',segmented_button_selected_hover_color='#8c7cff')
        self.tabs.pack(fill='both',expand=True,padx=12,pady=(12,6))
        t2=self.tabs.add('Audio + Video')
        t3=self.tabs.add('Ảnh + SRT')
        t4=self.tabs.add('Ảnh + Audio (1:1)')
        self._setup_video_tab(t2)
        self._setup_image_tab(t3)
        self._setup_image_audio_tab(t4)

        bottom=ctk.CTkFrame(self,fg_color='#0a0a16',height=150,corner_radius=0)
        bottom.pack(fill='x',padx=12,pady=(0,12)); bottom.pack_propagate(False)
        self.status=ctk.StringVar(value='Sẵn sàng.')
        statrow=ctk.CTkFrame(bottom,fg_color='transparent')
        statrow.pack(fill='x',padx=10,pady=(4,0))
        ctk.CTkLabel(statrow,textvariable=self.status,text_color='#fbbf24',anchor='w').pack(side='left',fill='x',expand=True)
        ctk.CTkButton(statrow,text='SAO CHÉP LOG',width=126,fg_color='#36576c',command=self.copy_video_log).pack(side='right',padx=(6,0))
        self.progress=ctk.CTkProgressBar(bottom); self.progress.set(0); self.progress.pack(fill='x',padx=10,pady=4)
        self.logbox=ctk.CTkTextbox(bottom,height=90,fg_color='#08081e',text_color='#00d4ff',font=('Consolas',11))
        self.logbox.pack(fill='both',expand=True,padx=10,pady=(2,8))

    def _path_row(self,parent,label,var,save=False, browse_mode='dir', filetypes=None):
        row=ctk.CTkFrame(parent,fg_color='transparent'); row.pack(fill='x',padx=12,pady=4)
        ctk.CTkLabel(row,text=label,width=170,anchor='w',text_color='#cbd5e1').pack(side='left')
        ctk.CTkEntry(row,textvariable=var).pack(side='left',fill='x',expand=True,padx=(0,6))
        def browse():
            if save:
                p=filedialog.asksaveasfilename(defaultextension='.mp4',filetypes=[('MP4','*.mp4')])
            elif browse_mode == 'file':
                p=filedialog.askopenfilename(filetypes=filetypes or [('Tất cả','*.*')])
            else:
                p=filedialog.askdirectory()
            if p: var.set(p)
        ctk.CTkButton(row,text='...',width=42,command=browse).pack(side='left')

    def _make_scrollable_body(self, parent):
        """Create a real vertically scrollable body using native tkinter Canvas.

        The bundled lightweight customtkinter compatibility layer does not implement
        CTkScrollableFrame scrolling, so this helper is used for long settings pages.
        """
        outer=ctk.CTkFrame(parent,fg_color='#16163a')
        outer.pack(fill='both',expand=True)
        canvas=tk.Canvas(outer,bg='#16163a',highlightthickness=0,bd=0)
        scrollbar=tk.Scrollbar(outer,orient='vertical',command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right',fill='y')
        canvas.pack(side='left',fill='both',expand=True)
        inner=tk.Frame(canvas,bg='#16163a')
        window_id=canvas.create_window((0,0),window=inner,anchor='nw')

        def refresh(_event=None):
            try:
                canvas.configure(scrollregion=canvas.bbox('all'))
            except Exception:
                pass

        def fit_width(event):
            try:
                canvas.itemconfigure(window_id,width=max(1,event.width))
                refresh()
            except Exception:
                pass

        def wheel(event):
            try:
                if not canvas.winfo_ismapped():
                    return
                delta=getattr(event,'delta',0)
                if delta:
                    canvas.yview_scroll(int(-delta/120), 'units')
                elif getattr(event,'num',None)==4:
                    canvas.yview_scroll(-3,'units')
                elif getattr(event,'num',None)==5:
                    canvas.yview_scroll(3,'units')
            except Exception:
                pass

        inner.bind('<Configure>',refresh)
        canvas.bind('<Configure>',fit_width)
        # Windows/macOS mouse wheel; Linux wheel buttons also supported. The mapped
        # check prevents this hidden tab from consuming wheel input on other tabs.
        self.bind_all('<MouseWheel>',wheel,add='+')
        self.bind_all('<Button-4>',wheel,add='+')
        self.bind_all('<Button-5>',wheel,add='+')
        return inner

    def _setup_video_tab(self,parent):
        body=self._make_scrollable_body(parent)
        self.t2_audio=ctk.StringVar(); self.t2_video=ctk.StringVar(); self.t2_out=ctk.StringVar()
        ctk.CTkLabel(body,text='FOLDER AUDIO + VIDEO (Audio giữ nguyên 100%)',font=('Arial',16,'bold'),text_color='#00d4ff').pack(anchor='w',padx=12,pady=(12,6))
        self._path_row(body,'Folder Audio:',self.t2_audio); self._path_row(body,'Folder Video:',self.t2_video); self._path_row(body,'Lưu file:',self.t2_out,save=True)

        card=ctk.CTkFrame(body,fg_color='#0e0e2e',border_color='#2a1a4a',border_width=1); card.pack(fill='x',padx=12,pady=8)
        ctk.CTkLabel(card,text='ĐỒNG BỘ (Audio giữ nguyên – Video điều chỉnh)',font=('Arial',14,'bold'),text_color='#ffd700').pack(anchor='w',padx=10,pady=(8,4))
        self.sync=ctk.StringVar(value=SYNC_MODES[0])
        ctk.CTkOptionMenu(card,values=SYNC_MODES,variable=self.sync).pack(anchor='w',padx=10,pady=4)
        row=ctk.CTkFrame(card,fg_color='transparent'); row.pack(fill='x',padx=10,pady=4)
        self.min_speed=ctk.StringVar(value='0.5'); self.max_speed=ctk.StringVar(value='2.0')
        ctk.CTkLabel(row,text='Tốc độ tối thiểu:',text_color='#9ca3af').pack(side='left')
        ctk.CTkOptionMenu(row,values=['0.25','0.5','0.75','1.0'],variable=self.min_speed,width=80).pack(side='left',padx=5)
        ctk.CTkLabel(row,text='x     Tối đa:',text_color='#9ca3af').pack(side='left',padx=(10,0))
        ctk.CTkOptionMenu(row,values=['1.5','2.0','3.0','4.0'],variable=self.max_speed,width=80).pack(side='left',padx=5)

        self.video_vol=ctk.StringVar(value='0.0'); self.vocal=ctk.StringVar(value=VOCAL_MODES[0]); self.export_t2=ctk.BooleanVar(value=False)
        row=ctk.CTkFrame(card,fg_color='transparent'); row.pack(fill='x',padx=10,pady=4)
        ctk.CTkLabel(row,text='Volume audio gốc video (0 = chỉ audio ngoài):',text_color='#00e5cc').pack(side='left')
        ctk.CTkOptionMenu(row,values=['0.0','0.1','0.2','0.3','0.5','0.7','1.0'],variable=self.video_vol,width=80).pack(side='left',padx=8)
        row=ctk.CTkFrame(card,fg_color='transparent'); row.pack(fill='x',padx=10,pady=4)
        ctk.CTkLabel(row,text='Giọng nói trong video gốc:',text_color='#ffd700').pack(side='left')
        ctk.CTkOptionMenu(row,values=VOCAL_MODES,variable=self.vocal,width=220).pack(side='left',padx=8)
        ctk.CTkCheckBox(card,text='Xuất từng video riêng (không ghép tổng)',variable=self.export_t2).pack(anchor='w',padx=10,pady=(4,10))
        ctk.CTkLabel(card,text='Engine ổn định: segment lỗi sẽ tự retry tuần tự; ghép lỗi tự re-encode.',text_color='#7dd3fc').pack(anchor='w',padx=10,pady=(0,8))
        self.t2_trans=self._transition_ui(body,'t2')
        self.run2=ctk.CTkButton(body,text='CHẠY SIÊU TỐC (MODE VIDEO)',height=45,fg_color='#ff2266',hover_color='#d91e58',font=('Arial',15,'bold'),command=self.run_tab2)
        self.run2.pack(fill='x',padx=12,pady=12)

    def _setup_image_tab(self,parent):
        body=self._make_scrollable_body(parent)
        self.t3_audio_file=ctk.StringVar(); self.t3_srt=ctk.StringVar(); self.t3_img=ctk.StringVar(); self.t3_out=ctk.StringVar()
        ctk.CTkLabel(body,text='ẢNH → VIDEO THEO SRT TIMELINE',font=('Arial',16,'bold'),text_color='#b44aff').pack(anchor='w',padx=12,pady=(12,2))
        ctk.CTkLabel(
            body,
            text='SRT quyết định điểm đổi ảnh. Nếu SRT có gap, giữ ảnh trước; không dịch ảnh tiếp theo xuất hiện sớm.',
            text_color='#8b8ba8'
        ).pack(anchor='w',padx=12,pady=(0,6))
        self._path_row(body,'Audio tổng (tùy chọn):',self.t3_audio_file,browse_mode='file',filetypes=[('Audio','*.mp3 *.wav *.m4a *.aac *.flac *.ogg *.opus'),('Tất cả','*.*')])
        self._path_row(body,'File SRT timeline:',self.t3_srt,browse_mode='file',filetypes=[('SRT','*.srt'),('Tất cả','*.*')])
        self._path_row(body,'Folder Ảnh:',self.t3_img)
        self._path_row(body,'Lưu video tổng:',self.t3_out,save=True)

        timeline_card=ctk.CTkFrame(body,fg_color='#0e0e2e',border_color='#2a1a4a',border_width=1); timeline_card.pack(fill='x',padx=12,pady=8)
        ctk.CTkLabel(timeline_card,text='SRT TIMELINE LOCK',font=('Arial',14,'bold'),text_color='#ffd700').pack(anchor='w',padx=10,pady=(8,3))
        ctk.CTkLabel(
            timeline_card,
            text='• SRT quyết định toàn bộ thời lượng ảnh. Không còn chế độ nhập số giây/ảnh.\n• END cue trước = START cue sau. Không cộng gap, không cộng thời gian chuyển cảnh.\n• Timestamp SRT được quy đổi về absolute frame boundary theo FPS để tránh drift tích lũy.',
            justify='left',text_color='#7dd3fc'
        ).pack(anchor='w',padx=10,pady=(0,8))

        card=ctk.CTkFrame(body,fg_color='#0e0e2e',border_color='#2a1a4a',border_width=1); card.pack(fill='x',padx=12,pady=8)
        ctk.CTkLabel(card,text='CHỌN CHUYỂN ĐỘNG ẢNH:',font=('Arial',14,'bold'),text_color='#ffd700').pack(anchor='w',padx=10,pady=(8,2))
        ctk.CTkLabel(
            card,
            text='Dùng chung engine Zoom/Pan hiện có. Chọn 1 hiệu ứng để tất cả ảnh cùng chuyển động; chọn nhiều để tool luân phiên ổn định giữa các ảnh.',
            text_color='#8b8ba8'
        ).pack(anchor='w',padx=10,pady=(0,6))

        self.effect_vars = {}
        effects_grid=ctk.CTkFrame(card,fg_color='transparent'); effects_grid.pack(fill='x',padx=10,pady=(0,6))
        for col in range(3):
            effects_grid.grid_columnconfigure(col, weight=1)
        defaults={'Pan Trái','Pan Phải','Pan Lên','Pan Xuống'}
        for idx,name in enumerate(EFFECTS):
            var=ctk.BooleanVar(value=(name in defaults))
            self.effect_vars[name]=var
            ctk.CTkCheckBox(effects_grid,text=name,variable=var,text_color='#e5e7eb').grid(row=idx//3,column=idx%3,sticky='w',padx=4,pady=4)

        preset=ctk.CTkFrame(card,fg_color='transparent'); preset.pack(fill='x',padx=10,pady=(0,6))
        def set_effects(names):
            wanted=set(names)
            for n,v in self.effect_vars.items():
                v.set(n in wanted)
        ctk.CTkButton(preset,text='Chọn Zoom + Pan',width=130,command=lambda:set_effects(BASE_EFFECTS)).pack(side='left',padx=(0,6))
        ctk.CTkButton(preset,text='Chọn 4 Pan',width=110,command=lambda:set_effects(['Pan Trái','Pan Phải','Pan Lên','Pan Xuống'])).pack(side='left',padx=6)
        ctk.CTkButton(preset,text='Chọn 2 Zoom',width=110,command=lambda:set_effects(['Zoom In (phóng to)','Zoom Out (thu nhỏ)'])).pack(side='left',padx=6)
        ctk.CTkButton(preset,text='Chọn Combo Zoom+Pan',width=170,command=lambda:set_effects(COMBO_EFFECTS)).pack(side='left',padx=6)
        ctk.CTkButton(preset,text='Bỏ chọn',width=90,fg_color='#555566',hover_color='#666677',command=lambda:set_effects([])).pack(side='left',padx=6)

        row=ctk.CTkFrame(card,fg_color='transparent'); row.pack(fill='x',padx=10,pady=6)
        self.intensity=ctk.StringVar(value='1.20'); self.fps=ctk.StringVar(value='60')
        ctk.CTkLabel(row,text='Cường độ (>1.0):',text_color='#9ca3af').pack(side='left')
        ctk.CTkEntry(row,textvariable=self.intensity,width=85).pack(side='left',padx=6)
        ctk.CTkLabel(row,text='FPS:',text_color='#9ca3af').pack(side='left',padx=(12,0))
        ctk.CTkOptionMenu(row,values=['24','25','30','50','60'],variable=self.fps,width=70).pack(side='left',padx=6)
        ctk.CTkLabel(row,text='60 FPS = boundary tối đa khoảng ±8.33 ms; 30 FPS ≈ ±16.67 ms.',text_color='#7dd3fc').pack(side='left',padx=8)

        output_card=ctk.CTkFrame(body,fg_color='#0e0e2e',border_color='#2a1a4a',border_width=1); output_card.pack(fill='x',padx=12,pady=8)
        ctk.CTkLabel(output_card,text='XUẤT VIDEO',font=('Arial',14,'bold'),text_color='#ffd700').pack(anchor='w',padx=10,pady=(8,3))
        ctk.CTkLabel(
            output_card,
            text='Chế độ SRT luôn xuất 1 video tổng liền mạch. Không xuất video lẻ theo từng cue.',
            text_color='#e5e7eb'
        ).pack(anchor='w',padx=10,pady=(2,8))

        # SRT strict mode uses a hard boundary at the exact cue frame. Xfade is
        # intentionally disabled because it would overlap the next image before
        # the SRT boundary. Keep internal variables so shared settings code works.
        self.t3_trans=(ctk.StringVar(value='Tắt'),ctk.StringVar(value='none'),ctk.StringVar(value='0.0'))
        self.run3=ctk.CTkButton(body,text='CHẠY ẢNH → VIDEO THEO SRT',height=45,fg_color='#7c3aed',hover_color='#6d28d9',font=('Arial',15,'bold'),command=self.run_tab3)
        self.run3.pack(fill='x',padx=12,pady=12)

    def _transition_ui(self,parent,prefix):
        card=ctk.CTkFrame(parent,fg_color='#0e0e2e',border_color='#2a1a4a',border_width=1); card.pack(fill='x',padx=12,pady=8)
        ctk.CTkLabel(card,text='CHUYỂN CẢNH (58 kiểu)',font=('Arial',14,'bold'),text_color='#ffd700').pack(anchor='w',padx=10,pady=(8,4))
        row=ctk.CTkFrame(card,fg_color='transparent'); row.pack(fill='x',padx=10,pady=5)
        group=ctk.StringVar(value='Tắt'); item=ctk.StringVar(value='none'); dur=ctk.StringVar(value='0.5')
        ctk.CTkLabel(row,text='Nhóm:',text_color='#9ca3af').pack(side='left')
        item_cb=ctk.CTkOptionMenu(row,values=['none'],variable=item,width=160); item_cb.pack(side='left',padx=5)
        def on_group(v):
            vals=TRANSITION_GROUPS.get(v,['none'])
            show=['Random']+vals if v!='Tắt' else ['none']
            item_cb.configure(values=show); item.set(show[0])
        ctk.CTkOptionMenu(row,values=list(TRANSITION_GROUPS),variable=group,command=on_group,width=160).pack(side='left',padx=(5,10))
        ctk.CTkLabel(row,text='Kiểu:',text_color='#9ca3af').pack(side='left')
        ctk.CTkLabel(row,text='Dài:',text_color='#9ca3af').pack(side='left',padx=(12,0))
        ctk.CTkOptionMenu(row,values=['0.3','0.4','0.5','0.8','1.0','1.5'],variable=dur,width=75).pack(side='left',padx=5)
        ctk.CTkLabel(card,text='Chuyển cảnh được bake vào cuối từng đoạn, audio vẫn giữ đúng thời lượng.',text_color='#777799').pack(anchor='w',padx=10,pady=(0,8))
        return (group,item,dur)

    def copy_video_log(self):
        content=self.logbox.get('1.0','end-1c')
        self.clipboard_clear()
        self.clipboard_append(content)
        self.update()
        self.status.set(f'Đã sao chép {len(content):,} ký tự log.')

    def log(self,msg):
        def ui():
            self.logbox.insert('end',str(msg)+'\n'); self.logbox.see('end')
        self.after(0,ui)

    def set_progress(self,done,total,status=None):
        def ui():
            self.progress.set(done/max(1,total))
            if status: self.status.set(status)
        self.after(0,ui)

    def _set_busy(self,b):
        self.busy=b
        st='disabled' if b else 'normal'
        self.run2.configure(state=st); self.run3.configure(state=st); self.run4.configure(state=st); self.gpu_test_btn.configure(state=st)
        self.cancel_pair_button.configure(state=('normal' if b and self._active_job=='pairs' else 'disabled'))
        if not b: self._active_job=None

    def test_gpu_nvenc(self):
        """User-triggered hardware test; run silently in a worker thread."""
        if self.busy:
            return
        self._set_busy(True)
        self.status.set('Đang kiểm tra mã hóa NVIDIA NVENC...')
        self.log('[GPU] Kiểm tra thủ công NVENC: test encoder, không dùng ảnh dự án.')
        test_w,test_h=get_resolution(self.ratio.get(),self.quality.get())
        def work():
            ok = _preflight_nvenc(self.log, width=test_w, height=test_h, fps=60)
            def finish():
                self._set_busy(False)
                if ok:
                    self.gpu.set(True)
                    self.status.set('GPU NVENC PASS — có thể bật mã hóa GPU.')
                else:
                    self.status.set('GPU NVENC FAIL — xem log; tool sẽ dùng CPU khi chạy.')
            self.after(0, finish)
        threading.Thread(target=work, daemon=True).start()

    def _settings(self, mode):
        w,h=get_resolution(self.ratio.get(),self.quality.get())
        group,item,dur=(self.t2_trans if mode==2 else self.t3_trans)
        return {
            'w':w,'h':h,'use_gpu':bool(self.gpu.get()),'threads':max(1,int(self.threads.get() or 1)),
            'trans_group':group.get(),'trans_item':item.get(),'trans_dur':float(dur.get()),
        }

    def _setup_image_audio_tab(self,parent):
        body=self._make_scrollable_body(parent)
        self.t4_img=ctk.StringVar(); self.t4_audio=ctk.StringVar(); self.t4_out=ctk.StringVar()
        self.t4_fps=ctk.StringVar(value='30')
        self.t4_intensity=ctk.StringVar(value='1.20')
        self.t4_effect_vars={}
        self.t4_save_clips=ctk.BooleanVar(value=False)
        self.pair_cancel_event=threading.Event()
        ctk.CTkLabel(body,text='GHÉP 1 ẢNH + 1 AUDIO → 1 VIDEO TỔNG',font=('Arial',17,'bold'),text_color='#00d4ff').pack(anchor='w',padx=12,pady=(14,4))
        ctk.CTkLabel(body,text='Ví dụ: 001.png ↔ 001.mp3 ... 100.png ↔ 100.mp3. Độ dài ảnh = độ dài audio tương ứng.',text_color='#b5c8e6').pack(anchor='w',padx=12,pady=(0,8))
        self._path_row(body,'Thư mục Ảnh:',self.t4_img)
        self._path_row(body,'Thư mục Audio:',self.t4_audio)
        self._path_row(body,'Video tổng (.mp4):',self.t4_out,save=True)
        card=ctk.CTkFrame(body,fg_color='#0e0e2e',border_color='#2a1a4a',border_width=1)
        card.pack(fill='x',padx=12,pady=10)
        ctk.CTkLabel(card,text='GHÉP CẶP CHÍNH XÁC · KHÔNG CẦN SRT',font=('Arial',14,'bold'),text_color='#ffd700').pack(anchor='w',padx=12,pady=(12,6))
        ctk.CTkLabel(card,text='• Nếu tên có số: bắt buộc khớp 001–001, 002–002...; không tái sử dụng audio.\n• Nếu tất cả tên không có số: ghép theo thứ tự tự nhiên.\n• Sai số lượng, thiếu hoặc trùng số → dừng trước khi render.\n• Audio được nối liên tục trước, rồi mới ghép vào video để tránh khoảng im giữa clip.',justify='left',text_color='#c9d6ef').pack(anchor='w',padx=12,pady=(0,10))
        motion_card=ctk.CTkFrame(body,fg_color='#0e0e2e',border_color='#2a1a4a',border_width=1)
        motion_card.pack(fill='x',padx=12,pady=8)
        ctk.CTkLabel(motion_card,text='CHỌN CHUYỂN ĐỘNG ẢNH (ĐẦY ĐỦ NHƯ TAB ẢNH + SRT)',font=('Arial',14,'bold'),text_color='#ffd700').pack(anchor='w',padx=10,pady=(8,2))
        ctk.CTkLabel(
            motion_card,
            text='Chọn 1 hiệu ứng để áp dụng cho mọi ảnh; chọn nhiều hiệu ứng để luân phiên theo từng ảnh. Hiệu ứng được render trực tiếp vào video.',
            text_color='#8b8ba8',wraplength=1100,justify='left'
        ).pack(anchor='w',padx=10,pady=(0,6))

        effects_grid=ctk.CTkFrame(motion_card,fg_color='transparent')
        effects_grid.pack(fill='x',padx=10,pady=(0,6))
        for col in range(3):
            effects_grid.grid_columnconfigure(col,weight=1)
        default_motion={'Pan Trái','Pan Phải','Pan Lên','Pan Xuống'}
        for idx,name in enumerate(EFFECTS):
            var=ctk.BooleanVar(value=(name in default_motion))
            self.t4_effect_vars[name]=var
            ctk.CTkCheckBox(effects_grid,text=name,variable=var,text_color='#e5e7eb').grid(
                row=idx//3,column=idx%3,sticky='w',padx=4,pady=4
            )

        preset=ctk.CTkFrame(motion_card,fg_color='transparent')
        preset.pack(fill='x',padx=10,pady=(0,6))
        def set_t4_effects(names):
            wanted=set(names)
            for n,v in self.t4_effect_vars.items():
                v.set(n in wanted)
        ctk.CTkButton(preset,text='Chọn Zoom + Pan',width=130,command=lambda:set_t4_effects(BASE_EFFECTS)).pack(side='left',padx=(0,6))
        ctk.CTkButton(preset,text='Chọn 4 Pan',width=110,command=lambda:set_t4_effects(['Pan Trái','Pan Phải','Pan Lên','Pan Xuống'])).pack(side='left',padx=6)
        ctk.CTkButton(preset,text='Chọn 2 Zoom',width=110,command=lambda:set_t4_effects(['Zoom In (phóng to)','Zoom Out (thu nhỏ)'])).pack(side='left',padx=6)
        ctk.CTkButton(preset,text='Chọn Combo Zoom+Pan',width=170,command=lambda:set_t4_effects(COMBO_EFFECTS)).pack(side='left',padx=6)
        ctk.CTkButton(preset,text='Không hiệu ứng',width=115,command=lambda:set_t4_effects(['Không hiệu ứng'])).pack(side='left',padx=6)
        ctk.CTkButton(preset,text='Bỏ chọn',width=90,fg_color='#555566',hover_color='#666677',command=lambda:set_t4_effects([])).pack(side='left',padx=6)

        row=ctk.CTkFrame(motion_card,fg_color='transparent'); row.pack(fill='x',padx=10,pady=(2,10))
        ctk.CTkLabel(row,text='Cường độ (>1.0, ví dụ 1.20):',text_color='#b5c8e6').pack(side='left')
        ctk.CTkEntry(row,textvariable=self.t4_intensity,width=75).pack(side='left',padx=(5,16))
        ctk.CTkLabel(row,text='FPS:',text_color='#b5c8e6').pack(side='left')
        ctk.CTkOptionMenu(row,values=['24','25','30','50','60'],variable=self.t4_fps,width=75).pack(side='left',padx=(5,16))
        ctk.CTkLabel(row,text='Cường độ càng cao, mức phóng/crop càng mạnh.',text_color='#7dd3fc').pack(side='left',padx=8)

        ctk.CTkCheckBox(card,text='Lưu thêm 1 video riêng cho mỗi cặp (ngoài video tổng)',variable=self.t4_save_clips,text_color='#ffffff').pack(anchor='w',padx=12,pady=(0,12))
        actions=ctk.CTkFrame(body,fg_color='transparent'); actions.pack(fill='x',padx=12,pady=10)
        self.run4=ctk.CTkButton(actions,text='GHÉP ẢNH + AUDIO → VIDEO',height=48,fg_color='#167b56',hover_color='#126347',font=('Arial',15,'bold'),command=self.run_tab4)
        self.run4.pack(side='left',fill='x',expand=True,padx=(0,8))
        self.cancel_pair_button=ctk.CTkButton(actions,text='DỪNG SAU ĐOẠN ĐANG CHẠY',height=48,width=210,fg_color='#a04444',hover_color='#873535',command=self.cancel_paired_render,state='disabled')
        self.cancel_pair_button.pack(side='right')
        ctk.CTkLabel(body,text='Dùng cài đặt GPU / độ phân giải / số luồng ở thanh trên. Nếu GPU không tương thích sẽ fallback CPU; log ghi rõ.',text_color='#8ab5e5').pack(anchor='w',padx=12,pady=(0,10))

    def cancel_paired_render(self):
        if self.busy and self._active_job=='pairs':
            self.pair_cancel_event.set()
            self.log('[CANCEL] Đã yêu cầu hủy; các FFmpeg đang render cần kết thúc đoạn hiện tại.')
            self.status.set('Đang yêu cầu hủy ...')

    def run_tab4(self):
        if self.busy: return
        idir=Path(self.t4_img.get().strip()); adir=Path(self.t4_audio.get().strip())
        if not idir.is_dir() or not adir.is_dir():
            messagebox.showwarning('Thiếu thư mục','Phải chọn cả Folder Ảnh và Folder Audio.'); return
        try:
            pairs, mode=strict_pairs(idir,adir)
            out=preflight_mp4_output(self.t4_out.get(),source_paths=[x for pair in pairs for x in pair])
            self.t4_out.set(str(out))
            fps=int(self.t4_fps.get())
            intensity=float(self.t4_intensity.get().replace(',','.'))
            if intensity<=1.0 or intensity>5.0:
                raise ValueError('Cường độ hiệu ứng phải >1.0 và <=5.0.')
            selected_effects=[name for name,var in self.t4_effect_vars.items() if var.get()]
            if not selected_effects:
                raise ValueError('Chưa chọn chuyển động. Hãy chọn ít nhất 1 hiệu ứng hoặc bấm “Không hiệu ứng”.')
            settings=self._settings(3)
            settings.update({'fps':fps,'effects':selected_effects,
                             'intensity':intensity,'timeline_mode':'srt',
                             'srt_timeline':None})
        except Exception as e:
            messagebox.showerror('Dữ liệu đầu vào chưa đúng',str(e)); return
        if out.exists() and not messagebox.askyesno('Video đã tồn tại','Video đích đã tồn tại. Chỉ thay thế sau khi video mới được QA PASS. Tiếp tục?'):
            return
        save_clips=bool(self.t4_save_clips.get())
        export_dir=out.with_name(out.stem+'_CLIPS')
        if save_clips and export_dir.is_dir():
            existing_clips=list(export_dir.glob('*.mp4'))
            if existing_clips and not messagebox.askyesno(
                'Clip lẻ đã tồn tại',
                f'Thư mục clip đã có {len(existing_clips)} file MP4:\n{export_dir}\n\n'
                'Chỉ thay từng clip sau khi bản mới được render và kiểm tra thành công. Tiếp tục?'
            ):
                return
        # Cross-process lock: two separate tool instances must not write the same output/cache.
        lock_path=out.with_name('.'+out.name+'.alltool.lock')
        try:
            fd=os.open(str(lock_path),os.O_CREAT|os.O_EXCL|os.O_WRONLY)
            with os.fdopen(fd,'w',encoding='utf-8') as lock_file:
                lock_file.write(f'pid={os.getpid()}\noutput={out}\n')
        except FileExistsError:
            messagebox.showerror(
                'Đầu ra đang được sử dụng',
                f'Đã có khóa cho đầu ra này:\n{lock_path}\n\n'
                'Có thể một phiên AllToolYT khác đang chạy. Hãy xác nhận tiến trình cũ đã dừng '
                'trước khi tự xóa khóa còn sót sau sự cố.'
            )
            return
        except OSError as e:
            messagebox.showerror('Không tạo được khóa công việc',str(e)); return
        self._pair_lock_path=lock_path
        self.pair_cancel_event.clear()
        self._active_job='pairs'
        self._set_busy(True); self.progress.set(0); self.logbox.delete('1.0','end')
        self.status.set(f'Đã kiểm tra {len(pairs)} cặp. Đang ghép...')
        self.log(f'[PAIR] {len(pairs)} ảnh + {len(pairs)} audio • ghép={mode}.')
        self.log(f'[LOCK] Khóa đầu ra: {lock_path}')
        self.log(f'[FFMPEG] Đang chọn: {find_ffmpeg()}')
        try:
            threading.Thread(target=self._process_image_audio,
                             args=(pairs,out,settings,mode,save_clips),daemon=True).start()
        except Exception:
            try: lock_path.unlink()
            except OSError: pass
            self._pair_lock_path=None
            self._set_busy(False)
            raise

    def _process_image_audio(self,pairs,out,settings,pair_mode,save_clips):
        """Audio master first; per-image video exact-frame; atomic final promotion."""
        cache_root=None
        _RENDER_CONTEXT.cancel_event=self.pair_cancel_event
        try:
            job_id, manifest=job_identity(pairs,out,settings['fps'],settings['w'],settings['h'],settings['effects'],settings['intensity'])
            cache_root=Path(out).parent / ('.'+Path(out).stem+'_image_audio_cache_'+job_id)
            cache_root.mkdir(parents=True,exist_ok=True)
            manifest_path=cache_root/'manifest.json'
            old_manifest=None
            if manifest_path.exists():
                try: old_manifest=json.loads(manifest_path.read_text(encoding='utf-8'))
                except Exception: pass
            if manifest_path.exists() and old_manifest != manifest:
                raise RuntimeError('Manifest cache không khớp nguồn; không dùng cache cũ.')
            if not manifest_path.exists():
                manifest_path.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
            audio_master=cache_root/'continuous_audio.flac'
            timeline_path=cache_root/'audio_timeline.json'
            timings=None
            if audio_master.is_file() and timeline_path.is_file() and old_manifest==manifest:
                try:
                    candidate=json.loads(timeline_path.read_text(encoding='utf-8'))
                    if len(candidate)==len(pairs) and candidate[-1]['end_frame']>0 and probe_media(audio_master)['has_audio']:
                        timings=candidate
                        self.log('[CACHE] Dùng lại audio master và timeline đã giải mã.')
                except Exception: pass
            if timings is None:
                timings=build_gapless_master_audio(
                    pairs,audio_master,settings['fps'],log=self.log,
                    progress=lambda n,total:self.set_progress(0.20*n/total,1,f'Audio {n}/{total}'),
                    cancel_event=self.pair_cancel_event)
                timeline_path.write_text(json.dumps(timings,ensure_ascii=False,indent=2),encoding='utf-8')
            if self.pair_cancel_event.is_set(): raise JobCancelled('Đã hủy; cache audio đã được lưu.')
            fps=settings['fps']
            settings['srt_timeline']=[{
                'frames':t['frames'], 'duration':t['duration'],
                'start_ts':_seconds_to_srt_timestamp(t['start']),
                'end_ts':_seconds_to_srt_timestamp(t['end'])} for t in timings]
            settings['_gpu_disable_event']=threading.Event()
            settings['_gpu_disable_lock']=threading.Lock()
            settings['_gpu_success_event']=threading.Event()
            if settings['use_gpu'] and not _preflight_nvenc(self.log,width=settings['w'],height=settings['h'],fps=fps):
                settings['_gpu_disable_event'].set()
                settings['use_gpu']=False
            self.log(f'[VIDEO] Rendering {len(pairs)} ảnh @ {fps} FPS, {settings["w"]}x{settings["h"]}.')
            results={}; tasks=[]
            for i,(img,audio) in enumerate(pairs):
                seg=cache_root/f'{i+1:04d}.mp4'
                if seg.is_file():
                    try:
                        assert_segment_video(seg,timings[i]['frames'],fps,settings['w'],settings['h'])
                        results[i]=seg
                        continue
                    except Exception:
                        try: seg.unlink()
                        except OSError: pass
                tasks.append((i,img,None,None,seg))
            if results:
                self.log(f'[CACHE] Đã xác minh và tái sử dụng {len(results)} segment hợp lệ.')
            failures={}
            def render(t):
                _RENDER_CONTEXT.cancel_event=self.pair_cancel_event
                try:
                    if self.pair_cancel_event.is_set(): raise JobCancelled('Đã hủy.')
                    i,img,a,next_img,seg=t
                    result=self._render_image_segment(i,img,None,None,seg,settings,False)
                    assert_segment_video(result,timings[i]['frames'],fps,settings['w'],settings['h'])
                    return result
                finally:
                    _RENDER_CONTEXT.cancel_event=None
            with ThreadPoolExecutor(max_workers=settings['threads']) as ex:
                futures={ex.submit(render,t):t for t in tasks}
                for f in as_completed(futures):
                    t=futures[f]; i=t[0]
                    try: results[i]=f.result()
                    except Exception as e:
                        failures[i]=(t,e); self.log(f'[RETRY-QUEUE] Cặp {i+1:04d}: {str(e)[-250:]}')
                    self.set_progress(0.20+0.68*(len(results)+len(failures))/len(pairs),1,f'Render {len(results)+len(failures)}/{len(pairs)}')
            if self.pair_cancel_event.is_set(): raise JobCancelled('Đã hủy. Cache đã giữ lại.')
            for i in sorted(failures):
                self.log(f'[RECOVERY] Thử lại CPU an toàn cặp {i+1:04d}.')
                t,_=failures[i]
                _RENDER_CONTEXT.cancel_event=self.pair_cancel_event
                try:
                    results[i]=self._render_image_segment(*t,settings,True)
                finally:
                    _RENDER_CONTEXT.cancel_event=None
                assert_segment_video(results[i],timings[i]['frames'],fps,settings['w'],settings['h'])
                if self.pair_cancel_event.is_set(): raise JobCancelled('Đã hủy. Cache đã giữ lại.')
            if len(results)!=len(pairs): raise RuntimeError('Có đoạn video bị thiếu. Không ghép thiếu đoạn.')
            if self.pair_cancel_event.is_set(): raise JobCancelled('Đã hủy trước khi ghép tổng.')
            self.set_progress(0.90,1,'Đang ghép video và audio tổng...')
            ordered=[results[i] for i in range(len(pairs))]
            silent=cache_root/'_silent_merged.mp4'
            effective_gpu=bool(settings['use_gpu']) and not settings['_gpu_disable_event'].is_set()
            merge_segments(ordered,silent,self.log,w=settings['w'],h=settings['h'],fps=fps,use_gpu=effective_gpu,require_audio=False)
            total_frames=timings[-1]['end_frame']
            verify_timeline_output(silent,total_frames,fps,self.log)
            assert_segment_video(silent,total_frames,fps,settings['w'],settings['h'])
            staged_output=Path(out).with_name('.'+Path(out).stem+'.__pending_qa.mp4')
            if staged_output.exists(): staged_output.unlink()
            _mux_timeline_audio(silent,audio_master,staged_output,total_frames/fps,self.log)
            self.set_progress(0.96,1,'Đang kiểm tra frame và audio cuối...')
            verify_timeline_output(staged_output,total_frames,fps,self.log)
            assert_segment_video(staged_output,total_frames,fps,settings['w'],settings['h'])
            info=_validate_media_file(staged_output,require_audio=True)
            if abs(info['duration']-total_frames/fps)>max(.08,2/fps):
                raise RuntimeError(f'QA lệch duration final: actual={info["duration"]}, expected={total_frames/fps}')
            os.replace(staged_output,out)
            clip_failures=[]
            clip_successes=0
            clip_cancelled=False
            if save_clips:
                export_dir=Path(out).with_name(Path(out).stem+'_CLIPS')
                export_dir.mkdir(parents=True,exist_ok=True)
                for i,(video_segment,(_,original_audio)) in enumerate(zip(ordered,pairs)):
                    if self.pair_cancel_event.is_set():
                        clip_cancelled=True
                        self.log('[CANCEL] Đã ghép tổng; dừng xuất clip lẻ theo yêu cầu.')
                        break
                    clip=export_dir/f'{i+1:04d}.mp4'
                    staged_clip=export_dir/f'.{i+1:04d}.__pending.mp4'
                    try:
                        if staged_clip.exists(): staged_clip.unlink()
                        _mux_timeline_audio(video_segment,original_audio,staged_clip,timings[i]['frames']/fps,self.log)
                        _validate_media_file(staged_clip,require_audio=True)
                        # Existing clip is replaced only after the new one passes media validation.
                        os.replace(staged_clip,clip)
                        clip_successes+=1
                    except Exception as clip_error:
                        try:
                            if staged_clip.exists(): staged_clip.unlink()
                        except OSError: pass
                        clip_failures.append(f'{i+1:04d}: {clip_error}')
                        self.log('[CLIP-WARNING] '+clip_failures[-1])
                    self.set_progress(.96+.03*(i+1)/len(pairs),1,f'Xuất clip có audio {i+1}/{len(pairs)}')
            clip_export_ok=(not save_clips) or (clip_successes==len(pairs) and not clip_failures and not clip_cancelled)
            report=Path(out).with_name(Path(out).stem+'_QA.txt')
            gpu_used=settings['_gpu_success_event'].is_set()
            gpu_fallback=settings['_gpu_disable_event'].is_set()
            qa_status='PASS' if clip_export_ok else 'PARTIAL_FAIL'
            report.write_text(
                'AllToolYT Mini v2.6.9 - IMAGE AUDIO 1:1\n'
                f'Status: {qa_status} (video tổng đã QA PASS; clip lẻ {clip_successes}/{len(pairs) if save_clips else 0}; cancelled={clip_cancelled})\n'
                f'Pairs: {len(pairs)}\nMatching: {pair_mode}\n'
                f'FPS: {fps}\nResolution: {settings["w"]}x{settings["h"]}\n'
                f'Frames: {total_frames}\nDuration: {total_frames/fps:.6f}s\n'
                f'Audio decoded duration: {sum(x["samples"] for x in timings)/48000:.6f}s\n'
                f'Video: {out}\n'
                f'NVENC encoded at least one segment: {gpu_used}\nCPU fallback occurred: {gpu_fallback}\nFFmpeg: {find_ffmpeg()}\n'
                f'Clips with audio: {clip_successes if save_clips else 0}\n'
                + (f'Clip errors: {clip_failures}\n' if clip_failures else '')
                + 'IMPORTANT: GPU hardware certification is machine-dependent.\n',encoding='utf-8')
            if clip_export_ok:
                self.set_progress(1,1,'Hoàn thành: video tổng và clip lẻ đã QA PASS.')
                self.after(0,lambda:messagebox.showinfo('Đã ghép thành công',
                    f'{len(pairs)} ảnh + {len(pairs)} audio -> 1 video MP4\n\n{out}\n\nBáo cáo QA: {report}'))
                shutil.rmtree(cache_root,ignore_errors=True)
            else:
                self.set_progress(1,1,f'Video tổng QA PASS; clip lẻ chưa hoàn tất ({clip_successes}/{len(pairs)}).')
                self.log(f'[QA PARTIAL_FAIL] Video tổng hợp lệ, nhưng clip lẻ chỉ hoàn thành {clip_successes}/{len(pairs)}. Cache được giữ để phục hồi.')
                self.after(0,lambda:messagebox.showwarning('Video tổng đã tạo; clip lẻ chưa hoàn tất',
                    f'Video tổng đã QA PASS:\n{out}\n\nClip lẻ: {clip_successes}/{len(pairs)}.\n'
                    f'Hủy xuất: {clip_cancelled}\nLỗi clip: {len(clip_failures)}\n'
                    f'Báo cáo QA: {report}\n\nCache được giữ lại để chạy lại phần còn thiếu.'))
        except JobCancelled as e:
            if 'staged_output' in locals() and staged_output.exists():
                try: staged_output.unlink()
                except OSError: pass
            self.log('[CANCEL] '+str(e))
            self.set_progress(0,1,'Đã hủy; giữ cache để chạy lại.')
        except Exception as e:
            if 'staged_output' in locals() and staged_output.exists():
                try: staged_output.unlink()
                except OSError: pass
            self.log('[ERROR] '+str(e))
            self.set_progress(0,1,'Ghép ảnh + audio thất bại. Có thể chạy lại để phục hồi.')
            self.after(0,lambda detail=str(e):messagebox.showerror('Lỗi ghép ảnh + audio',detail))
        finally:
            _RENDER_CONTEXT.cancel_event=None
            lock_path=getattr(self,'_pair_lock_path',None)
            if lock_path:
                try: Path(lock_path).unlink(missing_ok=True)
                except OSError: pass
                self._pair_lock_path=None
            self.after(0,lambda:self._set_busy(False))

    def run_tab2(self):
        if self.busy: return
        vdir=Path(self.t2_video.get().strip()); adir=Path(self.t2_audio.get().strip()) if self.t2_audio.get().strip() else None
        if not vdir.is_dir(): messagebox.showwarning('Thiếu','Chọn Folder Video trước.'); return
        videos=[p for p in vdir.iterdir() if p.is_file() and p.suffix.lower() in VIDEO_EXTS]
        audios=[p for p in adir.iterdir() if p.is_file() and p.suffix.lower() in AUDIO_EXTS] if adir and adir.is_dir() else []
        if not videos: messagebox.showwarning('Thiếu','Không tìm thấy video trong Folder Video.'); return
        out=self.t2_out.get().strip()
        if not self.export_t2.get():
            try:
                out=str(preflight_mp4_output(out, source_paths=[*videos, *audios]))
                self.t2_out.set(out)
            except Exception as e:
                messagebox.showerror('Đường dẫn video đầu ra', str(e)); return
        if self.vocal.get().startswith('AI Demucs'):
            messagebox.showwarning('Demucs','Bản tích hợp có giữ tùy chọn Demucs, nhưng cần cài Demucs riêng. Nếu chưa cài, hãy chọn “Không xử lý” hoặc “Karaoke L-R”.')
        try:
            pairs=pair_files(videos,audios)
        except ValueError as e:
            messagebox.showerror('Sai ghép cặp Video + Audio',str(e)); return
        settings=self._settings(2)
        settings.update({'sync':self.sync.get(),'min_speed':float(self.min_speed.get()),'max_speed':float(self.max_speed.get()),'video_vol':(float(self.video_vol.get()) if audios else max(1.0,float(self.video_vol.get()))),'vocal':self.vocal.get()})
        self._set_busy(True); self.logbox.delete('1.0','end'); self.status.set(f'Chuẩn bị {len(pairs)} video...'); self.progress.set(0)
        threading.Thread(target=self._process_video,args=(pairs,out,settings,bool(self.export_t2.get())),daemon=True).start()

    def run_tab3(self):
        if self.busy:return
        idir=Path(self.t3_img.get().strip())
        audio_total=Path(self.t3_audio_file.get().strip()) if self.t3_audio_file.get().strip() else None
        srt_path=Path(self.t3_srt.get().strip()) if self.t3_srt.get().strip() else None
        if not idir.is_dir(): messagebox.showwarning('Thiếu','Chọn Folder Ảnh trước.'); return
        if not srt_path or not srt_path.is_file(): messagebox.showwarning('Thiếu SRT','Chọn File SRT timeline trước.'); return
        imgs=[p for p in idir.iterdir() if p.is_file() and p.suffix.lower() in IMAGE_EXTS]
        if not imgs: messagebox.showwarning('Thiếu','Không tìm thấy ảnh trong Folder Ảnh.'); return
        if audio_total and not audio_total.is_file(): messagebox.showwarning('Audio tổng','Đường dẫn audio tổng không tồn tại.'); return
        try:
            out = str(preflight_mp4_output(
                self.t3_out.get(), source_paths=[srt_path, audio_total, *imgs]
            ))
            if out != self.t3_out.get().strip():
                self.t3_out.set(out)
        except Exception as e:
            messagebox.showerror('Đường dẫn video đầu ra', str(e)); return

        try:
            intensity=float(self.intensity.get().strip().replace(',', '.'))
            if intensity <= 1.0:
                raise ValueError
        except Exception:
            messagebox.showwarning('Cường độ không hợp lệ','Nhập số lớn hơn 1.0, ví dụ 1.15, 1.3 hoặc 2.0.')
            return

        settings=self._settings(3)
        selected_effects=[name for name,var in self.effect_vars.items() if var.get()]
        if not selected_effects:
            messagebox.showwarning('Chưa chọn hiệu ứng','Hãy chọn ít nhất 1 chuyển động. Có thể chọn “Không hiệu ứng” nếu muốn ảnh đứng yên.')
            return
        settings.update({
            'effects':selected_effects,
            'intensity':intensity,
            'fps':int(self.fps.get()),
            'timeline_mode':'srt',
            'timeline_audio':str(audio_total) if audio_total else None,
            'srt_path':str(srt_path),
            'srt_timeline':None,
        })

        try:
            cues=parse_srt_file(srt_path)
            # SRT master must begin at timeline zero. Small 1 ms BOM/rounding style
            # differences are accepted, larger offsets are rejected rather than hidden.
            if abs(float(cues[0]['start'])) > 0.001:
                raise RuntimeError(f'Cue SRT đầu tiên phải bắt đầu tại 00:00:00,000; hiện tại là {cues[0]["start_ts"]}.')
            timeline=build_srt_timeline(cues, settings['fps'])
        except Exception as e:
            messagebox.showerror('Lỗi SRT', str(e)); return

        imgs_sorted=sorted(imgs, key=natural_key)
        if len(imgs_sorted) != len(timeline):
            messagebox.showwarning(
                'Không khớp số lượng',
                f'Số ảnh ({len(imgs_sorted)}) phải bằng số cue SRT ({len(timeline)}).\nMỗi ảnh tương ứng đúng 1 cue SRT.'
            )
            return

        # Prefer exact numeric matching (001 -> cue 1, 002 -> cue 2...). If all
        # image names contain unique numeric indices, enforce the mapping strictly.
        numeric=[parse_file_index(p) for p in imgs_sorted]
        if all(x is not None for x in numeric) and len(set(numeric)) == len(numeric):
            by_idx={parse_file_index(p):p for p in imgs_sorted}
            cue_indices=[int(c['index']) for c in cues]
            missing=[x for x in cue_indices if x not in by_idx]
            extra=[x for x in by_idx if x not in set(cue_indices)]
            if missing or extra:
                msg=[]
                if missing: msg.append('Thiếu ảnh cho cue: '+', '.join(map(str,missing[:20])))
                if extra: msg.append('Ảnh có số không thuộc SRT: '+', '.join(map(str,extra[:20])))
                messagebox.showwarning('Sai số thứ tự ảnh/SRT','\n'.join(msg)); return
            imgs_sorted=[by_idx[x] for x in cue_indices]

        pairs=[(img,None) for img in imgs_sorted]
        settings['srt_timeline']=timeline

        self._set_busy(True); self.logbox.delete('1.0','end'); self.status.set(f'Chuẩn bị {len(pairs)} ảnh theo SRT...'); self.progress.set(0)
        self.log(f'[OUTPUT] MP4 hợp lệ: {out}')
        self.log(f'[ORDER] {len(pairs)} ảnh ↔ {len(timeline)} cue SRT.')
        self.log(f'[SRT] Timeline master: {srt_path}')
        if settings.get('timeline_audio'):
            self.log(f"[SRT] Audio tổng: {settings['timeline_audio']}")
        self.log(f"[SRT] FPS={settings['fps']} • absolute frame boundaries • 0 gap • 0 xfade overlap.")
        threading.Thread(
            target=self._process_images,
            args=(pairs,out,settings,False,True),
            daemon=True
        ).start()

    def _process_video(self,pairs,out,settings,export_individual):
        temp_root=Path(tempfile.mkdtemp(prefix='alltool_video_'))
        try:
            if export_individual:
                base=Path(out).parent if out else Path(self.t2_video.get().strip())
                segdir=base/'_Output_Video'; segdir.mkdir(parents=True,exist_ok=True)
            else:
                segdir=temp_root
            tasks=[]
            for i,(v,a) in enumerate(pairs):
                nxt=pairs[i+1][0] if i+1<len(pairs) else None
                tasks.append((i,v,a,nxt,segdir/f'{i+1:04d}.mp4'))

            # Match the validated encoder to the actual render. Previously
            # image->video preflight did this, but video->video did not.
            if settings.get('use_gpu'):
                if not _preflight_nvenc(self.log, width=settings['w'], height=settings['h'], fps=30):
                    settings['use_gpu']=False
                    self.log('[GPU] NVENC không khả dụng; tab Video dùng CPU để tránh render lỗi.')

            # PASS 1: render song song như trước để giữ tốc độ.
            done=0; results={}; failed={}
            with ThreadPoolExecutor(max_workers=settings['threads']) as ex:
                futs={ex.submit(self._render_video_segment,*t,settings,False):t for t in tasks}
                for fut in as_completed(futs):
                    t=futs[fut]; i=t[0]
                    try:
                        results[i]=fut.result(); self.log(f'[DONE] video {i+1:04d}')
                    except Exception as e:
                        failed[i]=(t,e)
                        self.log(f'[RETRY-QUEUE] video {i+1:04d} lỗi pass nhanh → đưa vào hàng đợi cứu lỗi.')
                        self.log('  ' + str(e).splitlines()[-1])
                    done+=1; self.set_progress(done,len(tasks),f'Pass nhanh {done}/{len(tasks)} video')

            # PASS 2: mọi job lỗi được retry TUẦN TỰ bằng pipeline an toàn CPU.
            # Việc retry tuần tự tránh NVENC/VRAM/decoder contention khi render nhiều luồng.
            if failed:
                self.log(f'[RECOVERY] Có {len(failed)} segment lỗi. Bắt đầu cứu lỗi tuần tự...')
                recover_done=0
                for i in sorted(failed):
                    t,_old_err=failed[i]
                    try:
                        results[i]=self._render_video_segment(*t,settings,True)
                        self.log(f'[RECOVERED] video {i+1:04d} đã render lại thành công.')
                    except Exception as e:
                        self.log(f'[FAIL-FINAL] video {i+1:04d}: {e}')
                    recover_done+=1
                    self.set_progress(recover_done,len(failed),f'Cứu lỗi {recover_done}/{len(failed)} segment')

            ordered=[results[i] for i in sorted(results)]
            missing=[i+1 for i in range(len(tasks)) if i not in results]
            if missing:
                preview=', '.join(f'{x:04d}' for x in missing[:20])
                if len(missing)>20: preview += ', ...'
                raise RuntimeError(
                    f'Còn {len(missing)} segment không thể cứu sau các tầng fallback: {preview}.\n'
                    'Tool không ghép thiếu đoạn để tránh video tổng sai nội dung.'
                )

            if export_individual:
                self.after(0,lambda:messagebox.showinfo('Hoàn thành',f'Đã xuất {len(ordered)} video riêng vào:\n{segdir}'))
                self.after(0,lambda:self.status.set('Hoàn thành xuất video riêng.'))
            else:
                self.log('Đang ghép file tổng...')
                merge_segments(
                    ordered,out,self.log,
                    w=settings['w'],h=settings['h'],fps=30,use_gpu=settings['use_gpu']
                )
                self.log('Ghép xong video tổng!')
                self.after(0,lambda:messagebox.showinfo('Hoàn thành',f'Đã tạo video:\n{out}'))
                self.after(0,lambda:self.status.set('Hoàn thành!'))
        except Exception as e:
            self.log('[ERROR] '+str(e)); self.after(0,lambda e=e:messagebox.showerror('Lỗi tạo video',str(e))); self.after(0,lambda:self.status.set('Thất bại.'))
        finally:
            if not export_individual: shutil.rmtree(temp_root,ignore_errors=True)
            self.after(0,lambda:self._set_busy(False))

    def _normalize_video_for_recovery(self,src,dst,w,h,fps):
        """Chuẩn hóa video nguồn lỗi/có timestamp lạ về MP4 H.264 CFR sạch."""
        ffmpeg=find_ffmpeg(); dst=Path(dst)
        info=probe_media(src)
        input_flags=['-fflags','+genpts+discardcorrupt','-err_detect','ignore_err','-probesize','100M','-analyzeduration','100M']
        vf=_scale_filter(w,h,fps)
        base=[ffmpeg,'-y','-hide_banner']+input_flags+['-i',str(src),'-map','0:v:0','-vf',vf,'-r',str(fps),'-pix_fmt','yuv420p']
        if info.get('has_audio'):
            cmd=base+['-map','0:a:0?','-af','aresample=48000,aformat=channel_layouts=stereo','-c:a','aac','-b:a','192k','-ar','48000']+_codec_args(False)+['-map_metadata','-1','-map_chapters','-1','-avoid_negative_ts','make_zero','-movflags','+faststart',str(dst)]
            try:
                _run_ffmpeg(cmd,self.log); _validate_media_file(dst,require_audio=False); return dst
            except Exception as e:
                self.log('[RECOVERY] Chuẩn hóa cả audio gốc lỗi → thử video-only. '+str(e).splitlines()[-1])
                try: dst.unlink()
                except Exception: pass
        cmd=base+['-an']+_codec_args(False)+['-map_metadata','-1','-map_chapters','-1','-avoid_negative_ts','make_zero','-movflags','+faststart',str(dst)]
        _run_ffmpeg(cmd,self.log); _validate_media_file(dst,require_audio=False); return dst

    def _normalize_audio_for_recovery(self,src,dst):
        """Chuẩn hóa audio ngoài về WAV 48k stereo; không đổi tốc độ/nội dung."""
        ffmpeg=find_ffmpeg(); dst=Path(dst)
        cmd=[ffmpeg,'-y','-hide_banner','-fflags','+genpts+discardcorrupt','-err_detect','ignore_err','-i',str(src),'-vn','-map','0:a:0','-af','aresample=48000,aformat=channel_layouts=stereo','-c:a','pcm_s16le','-ar','48000','-ac','2',str(dst)]
        _run_ffmpeg(cmd,self.log)
        info=probe_media(dst)
        if not info.get('has_audio') or info.get('duration',0)<=0.05:
            raise RuntimeError('Không chuẩn hóa được audio ngoài.')
        return dst

    def _render_video_segment(self,i,video,audio,next_video,out,settings,recovery=False):
        """Render một segment.

        Pass thường ưu tiên GPU/CPU fallback. Pass recovery chạy tuần tự, chuẩn hóa
        input có timestamp/codec lạ rồi render CPU để tối đa độ ổn định.
        """
        ffmpeg=find_ffmpeg(); w=settings['w']; h=settings['h']; fps=30
        base_out=Path(out); base_out.parent.mkdir(parents=True,exist_ok=True)
        workdir=base_out.parent / f'.recover_{i+1:04d}'
        source_video=Path(video); source_audio=Path(audio) if audio else None
        cleanup=[]

        try:
            if recovery:
                workdir.mkdir(parents=True,exist_ok=True)
                norm_v=workdir/'source_normalized.mp4'
                self.log(f'[RECOVERY] {i+1:04d}: chuẩn hóa video nguồn...')
                source_video=self._normalize_video_for_recovery(source_video,norm_v,w,h,fps); cleanup.append(norm_v)
                if source_audio:
                    norm_a=workdir/'audio_normalized.wav'
                    try:
                        self.log(f'[RECOVERY] {i+1:04d}: chuẩn hóa audio ngoài...')
                        source_audio=self._normalize_audio_for_recovery(source_audio,norm_a); cleanup.append(norm_a)
                    except Exception as e:
                        # Audio ngoài là dữ liệu quan trọng: không thay bằng silence nếu đã được cung cấp.
                        raise RuntimeError(f'Audio ngoài của segment {i+1:04d} không đọc được: {e}')

            vp=probe_media(source_video); src=max(vp['duration'],0.1)
            ap=probe_media(source_audio) if source_audio else None
            target=max((ap['duration'] if ap and ap['duration']>0 else src),0.2)
            sync=settings['sync']; vol=settings['video_vol']; vocal=settings['vocal']
            if vocal.startswith('AI Demucs'):
                vocal='Không xử lý'
            trans=_transition_name(settings['trans_group'],settings['trans_item'],i+1000)
            d=min(settings['trans_dur'],max(0.05,target/3)) if trans and next_video else 0

            temp_base=base_out.with_name(base_out.stem + '.__base.mp4') if d>0 else base_out
            try:
                if temp_base.exists(): temp_base.unlink()
                if base_out.exists() and temp_base != base_out: base_out.unlink()
            except Exception: pass

            input_args=[]
            if recovery:
                input_args += ['-fflags','+genpts+discardcorrupt','-err_detect','ignore_err']
            if sync.startswith('Loop'):
                input_args += ['-stream_loop','-1']
            input_args += ['-i',str(source_video)]
            audio_idx=None
            if source_audio:
                audio_idx=1
                input_args += ['-i',str(source_audio)]

            scale=_scale_filter(w,h,fps)
            if sync.startswith('Speed'):
                # setpts > 1 làm video chậm lại; src/target là hệ số speed đúng với logic cũ.
                speed=max(settings['min_speed'],min(settings['max_speed'],src/target))
                vf0=f"{scale},setpts=PTS/{speed:.8f},tpad=stop_mode=clone:stop_duration={target:.6f},trim=duration={target:.6f},setpts=PTS-STARTPTS"
            elif sync.startswith('Loop'):
                vf0=f"{scale},trim=duration={target:.6f},setpts=PTS-STARTPTS"
            else:
                vf0=f"{scale},tpad=stop_mode=clone:stop_duration={target:.6f},trim=duration={target:.6f},setpts=PTS-STARTPTS"

            fc=[f"[0:v]{vf0}[v]"]
            if audio_idx is not None:
                fc.append(f"[{audio_idx}:a]aresample=48000,aformat=channel_layouts=stereo,apad,atrim=duration={target:.6f}[tts]")
                if vol>0 and vp['has_audio']:
                    orig=_audio_filter_for_original(vocal,vol)
                    fc.append(f"[0:a]{orig},aresample=48000,aformat=channel_layouts=stereo,apad,atrim=duration={target:.6f}[orig]")
                    fc.append("[tts][orig]amix=inputs=2:duration=first:normalize=0[a]")
                else:
                    fc.append('[tts]anull[a]')
            elif vol>0 and vp['has_audio']:
                orig=_audio_filter_for_original(vocal,vol)
                fc.append(f"[0:a]{orig},aresample=48000,aformat=channel_layouts=stereo,apad,atrim=duration={target:.6f}[a]")
            else:
                silence_idx=1
                input_args += ['-f','lavfi','-i','anullsrc=channel_layout=stereo:sample_rate=48000']
                fc.append(f"[{silence_idx}:a]atrim=duration={target:.6f}[a]")

            base=[ffmpeg,'-y','-hide_banner']+input_args+[
                '-filter_complex',';'.join(fc),'-map','[v]','-map','[a]',
                '-t',f'{target:.6f}','-r',str(fps),'-pix_fmt','yuv420p',
                '-c:a','aac','-b:a','192k','-ar','48000',
                '-map_metadata','-1','-map_chapters','-1','-max_muxing_queue_size','4096',
                '-avoid_negative_ts','make_zero','-video_track_timescale','90000','-movflags','+faststart'
            ]
            cpu=base+_codec_args(False)+[str(temp_base)]
            gpu=base+_codec_args(True)+[str(temp_base)]
            if recovery:
                _run_ffmpeg(cpu,self.log)
            else:
                _run_with_gpu_fallback(
                    gpu,cpu,settings['use_gpu'],self.log,
                    gpu_disable_event=settings.get('_gpu_disable_event'),
                    gpu_disable_lock=settings.get('_gpu_disable_lock'),
                    gpu_success_event=settings.get('_gpu_success_event')
                )
            _validate_media_file(temp_base,require_audio=True)

            # Transition không được phép làm mất cả segment. Nếu xfade lỗi, giữ
            # bản base đã render thành công và tiếp tục batch.
            if d>0:
                try:
                    apply_visual_transition(temp_base,next_video,base_out,trans=trans,duration=d,total_duration=target,w=w,h=h,fps=fps,use_gpu=(settings['use_gpu'] and not recovery),next_is_image=False,log=self.log)
                    _validate_media_file(base_out,require_audio=True)
                    try: temp_base.unlink()
                    except Exception: pass
                except Exception as e:
                    self.log(f'[TRANSITION-FALLBACK] {i+1:04d}: xfade lỗi → giữ segment không transition.')
                    self.log('  '+str(e).splitlines()[-1])
                    try:
                        if base_out.exists(): base_out.unlink()
                    except Exception: pass
                    shutil.move(str(temp_base),str(base_out))
            _validate_media_file(base_out,require_audio=True)
            return base_out
        finally:
            if recovery:
                shutil.rmtree(workdir,ignore_errors=True)

    def _process_images(self,pairs,out,settings,save_individual,merge_total):
        timeline_mode = settings.get('timeline_mode') == 'srt'
        job_manifest = None
        cache_dir = None
        success = False
        try:
            if timeline_mode:
                cache_key, job_manifest = _render_job_fingerprint(pairs, settings, out)
                cache_dir = Path(tempfile.gettempdir()) / 'AllToolYT_SRT_Render_Cache' / cache_key
                cache_dir.mkdir(parents=True, exist_ok=True)
                manifest_file = cache_dir / 'manifest.json'
                # A broken or stale manifest is not used as a source of truth.
                if manifest_file.exists():
                    try:
                        recorded = json.loads(manifest_file.read_text(encoding='utf-8'))
                    except (OSError, ValueError):
                        recorded = None
                    if recorded != job_manifest:
                        raise RuntimeError('Cache render không khớp manifest. Vui lòng chọn đầu ra mới để tránh dùng sai video cũ.')
                else:
                    manifest_file.write_text(json.dumps(job_manifest, ensure_ascii=False, indent=2), encoding='utf-8')
                temp_root = cache_dir
                self.log('[CACHE] Thư mục phục hồi job: ' + str(cache_dir))
            else:
                temp_root=Path(tempfile.mkdtemp(prefix='alltool_img_'))
            if timeline_mode:
                save_individual = False
            if save_individual:
                base=Path(out).parent if out else Path(self.t3_img.get().strip())
                segdir=base/'_Output_Images'; segdir.mkdir(parents=True,exist_ok=True)
            else:
                segdir=temp_root

            tasks=[]
            for i,(img,a) in enumerate(pairs):
                # SRT timeline mode is strict: no visual xfade overlap between cues.
                if timeline_mode:
                    nxt = None
                else:
                    nxt=pairs[i+1][0] if merge_total and i+1<len(pairs) else None
                tasks.append((i,img,a,nxt,segdir/f'{i+1:04d}.mp4'))

            self.log(f"[IMAGE-ENGINE] {settings['threads']} luồng • {settings['w']}x{settings['h']} • {settings['fps']} FPS • GPU yêu cầu={'ON' if settings['use_gpu'] else 'OFF'} (chưa xác nhận NVENC)")
            self.log('[IMAGE-ENGINE] Dùng chung engine Zoom/Pan mượt + easing + oversampling thích ứng của tool.')
            if timeline_mode:
                total_frames = settings['srt_timeline'][-1]['end_frame']
                total_sec = settings['srt_timeline'][-1]['end']
                self.log(f"[SRT] {len(settings['srt_timeline'])} cue • tổng timeline {total_sec:.3f}s • {total_frames} frame @ {settings['fps']} FPS")

            # Test NVENC exactly once before a large batch. If it is unavailable,
            # disable GPU immediately instead of failing once for every image.
            settings['_gpu_disable_event']=threading.Event()
            settings['_gpu_disable_lock']=threading.Lock()
            settings['_gpu_success_event']=threading.Event()
            if settings.get('use_gpu') and not _preflight_nvenc(self.log, width=settings['w'], height=settings['h'], fps=settings['fps']):
                settings['_gpu_disable_event'].set()
                settings['use_gpu']=False

            # Reuse only segments from the exact same manifest/settings.
            # A failed final merge must never force hundreds of images to render twice.
            done=0; results={}; failed={}
            render_tasks=[]
            for t in tasks:
                i, img, a, nxt, segment_path = t
                if timeline_mode and segment_path.is_file():
                    try:
                        info=_validate_media_file(segment_path,require_audio=False)
                        expected=settings['srt_timeline'][i]['duration']
                        tolerance=max(0.035, 2.0/settings['fps'])
                        if abs(info['duration'] - expected)>tolerance:
                            raise RuntimeError('Segment cũ không khớp duration SRT')
                        results[i]=segment_path
                        done+=1
                    except Exception:
                        try: segment_path.unlink()
                        except OSError: pass
                        render_tasks.append(t)
                else:
                    render_tasks.append(t)
            if done:
                self.log(f'[CACHE] Phục hồi {done}/{len(tasks)} đoạn cũ đã render; chỉ chạy lại {len(render_tasks)} ảnh còn thiếu.')
                self.set_progress(done,len(tasks),f'Phục hồi {done}/{len(tasks)} ảnh từ cache')

            # PASS 1: run only the remaining tasks.
            with ThreadPoolExecutor(max_workers=settings['threads']) as ex:
                futs={ex.submit(self._render_image_segment,*t,settings,False):t for t in render_tasks}
                for fut in as_completed(futs):
                    t=futs[fut]; i=t[0]
                    try:
                        results[i]=fut.result()
                        self.log(f'[DONE] ảnh {i+1:04d}')
                    except Exception as e:
                        failed[i]=(t,e)
                        self.log(f'[RETRY-QUEUE] ảnh {i+1:04d} lỗi pass nhanh → đưa vào hàng đợi cứu lỗi.')
                        lines=[x for x in str(e).splitlines() if x.strip()]
                        for line in lines[-4:]: self.log('  '+line)
                    done+=1
                    self.set_progress(done,len(tasks),f'Pass nhanh {done}/{len(tasks)} ảnh')

            # PASS 2: only failed jobs are retried. Inputs are staged/normalized
            # locally, oversampling is reduced to 1x and CPU is used for maximum
            # compatibility. Successful jobs are never rendered again.
            if failed:
                self.log(f'[RECOVERY-IMAGE] Có {len(failed)} segment lỗi. Bắt đầu cứu lỗi...')
                recover_done=0
                for i in sorted(failed):
                    t,_old_err=failed[i]
                    try:
                        results[i]=self._render_image_segment(*t,settings,True)
                        self.log(f'[RECOVERED] ảnh {i+1:04d} đã render lại thành công.')
                    except Exception as e:
                        self.log(f'[FAIL-FINAL] ảnh {i+1:04d}:')
                        lines=[x for x in str(e).splitlines() if x.strip()]
                        for line in lines[-8:]: self.log('  '+line)
                    recover_done+=1
                    self.set_progress(recover_done,len(failed),f'Cứu lỗi ảnh {recover_done}/{len(failed)}')

            ordered=[results[i] for i in sorted(results)]
            missing=[i+1 for i in range(len(tasks)) if i not in results]
            if missing:
                preview=', '.join(f'{x:04d}' for x in missing[:30])
                if len(missing)>30: preview += ', ...'
                raise RuntimeError(
                    f'Còn {len(missing)} segment ảnh không thể cứu: {preview}.\n'
                    'Tool không ghép thiếu đoạn để tránh video tổng sai nội dung.'
                )

            messages=[]
            if merge_total:
                self.log('Đang ghép video tổng theo đúng thứ tự ảnh...')
                gpu_event=settings.get('_gpu_disable_event')
                effective_gpu=bool(settings.get('use_gpu')) and not (gpu_event and gpu_event.is_set())

                # SRT image segments are intentionally VIDEO-ONLY. Audio, when
                # supplied, is muxed once after the silent timeline has been joined.
                if timeline_mode:
                    timeline_audio=settings.get('timeline_audio')
                    if timeline_audio:
                        silent_merged=temp_root/'_srt_timeline_video_only.mp4'
                        merge_segments(
                            ordered,silent_merged,self.log,
                            w=settings['w'],h=settings['h'],fps=settings['fps'],
                            use_gpu=effective_gpu,require_audio=False
                        )
                        self.log('[SRT] Ghép hình hoàn tất. Đang mux audio tổng vào video cuối...')
                        total_duration=settings['srt_timeline'][-1]['end']
                        _mux_timeline_audio(silent_merged,timeline_audio,out,total_duration,self.log)
                    else:
                        merge_segments(
                            ordered,out,self.log,
                            w=settings['w'],h=settings['h'],fps=settings['fps'],
                            use_gpu=effective_gpu,require_audio=False
                        )
                else:
                    merge_segments(
                        ordered,out,self.log,
                        w=settings['w'],h=settings['h'],fps=settings['fps'],
                        use_gpu=effective_gpu,require_audio=True
                    )
                if timeline_mode:
                    verify_timeline_output(
                        out, settings['srt_timeline'][-1]['end_frame'], settings['fps'], self.log
                    )
                self.log('Ghép xong video tổng!')
                messages.append(f'Video tổng:\n{out}')
            if save_individual:
                messages.append(f'{len(ordered)} clip riêng:\n{segdir}')

            if merge_total and save_individual:
                self.after(0,lambda:self.status.set('Hoàn thành video tổng + clip riêng.'))
            elif merge_total:
                self.after(0,lambda:self.status.set('Hoàn thành video tổng.'))
            else:
                self.after(0,lambda:self.status.set('Hoàn thành xuất clip ảnh riêng.'))
            success = True
            self.after(0,lambda m='\n\n'.join(messages):messagebox.showinfo('Hoàn thành',m))
        except Exception as e:
            self.log('[ERROR] '+str(e))
            self.after(0,lambda e=e:messagebox.showerror('Lỗi tạo video',str(e)))
            self.after(0,lambda:self.status.set('Thất bại.'))
        finally:
            # Keep verified intermediate videos on failures. A later run with
            # unchanged input/settings will resume instead of re-rendering all.
            if success or not timeline_mode:
                if 'temp_root' in locals():
                    shutil.rmtree(temp_root,ignore_errors=True)
            elif 'temp_root' in locals():
                self.log('[CACHE] Render chưa hoàn tất: đã giữ video trung gian ở ' + str(temp_root))
                self.log('[CACHE] Chạy lại cùng dữ liệu + cài đặt để chỉ render đoạn thiếu hoặc ghép lại.')
            self.after(0,lambda:self._set_busy(False))

    def _stage_local_with_retry(self, src, dst, tries=3):
        """Copy a network/source file locally for recovery, retrying transient LAN errors."""
        src=Path(src); dst=Path(dst); dst.parent.mkdir(parents=True,exist_ok=True)
        last=None
        for attempt in range(1,tries+1):
            try:
                shutil.copy2(src,dst)
                if dst.exists() and dst.stat().st_size>0:
                    return dst
            except Exception as e:
                last=e
            if attempt<tries:
                import time; time.sleep(0.4*attempt)
        raise RuntimeError(f'Không copy được file nguồn về local sau {tries} lần: {src} ({last})')

    def _render_image_segment(self,i,img,audio,next_img,out,settings,recovery=False):
        ffmpeg=find_ffmpeg(); w=settings['w']; h=settings['h']; fps=settings['fps']
        base_out=Path(out); base_out.parent.mkdir(parents=True,exist_ok=True)
        workdir=base_out.parent / f'.img_recover_{i+1:04d}'
        source_img=Path(img); source_audio=Path(audio) if audio else None

        try:
            if recovery:
                workdir.mkdir(parents=True,exist_ok=True)
                # Stage network files locally first. This prevents a transient UNC/LAN
                # read hiccup from killing the second pass.
                img_ext=source_img.suffix.lower() or '.img'
                source_img=self._stage_local_with_retry(source_img,workdir/f'source{img_ext}')
                if source_audio:
                    staged_a=self._stage_local_with_retry(source_audio,workdir/f'audio_source{source_audio.suffix.lower()}')
                    norm_a=workdir/'audio_normalized.wav'
                    source_audio=self._normalize_audio_for_recovery(staged_a,norm_a)
                self.log(f'[RECOVERY-IMAGE] {i+1:04d}: local input + CPU + oversampling an toàn.')

            timeline_mode = settings.get('timeline_mode') == 'srt'
            if not timeline_mode:
                raise RuntimeError('Ảnh → Video v2.6.1 chỉ hỗ trợ SRT timeline; chế độ thời lượng giây đã bị loại bỏ.')
            cue = settings['srt_timeline'][i]
            target = float(cue['duration'])
            frame_count = int(cue['frames'])
            trans = None
            d = 0
            self.log(f"[SRT-CUE] {i+1:04d}: {cue['start_ts']} --> {cue['end_ts']} • {target:.3f}s • {frame_count} frame")
            temp_base=base_out

            try:
                if temp_base.exists(): temp_base.unlink()
                if base_out.exists() and temp_base != base_out: base_out.unlink()
            except Exception:
                pass

            input_args=['-loop','1','-framerate',str(fps),'-i',str(source_img)]

            selected_effects=settings.get('effects') or ['Không hiệu ứng']
            if len(selected_effects) == 1:
                effect_name = selected_effects[0]
            else:
                cycle = i // len(selected_effects)
                order = list(selected_effects)
                random.Random(104729 + cycle * 7919).shuffle(order)
                effect_name = order[i % len(order)]

            self.log(f"[EFFECT] ảnh {i+1:04d}: {effect_name}{' [RECOVERY]' if recovery else ''}")
            effect=build_image_effect(
                effect_name,settings['intensity'],w,h,fps,target,seed=i+1,safe_mode=recovery
            )
            fc=f"[0:v]{effect},trim=duration={target:.6f},setpts=PTS-STARTPTS[v]"

            # Frame count is authoritative in SRT mode. No per-segment audio is
            # created, avoiding AAC encoder padding from affecting cue boundaries.
            base=[ffmpeg,'-y','-hide_banner','-filter_complex_threads','1']+input_args+[
                '-filter_complex',fc,'-map','[v]',
                '-frames:v',str(frame_count),'-r',str(fps),'-pix_fmt','yuv420p',
                '-an','-movflags','+faststart'
            ]
            # SRT strict timeline: disable B-frames so every segment has start_time=0
            # and stream-copy concat does not introduce a 1-2 frame DTS offset.
            timing_tail=['-bf','0','-video_track_timescale','90000','-avoid_negative_ts','make_zero']
            cpu=base+_codec_args(False)+timing_tail+['-threads','2',str(temp_base)]
            gpu=base+_codec_args(True)+timing_tail+['-threads','2',str(temp_base)]

            if recovery:
                _run_ffmpeg(cpu,self.log)
            else:
                _run_with_gpu_fallback(
                    gpu,cpu,settings['use_gpu'],self.log,
                    gpu_disable_event=settings.get('_gpu_disable_event'),
                    gpu_disable_lock=settings.get('_gpu_disable_lock'),
                    gpu_success_event=settings.get('_gpu_success_event')
                )
            _validate_media_file(temp_base,require_audio=False)

            if d>0:
                try:
                    # Transition is cosmetic. If it fails we keep the valid base
                    # segment rather than losing the whole job.
                    apply_visual_transition(
                        temp_base,next_img,base_out,trans=trans,duration=d,total_duration=target,
                        w=w,h=h,fps=fps,use_gpu=(settings['use_gpu'] and not recovery),
                        next_is_image=True,log=self.log
                    )
                    _validate_media_file(base_out,require_audio=False)
                    try: temp_base.unlink()
                    except Exception: pass
                except Exception as e:
                    self.log(f'[TRANSITION-FALLBACK] ảnh {i+1:04d}: xfade lỗi → giữ segment không transition.')
                    lines=[x for x in str(e).splitlines() if x.strip()]
                    for line in lines[-3:]: self.log('  '+line)
                    try:
                        if base_out.exists(): base_out.unlink()
                    except Exception: pass
                    shutil.move(str(temp_base),str(base_out))

            _validate_media_file(base_out,require_audio=False)
            return base_out
        finally:
            if recovery:
                shutil.rmtree(workdir,ignore_errors=True)

