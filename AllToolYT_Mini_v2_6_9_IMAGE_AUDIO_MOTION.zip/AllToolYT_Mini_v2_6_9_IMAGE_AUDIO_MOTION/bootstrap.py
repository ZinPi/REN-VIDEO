import os
import sys
import traceback
from pathlib import Path

ROOT = (Path(sys.executable).resolve().parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent)
LOG = ROOT / 'STARTUP_ERROR.log'


def write_log(text):
    try:
        LOG.write_text(text, encoding='utf-8-sig')
    except Exception:
        pass


def show_error(text):
    try:
        import tkinter as tk
        from tkinter import messagebox
        r = tk.Tk()
        r.withdraw()
        messagebox.showerror(
            'AllToolYT - Lỗi khởi động',
            'Tool không mở được giao diện.\n\n'
            'Chi tiết đã lưu tại:\n' + str(LOG) + '\n\n'
            'Dòng lỗi cuối:\n' + text.splitlines()[-1][:700]
        )
        r.destroy()
    except Exception:
        pass


def main():
    # Xóa log cũ để log luôn phản ánh lần chạy hiện tại.
    try:
        if LOG.exists():
            LOG.unlink()
    except Exception:
        pass
    try:
        import app
        app.run_app()
        return 0
    except Exception:
        detail = traceback.format_exc()
        write_log(detail)
        print('\n===== LOI KHOI DONG ALLTOOLYT =====', file=sys.stderr)
        print(detail, file=sys.stderr)
        show_error(detail)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
