@echo off
chcp 65001 >nul
cd /d "%~dp0"
set "PY=python"
where py >nul 2>nul && set "PY=py -3"
%PY% gpu_diagnostic.py
if errorlevel 1 echo Loi chay diagnostic. Kiem tra cai dat Python va FFmpeg.
echo.
echo Neu GPU khong duoc, gui file GPU_DIAGNOSTIC_*.txt.
pause
