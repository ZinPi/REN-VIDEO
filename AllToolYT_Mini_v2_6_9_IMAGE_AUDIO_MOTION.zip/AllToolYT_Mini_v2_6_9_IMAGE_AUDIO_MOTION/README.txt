ALLTOOLYT MINI v2.6.9 — HƯỚNG DẪN CHÍNH
========================================
Đọc HUONG_DAN_MOI_V269.txt trước khi chạy.

CÁC CÔNG CỤ
------------
1) ĐỔI TÊN FILE
- Sắp xếp danh sách, xem trước tên mới và đổi tên theo quy tắc.
- Có kiểm tra xung đột tên đích và cơ chế rollback trong các ca lỗi đã kiểm thử.

2) TẠO VIDEO

Tab “Audio + Video”
- Ghép audio với video theo các quy tắc của tab.
- Tùy chọn Speed / Loop / Cut-Freeze để đồng bộ video theo audio.
- Chỉnh âm lượng audio gốc, chế độ xử lý giọng, tỷ lệ 16:9 / 9:16, 720p / 1080p / 2K / 4K.
- Hỗ trợ NVENC nếu kiểm tra thực tế thành công; có fallback CPU.
- Có tùy chọn chuyển cảnh khi ghép timeline.

Tab “Ảnh + SRT”
- Chọn file SRT timeline và thư mục ảnh.
- Chọn nhiều chuyển động ảnh: Zoom In/Out, Pan 4 hướng, Zoom In → Pan, Zoom In + Pan.
- Có preset chọn nhóm hiệu ứng, cường độ và FPS.
- SRT quyết định thứ tự và thời điểm đổi ảnh; các cue chồng thời gian bị từ chối.

Tab “Ảnh + Audio (1:1)”
- Ghép N ảnh + N audio thành một MP4 tổng, không cần SRT.
- Chỉ ghép đúng chỉ số nếu tên file có số; không ghép nhầm khi thiếu hoặc thừa index.
- Có ĐẦY ĐỦ 15 lựa chọn chuyển động ảnh: Zoom In/Out, Pan 4 hướng, 4 combo Zoom In → Pan, 4 combo Zoom In + Pan và Không hiệu ứng.
- Có preset Zoom + Pan, 4 Pan, 2 Zoom, Combo Zoom+Pan, Không hiệu ứng và Bỏ chọn.
- Chọn một hiệu ứng để áp dụng cho mọi ảnh; chọn nhiều để luân phiên giữa các ảnh.
- Chỉnh cường độ và FPS riêng cho tab này.
- Có tùy chọn xuất thêm video riêng cho mỗi cặp ảnh/audio.
- Audio được giải mã và nối thành FLAC master trước khi mux vào video tổng.

3) LẤY NỘI DUNG YT
- Lấy transcript/subtitle YouTube theo ngôn ngữ chọn; có thể dùng fallback nhận dạng giọng nói khi cấu hình phù hợp.
- Sao chép nội dung và lưu TXT/SRT/JSON.

CÁCH CHẠY
----------
1. Giải nén ZIP vào một thư mục, không chạy trực tiếp bên trong ZIP.
2. Cần Python 3 có tkinter; chạy CAI_THU_VIEN.bat nếu chưa cài phụ thuộc.
3. Chạy CHAY_TOOL.bat hoặc CHAY_TOOL_KHONG_CMD.vbs.
4. Nếu không mở GUI, chạy KIEM_TRA_KHOI_DONG.bat và xem STARTUP_ERROR.log.

BUILD EXE
---------
Chạy BUILD_EXE.bat trên Windows. Bản EXE cần được kiểm thử trên chính máy đích.

GPU / NVENC
-----------
- Bật GPU và bấm TEST NVENC để chạy phép thử mã hóa thật.
- NVENC chỉ tăng tốc mã hóa video; một số bộ lọc scale/zoom/pan vẫn dùng CPU.
- Nếu NVENC không qua kiểm tra, tool có thể chuyển sang libx264 CPU.
- QA hiện tại xác nhận bộ lọc chuyển động bằng FFmpeg CPU trên Linux; chưa chứng nhận RTX 3060/NVENC hoặc EXE Windows.

QA
--
- Chạy python TEST_ENGINE_QA.py để kiểm tra pairing, timeline, render 1:1 và toàn bộ 15 hiệu ứng chuyển động.
- Xem QA_REPORT_v2.6.9.txt để biết chính xác phạm vi thử nghiệm và các giới hạn còn lại.
